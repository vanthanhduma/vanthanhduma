from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]


class Python315LazyImportCompatibilityTests(unittest.TestCase):
    def test_qt_disables_lazy_imports_before_pyside6(self):
        source = (ROOT / "qt_app.py").read_text(encoding="utf-8")
        guard = 'if hasattr(sys, "set_lazy_imports"):\n    sys.set_lazy_imports("none")'
        self.assertIn(guard, source)
        self.assertLess(source.index(guard), source.index("from PySide6.QtCore"))

    def test_every_runtime_entrypoint_disables_lazy_imports_early(self):
        boundaries = {
            "qt_app.py": "from PySide6.QtCore",
            "app.py": "import cv2",
            "engine_worker.py": "import cv2",
            "download_engine.py": "import json",
        }
        for name, boundary in boundaries.items():
            with self.subTest(name=name):
                source = (ROOT / name).read_text(encoding="utf-8")
                guard = 'if hasattr(sys, "set_lazy_imports"):\n    sys.set_lazy_imports("none")'
                self.assertIn(guard, source)
                self.assertLess(source.index(guard), source.index(boundary))

    def test_python315_lazy_import_api_is_optional_and_usable(self):
        if not hasattr(sys, "set_lazy_imports"):
            self.skipTest("sys.set_lazy_imports is available from Python 3.15")
        previous = sys.get_lazy_imports()
        try:
            sys.set_lazy_imports("none")
            self.assertEqual(sys.get_lazy_imports(), "none")
        finally:
            sys.set_lazy_imports(previous)


if __name__ == "__main__":
    unittest.main()
