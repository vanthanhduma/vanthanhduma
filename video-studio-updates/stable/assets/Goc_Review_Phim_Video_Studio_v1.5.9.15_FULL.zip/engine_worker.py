from __future__ import annotations

"""Hidden Tk processing engine bridge for the PySide6 desktop shell.

The existing processing engine remains in app.py. This worker owns the Tk
interpreter and all legacy processing methods; the Qt UI communicates with it
through newline-delimited JSON over stdin/stdout. No FFmpeg work runs on the Qt
GUI thread.
"""

import sys

# Python 3.15 adds PEP 810 lazy imports. Resolve all imports eagerly before
# loading Qt or third-party libraries; PySide6's import hook can otherwise
# leave lazy proxies uncallable in concurrent worker paths.
if hasattr(sys, "set_lazy_imports"):
    # CPython 3.15 accepts "normal" or "all"; normal keeps regular imports eager.
    sys.set_lazy_imports("normal")
    # Also force explicitly marked lazy imports to resolve immediately.
    if hasattr(sys, "set_lazy_imports_filter"):
        sys.set_lazy_imports_filter(lambda _importing, _imported, _fromlist: False)

import json
import os
# Keep OpenCV/BLAS from multiplying worker threads while games or other heavy apps run.
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "2")
# Tesseract uses OpenMP; cap its child-process parallelism so scanning yields CPU to the UI and foreground apps.
os.environ.setdefault("OMP_THREAD_LIMIT", "1")
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
import tempfile
import traceback
import time
import shutil
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox

import cv2
import numpy as np
from PIL import Image

try:
    cv2.setNumThreads(2)
except Exception:
    pass

import app as core
from batch_cta_queue import BatchCTAQueue
from batch_cta_projects import save_batch_cta_project
from project_storage import ensure_project_workspace, video_fingerprint

OUT = sys.__stdout__
IN = sys.__stdin__
COMMANDS: queue.Queue[dict] = queue.Queue()
STATE_DIR = Path(tempfile.gettempdir()) / "GocReviewPhim_QtBridge"
STATE_DIR.mkdir(parents=True, exist_ok=True)
PREVIEW_PATH = STATE_DIR / "preview.jpg"
MASK_PATH = STATE_DIR / "mask.png"
MASK_TASK_EVENTS: queue.Queue[dict] = queue.Queue()
MASK_TASK_ACTIVE = False
MASK_TASK_THREAD: threading.Thread | None = None
MASK_TASK_TOKEN = ""
THUMB_DIR = STATE_DIR / "thumbs"
THUMB_DIR.mkdir(parents=True, exist_ok=True)

app_instance: core.VideoToolApp | None = None
root: tk.Tk | None = None
last_preview_signature: tuple | None = None
preview_revision = 0
thumb_cache: dict[str, str] = {}
thumb_pending: set[str] = set()
CTA_CANCEL_EVENT: threading.Event | None = None
CTA_PAUSE_EVENT: threading.Event | None = None
CTA_SCAN_THREAD: threading.Thread | None = None
CTA_SCAN_RUNNING = False
CTA_PREVIEW_STOP_EVENT: threading.Event | None = None
CTA_PREVIEW_THREAD: threading.Thread | None = None
CTA_PREVIEW_RUNNING = False
BATCH_CANCEL_EVENT: threading.Event | None = None
BATCH_SCAN_THREAD: threading.Thread | None = None
BATCH_SCAN_RUNNING = False
BATCH_CTA_CANCEL_EVENT: threading.Event | None = None
BATCH_CTA_THREAD: threading.Thread | None = None
BATCH_CTA_RUNNING = False
BATCH_CTA_QUEUE: BatchCTAQueue | None = None
EMIT_LOCK = threading.Lock()
thumb_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="QtSceneThumb")
shutdown_requested = False


def emit(payload: dict) -> None:
    try:
        line = json.dumps(payload, ensure_ascii=True, separators=(",", ":")) + "\n"
        with EMIT_LOCK:
            OUT.write(line)
            OUT.flush()
    except Exception:
        pass


def reader() -> None:
    while True:
        line = IN.readline()
        if not line:
            COMMANDS.put({"cmd": "__stdin_closed__"})
            return
        try:
            payload = json.loads(line)
            if isinstance(payload, dict):
                COMMANDS.put(payload)
        except Exception:
            emit({"type": "error", "message": "Lệnh Qt bridge không phải JSON hợp lệ."})


def _notify(kind: str, title: str, message: str, **_kwargs):
    # Export completion and QC are shown in the main workspace, not a second modal window.
    if str(title).startswith("Đã xuất"):
        emit({"type": "export_notice", "kind": kind, "title": str(title), "message": str(message)})
    else:
        emit({"type": "notice", "kind": kind, "title": str(title), "message": str(message)})
    return "ok"


def _confirm(_title: str, _message: str, **_kwargs) -> bool:
    # Destructive actions are confirmed in the Qt shell before reaching this worker.
    return True


# Avoid a second, unstyled Tk message-box layer on top of the Qt window.
messagebox.showinfo = lambda title, message, **kw: _notify("info", title, message, **kw)
messagebox.showwarning = lambda title, message, **kw: _notify("warning", title, message, **kw)
messagebox.showerror = lambda title, message, **kw: _notify("error", title, message, **kw)
messagebox.askyesno = _confirm
messagebox.askokcancel = _confirm
messagebox.askretrycancel = _confirm


def _with_dialog_value(dialog_name: str, value: str, callback):
    original = getattr(filedialog, dialog_name)
    setattr(filedialog, dialog_name, lambda **_kwargs: value)
    try:
        return callback()
    finally:
        setattr(filedialog, dialog_name, original)


def _mark_preview_dirty() -> None:
    global preview_revision
    preview_revision += 1


def _render_preview(force: bool = False) -> None:
    global last_preview_signature
    app = app_instance
    if app is None or app.frame is None:
        return
    signature = (id(app.frame), id(app.mask), preview_revision,
                 app.frame_time_var.get() if hasattr(app, "frame_time_var") else "")
    if not force and signature == last_preview_signature and PREVIEW_PATH.exists():
        return
    source = app.frame
    h, w = source.shape[:2]
    scale = min(1600.0 / max(1, w), 900.0 / max(1, h), 1.0)
    preview_w = max(1, int(round(w * scale)))
    preview_h = max(1, int(round(h * scale)))
    if scale < 1.0:
        frame = cv2.resize(source, (preview_w, preview_h), interpolation=cv2.INTER_AREA)
    else:
        frame = source.copy()

    if app.mask is not None and app.show_mask.get():
        show = app.mask
        if scale < 1.0:
            show = cv2.resize(show, (preview_w, preview_h), interpolation=cv2.INTER_NEAREST)
        try:
            expansion = int(app._effective_mask_expansion())
        except Exception:
            expansion = 0
        preview_expansion = max(0, int(round(expansion * scale)))
        if preview_expansion > 0:
            k = preview_expansion * 2 + 1
            show = cv2.dilate(show, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        tint = np.zeros_like(frame)
        tint[:, :, 2] = 255
        blended = cv2.addWeighted(frame, 0.62, tint, 0.38, 0)
        active_pixels = show > 0
        frame[active_pixels] = blended[active_pixels]

    if app.lasso_points:
        try:
            pts = (np.asarray(app.lasso_points, dtype=np.float32) * scale).astype(np.int32).reshape((-1, 1, 2))
            cv2.polylines(frame, [pts], True, (203, 193, 49), max(1, int(round(3 * scale))), cv2.LINE_AA)
        except Exception:
            pass
    cv2.imwrite(str(PREVIEW_PATH), frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if app.mask is not None:
        try:
            cv2.imwrite(str(MASK_PATH), app.mask)
        except Exception:
            pass
    last_preview_signature = signature


def _thumb_key(video_path: str, start: float) -> str:
    return f"{str(Path(video_path).resolve())}|{float(start):.3f}"


def _make_thumb(video_path: str, start: float, key: str) -> None:
    try:
        frame = core.read_frame(video_path, start)
        h, w = frame.shape[:2]
        scale = min(180 / max(1, w), 100 / max(1, h))
        resized = cv2.resize(frame, (max(1, int(w * scale)), max(1, int(h * scale))),
                             interpolation=cv2.INTER_AREA)
        path = THUMB_DIR / (str(abs(hash(key))) + ".jpg")
        cv2.imwrite(str(path), resized, [cv2.IMWRITE_JPEG_QUALITY, 82])
        thumb_cache[key] = str(path)
    except Exception:
        thumb_cache[key] = ""
    finally:
        thumb_pending.discard(key)


def _snapshot() -> dict:
    app = app_instance
    if app is None:
        return {"ready": False}
    _render_preview()
    video_path = str(app.video_path or "")
    info = app.info or {}
    scenes = []
    if video_path:
        for i, scene in enumerate(app.scenes):
            start = float(scene.get("start", 0.0))
            end = float(scene.get("end", 0.0))
            key = _thumb_key(video_path, start)
            thumb = thumb_cache.get(key, "")
            if key not in thumb_cache and key not in thumb_pending:
                thumb_pending.add(key)
                thumb_executor.submit(_make_thumb, video_path, start, key)
            scenes.append({
                "index": i,
                "name": str(scene.get("name", f"Cảnh {i + 1}")),
                "start": start,
                "end": end,
                "start_text": app._fmt_time(start),
                "end_text": app._fmt_time(end),
                "thumbnail": thumb,
            })
    try:
        progress = float(app.progress["value"])
    except Exception:
        progress = 0.0
    frame_w = int(info.get("width", 0) or (app.frame.shape[1] if app.frame is not None else 0))
    frame_h = int(info.get("height", 0) or (app.frame.shape[0] if app.frame is not None else 0))
    return {
        "ready": True,
        "version": core.APP_VERSION,
        "project_name": app.project_name_var.get(),
        "project_path": str(app.current_project_path or ""),
        "dirty": bool(app.project_dirty),
        "autosave": bool(app.autosave_enabled_var.get()),
        "autosave_label": app.autosave_nav_var.get(),
        "video_path": video_path,
        "video_name": Path(video_path).name if video_path else "Chưa chọn video",
        "logo_path": str(app.logo_path or ""),
        "output_dir": str(app.output_dir or ""),
        "meta": app.meta_var.get(),
        "status": app.status_var.get(),
        "busy": bool(app.busy),
        "mask_busy": bool(getattr(app, "mask_busy", False)),
        "batch_active": bool(getattr(app, "batch_active", False)),
        "progress": progress,
        "duration": float(info.get("duration", 0.0) or 0.0),
        "width": frame_w,
        "height": frame_h,
        "fps": float(info.get("fps", 0.0) or 0.0),
        "codec": str(info.get("codec", "")),
        "frame_time": float(core.safe_float(app.frame_time_var.get(), "Thời điểm") if app.frame_time_var.get() else 0.0),
        "range_start": str(app.segment_start_var.get()),
        "range_end": str(app.segment_end_var.get()),
        "minute_start": str(app.segment_from_minutes_var.get()),
        "minute_end": str(app.segment_to_minutes_var.get()),
        "selected_scene": app.selected_scene_index,
        "scene_count": len(app.scenes),
        "scenes": scenes,
        "has_mask": app.mask is not None,
        "mask_pixels": int(cv2.countNonZero(app.mask)) if app.mask is not None else 0,
        "mask_tool": str(app.mask_tool_var.get()),
        "brush_size": int(app.mask_brush_size_var.get()),
        "expansion": int(app.expansion_var.get()),
        "auto_expansion": bool(app.auto_mask_expansion_var.get()),
        "show_mask": bool(app.show_mask.get()),
        "smart_mask": bool(app.auto_mask_expansion_var.get()),
        "preview_path": str(PREVIEW_PATH) if PREVIEW_PATH.exists() else "",
        "mask_path": str(MASK_PATH) if MASK_PATH.exists() else "",
        "frame_revision": preview_revision,
        "ffmpeg_status": str(app.ffmpeg_status_var.get()),
        "gpu_status": str(app.gpu_status_label.cget("text")) if getattr(app, "gpu_status_label", None) else "",
    }


def _load_video(path: str) -> None:
    app = app_instance
    if not path or not Path(path).is_file():
        raise ValueError("Không tìm thấy video nguồn.")
    # JSON commands are ASCII-escaped by the Qt shell. This avoids Windows
    # ANSI-code-page corruption of Vietnamese/non-ASCII file names.
    loaded = app.load_video_path(str(Path(path).expanduser().resolve()))
    if not loaded:
        raise RuntimeError("Không nạp video: thao tác bị hủy hoặc engine đang bận.")
    _mark_preview_dirty()


def _load_project(path: str) -> None:
    app = app_instance
    if not path or not Path(path).is_file():
        raise ValueError("Không tìm thấy file dự án.")
    if not app._confirm_unsaved_project():
        return
    ok = app._load_project_file(Path(path).expanduser().resolve())
    if not ok:
        raise RuntimeError("Không mở được dự án. Kiểm tra video nguồn và tài nguyên liên kết.")
    _mark_preview_dirty()


def _save_project(path: str | None = None, save_as: bool = False) -> None:
    app = app_instance
    if path:
        _with_dialog_value("asksaveasfilename", path, lambda: app.save_project(save_as=save_as))
    else:
        app.save_project(save_as=save_as)


def _choose_logo(path: str) -> None:
    app = app_instance
    _with_dialog_value("askopenfilename", path, app.choose_logo)


def _choose_output(path: str) -> None:
    app = app_instance
    _with_dialog_value("askdirectory", path, app.choose_output_dir)


def _set_frame_time(seconds: float, preserve_mask: bool = True) -> None:
    app = app_instance
    if not app.video_path or not app.info:
        return
    duration = float(app.info.get("duration", 0.0))
    seconds = max(0.0, min(float(seconds), max(0.0, duration - 0.05)))
    frame = core.read_frame(app.video_path, seconds)
    app.frame = frame
    app.frame_time_var.set(f"{seconds:.3f}".rstrip("0").rstrip("."))
    app.preview_seek_var.set(seconds)
    app.preview_seek_label_var.set(app._fmt_time(seconds))
    if not preserve_mask:
        app.mask = None
        app.lasso_points = []
        app.canvas_points = []
        app._clear_mask_history()
    try:
        app.refresh_canvas()
    except Exception:
        pass
    _mark_preview_dirty()


def _stop_cta_preview() -> dict:
    if CTA_PREVIEW_STOP_EVENT is not None:
        CTA_PREVIEW_STOP_EVENT.set()
    return {"ok": True}


def _start_cta_preview(start: float, end: float, stream_type: str = "cta") -> dict:
    global CTA_PREVIEW_STOP_EVENT, CTA_PREVIEW_THREAD, CTA_PREVIEW_RUNNING
    stream_label = "video gốc" if stream_type == "video" else "đoạn CTA"
    app = app_instance
    if app is None or not app.video_path or not Path(app.video_path).is_file():
        raise ValueError(f"Hãy mở video nguồn trước khi xem {stream_label}.")
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    start = max(0.0, float(start))
    end = min(duration, float(end)) if duration else float(end)
    if end <= start:
        raise ValueError("Mốc kết thúc phải lớn hơn mốc bắt đầu.")
    if CTA_PREVIEW_STOP_EVENT is not None:
        CTA_PREVIEW_STOP_EVENT.set()
    stop_event = threading.Event()
    CTA_PREVIEW_STOP_EVENT = stop_event
    CTA_PREVIEW_RUNNING = True
    video_path = str(app.video_path)
    token = uuid.uuid4().hex

    def playback() -> None:
        global CTA_PREVIEW_RUNNING, CTA_PREVIEW_STOP_EVENT
        cap = cv2.VideoCapture(video_path)
        # Keep only a short rolling window.  The old implementation retained
        # one JPEG per emitted frame, so a long source video could accumulate
        # hundreds of thousands of files and make both the worker and Explorer
        # crawl.
        paths: list[Path] = []
        written_count = 0
        try:
            if not cap.isOpened():
                raise RuntimeError(f"Không mở được video để xem {stream_label}.")
            fps = max(1.0, min(120.0, float(cap.get(cv2.CAP_PROP_FPS) or 25.0)))
            first_frame = max(0, int(round(start * fps)))
            last_frame = max(first_frame, int(round(end * fps)))
            cap.set(cv2.CAP_PROP_POS_FRAMES, first_frame)
            output_step = max(1, int(round(fps / 6.0)))
            frame_index = first_frame
            next_output = first_frame
            output_interval = output_step / fps
            while frame_index <= last_frame and not stop_event.is_set():
                tick = time.monotonic()
                # Grab every source frame to keep playback timing correct, but
                # only materialize the frames that will actually be displayed.
                ok = cap.grab()
                if not ok:
                    break
                if frame_index >= next_output:
                    ok, frame = cap.retrieve()
                    if not ok or frame is None:
                        break
                    height, width = frame.shape[:2]
                    scale = min(960.0 / max(1, width), 540.0 / max(1, height), 1.0)
                    if scale < 1.0:
                        frame = cv2.resize(frame, (max(1, round(width * scale)), max(1, round(height * scale))), interpolation=cv2.INTER_AREA)
                    path = STATE_DIR / f"cta_playback_{token}_{written_count:06d}.jpg"
                    written_count += 1
                    if cv2.imwrite(str(path), frame, [cv2.IMWRITE_JPEG_QUALITY, 76]):
                        paths.append(path)
                        if len(paths) > 8:
                            stale_path = paths.pop(0)
                            try:
                                stale_path.unlink(missing_ok=True)
                            except Exception:
                                pass
                        emit({"type": f"{stream_type}_preview_frame", "payload": {
                            "token": token, "path": str(path),
                            "seconds": round(frame_index / fps, 3), "end": round(end, 3),
                        }})
                    next_output += output_step
                    elapsed = time.monotonic() - tick
                    if elapsed < output_interval:
                        time.sleep(output_interval - elapsed)
                frame_index += 1
            emit({"type": f"{stream_type}_preview_done", "payload": {"token": token}})
        except Exception as exc:
            emit({"type": f"{stream_type}_preview_error", "payload": {"token": token, "message": str(exc)}})
        finally:
            cap.release()
            for path in paths:
                try:
                    path.unlink(missing_ok=True)
                except Exception:
                    pass
            CTA_PREVIEW_RUNNING = False
            if CTA_PREVIEW_STOP_EVENT is stop_event:
                CTA_PREVIEW_STOP_EVENT = None

    CTA_PREVIEW_THREAD = threading.Thread(target=playback, name="QtCTAPreview", daemon=True)
    CTA_PREVIEW_THREAD.start()
    return {"ok": True, "token": token, "start": start, "end": end}


def _start_video_preview(start: float, end: float) -> dict:
    return _start_cta_preview(start, end, stream_type="video")


def _set_selection(points: list[list[float]], shape: str) -> None:
    app = app_instance
    if app.frame is None or len(points) < 3:
        return
    h, w = app.frame.shape[:2]
    pts = [(max(0, min(w - 1, int(round(p[0])))),
            max(0, min(h - 1, int(round(p[1]))))) for p in points]
    app._push_mask_undo()
    app.lasso_points = pts
    app.canvas_points = []
    app.mask = None
    app.show_mask.set(True)
    app._mark_project_dirty()
    app.status_var.set("Đã khoanh vùng. Chọn Tự tách nét hoặc Dùng toàn bộ vùng khoanh.")
    try:
        app.refresh_canvas()
    except Exception:
        pass
    _mark_preview_dirty()


def _mask_stroke(points: list[list[float]], erase: bool = False) -> None:
    app = app_instance
    if app.frame is None or app.mask is None or not points:
        return
    app._push_mask_undo()
    app._brush_undo_pushed = True
    for p in points:
        x, y = int(round(p[0])), int(round(p[1]))
        app._paint_mask_at(x, y, erase=erase)
    app._brush_last = None
    app._brush_undo_pushed = False
    app._mark_project_dirty()
    _mark_preview_dirty()



def _current_scene():
    app = app_instance
    idx = getattr(app, "selected_scene_index", None)
    if idx is not None and 0 <= int(idx) < len(getattr(app, "scenes", [])):
        return app.scenes[int(idx)]
    return None


def _branding_state() -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Hãy mở video và tải khung hình trước khi mở Studio Branding.")
    scene = _current_scene()
    has_override = bool(scene and isinstance(scene.get("branding"), dict))
    cfg = dict(scene.get("branding") or app.branding_config) if scene else dict(app.branding_config)
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    cfg = {**core.default_branding_config(duration), **cfg}
    logo_path = str((scene.get("branding_logo_path") if has_override else None) or app.logo_path or "")
    return {
        "config": cfg,
        "logo_path": logo_path,
        "label_text": app._branding_text(),
        "frame_time": float(core.safe_float(app.frame_time_var.get(), "Thời điểm") if app.frame_time_var.get() else 0.0),
        "duration": duration,
        "scene_index": getattr(app, "selected_scene_index", None),
        "scene_name": str(scene.get("name", "Phân cảnh đang chọn")) if scene else "",
        "scene_has_override": has_override,
        "preset_names": [x.stem for x in app._branding_preset_files()],
    }


def _branding_preview(payload: dict) -> dict:
    """Render the preview background and transparent logo as separate UI layers."""
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Chưa có khung hình video để xem trước Branding.")

    source = app.frame
    h, w = source.shape[:2]
    # The preview canvas is not an export frame. Work at a UI-sized resolution
    # from the start instead of building multiple full-resolution 4K layers.
    preview_scale = min(1280.0 / max(1, w), 720.0 / max(1, h), 1.0)
    preview_w = max(1, int(round(w * preview_scale)))
    preview_h = max(1, int(round(h * preview_scale)))
    if preview_w != w or preview_h != h:
        preview_source = cv2.resize(
            source, (preview_w, preview_h), interpolation=cv2.INTER_AREA
        )
    else:
        preview_source = source

    cfg = {
        **core.default_branding_config(float((app.info or {}).get("duration", 0.0) or 0.0)),
        **(payload.get("config") if isinstance(payload.get("config"), dict) else {}),
    }
    logo_path = str(payload.get("logo_path", app.logo_path or ""))
    label_text = str(payload.get("label_text") or app._branding_text())
    try:
        seconds = float(app.frame_time_var.get() or 0.0)
    except Exception:
        seconds = 0.0
    start = max(0.0, float(cfg.get("show_from", 0.0)))
    end = max(start, float(cfg.get("show_to", (app.info or {}).get("duration", 0.0) or 0.0)))
    visible_now = start <= seconds < end

    # Build each component once. The background contains the video and label;
    # the logo remains a small transparent PNG that Qt can move locally while
    # the user drags, without sending a render request for every mouse event.
    logo_layer, label_layer = core.build_branding_components(
        preview_w, preview_h, logo_path, label_text, cfg
    )
    logo_rect = None
    logo_crop = None
    if visible_now:
        alpha = logo_layer[:, :, 3]
        ys, xs = np.where(alpha > 4)
        if xs.size:
            min_x, max_x = int(xs.min()), int(xs.max()) + 1
            min_y, max_y = int(ys.min()), int(ys.max()) + 1
            sx = w / float(preview_w)
            sy = h / float(preview_h)
            logo_rect = [
                int(round(min_x * sx)),
                int(round(min_y * sy)),
                int(round(max_x * sx)),
                int(round(max_y * sy)),
            ]
            logo_crop = logo_layer[min_y:max_y, min_x:max_x].copy()
        rendered = core.apply_mask_and_overlay(
            preview_source.copy(), None, 0, label_layer
        )
    else:
        rendered = preview_source

    preview_id = uuid.uuid4().hex
    target = STATE_DIR / f"branding_preview_{preview_id}.jpg"
    if not cv2.imwrite(
        str(target), rendered, [cv2.IMWRITE_JPEG_QUALITY, 86]
    ):
        raise RuntimeError("Không ghi được ảnh xem trước Branding.")

    logo_overlay_path = ""
    if logo_crop is not None and logo_crop.size:
        logo_target = STATE_DIR / f"branding_logo_{preview_id}.png"
        if not cv2.imwrite(
            str(logo_target), logo_crop,
            [cv2.IMWRITE_PNG_COMPRESSION, 3],
        ):
            target.unlink(missing_ok=True)
            raise RuntimeError("Không ghi được lớp logo trong suốt của Branding.")
        logo_overlay_path = str(logo_target)

    return {
        "preview_path": str(target),
        "logo_overlay_path": logo_overlay_path,
        "logo_rect": logo_rect,
        "frame_width": int(w), "frame_height": int(h),
        "preview_token": payload.get("preview_token"),
        "preview_width": int(preview_w), "preview_height": int(preview_h),
    }


def _branding_apply(payload: dict) -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Chưa có video để áp dụng Branding.")
    cfg = payload.get("config")
    if not isinstance(cfg, dict):
        raise ValueError("Thiết lập Branding không hợp lệ.")
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    new_cfg = {**core.default_branding_config(duration), **cfg}
    show_from = max(0.0, float(new_cfg.get("show_from", 0.0)))
    show_to = max(0.0, float(new_cfg.get("show_to", duration)))
    if show_to < show_from:
        raise ValueError("Mốc kết thúc Branding phải lớn hơn hoặc bằng mốc bắt đầu.")
    if duration and show_to > duration + 0.05:
        raise ValueError(f"Mốc kết thúc vượt thời lượng video ({app._fmt_time(duration)}).")
    logo_path = str(payload.get("logo_path", "") or "")
    if bool(new_cfg.get("logo_enabled", True)) and (not logo_path or not Path(logo_path).is_file()):
        raise ValueError("Logo đang bật nhưng file ảnh không tồn tại. Hãy chọn lại logo hoặc tắt hiển thị logo.")
    # The label text remains a project-level field shared by the renderer.
    # Parse it into the existing legacy label variables so Qt and export stay in sync.
    label_text = str(payload.get("label_text", "") or "").strip()
    if label_text:
        known_types = ("Tập", "Phần", "Chương")
        matched = False
        for label_type in known_types:
            prefix = label_type + " "
            if label_text.casefold().startswith(prefix.casefold()):
                app.label_type_var.set(label_type)
                app.label_value_var.set(label_text[len(prefix):].strip())
                matched = True
                break
        if not matched:
            app.label_type_var.set("Tùy chỉnh")
            app.label_value_var.set(label_text)

    scene_scope = bool(payload.get("scene_scope", False))
    scene = _current_scene()
    if scene_scope:
        if scene is None:
            raise ValueError("Chưa chọn phân cảnh để áp dụng Branding riêng.")
        scene["branding"] = new_cfg
        scene["branding_logo_path"] = logo_path
        message = f"Đã áp dụng Branding riêng cho {scene.get('name', 'phân cảnh')}."
    else:
        app.branding_config = new_cfg
        app.logo_path = logo_path
        try:
            app.logo_var.set(Path(logo_path).name if logo_path else "")
        except Exception:
            pass
        message = "Đã áp dụng Branding cho toàn dự án."
    app._mark_project_dirty()
    try:
        app.refresh_canvas()
    except Exception:
        pass
    _mark_preview_dirty()
    app.status_var.set(message)
    return {"ok": True, "message": message, "branding_state": _branding_state()}


def _branding_preset_save(payload: dict) -> dict:
    app = app_instance
    name = re.sub(r"[^\w.-]+", "_", str(payload.get("name", "")).strip(), flags=re.UNICODE).strip("._ ")
    if not name:
        raise ValueError("Tên preset không hợp lệ.")
    if len(name) > 64:
        name = name[:64]
    cfg = payload.get("config")
    if not isinstance(cfg, dict):
        raise ValueError("Thiết lập preset không hợp lệ.")
    folder = app._branding_presets_dir()
    logo_path = str(payload.get("logo_path", "") or "")
    stored_logo = ""
    if logo_path:
        source = Path(logo_path)
        if not source.is_file():
            raise FileNotFoundError("Không tìm thấy file logo để đóng gói vào preset.")
        asset_dir = folder / "assets"
        asset_dir.mkdir(parents=True, exist_ok=True)
        target = asset_dir / f"{name}{source.suffix.lower()}"
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        stored_logo = str(target)
    target_json = folder / f"{name}.json"
    record = {"format": "goc-review-phim-branding-preset", "version": 1,
              "branding": cfg, "logo_file": stored_logo}
    tmp = target_json.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(target_json)
    return {"ok": True, "name": name, "preset_names": [x.stem for x in app._branding_preset_files()]}


def _branding_preset_load(payload: dict) -> dict:
    app = app_instance
    name = str(payload.get("name", "")).strip()
    if not name or Path(name).name != name:
        raise ValueError("Tên preset không hợp lệ.")
    target = app._branding_presets_dir() / f"{name}.json"
    if not target.is_file():
        raise FileNotFoundError("Không tìm thấy preset đã chọn.")
    record = json.loads(target.read_text(encoding="utf-8"))
    if record.get("format") != "goc-review-phim-branding-preset":
        raise ValueError("File preset không đúng định dạng Góc Review Phim.")
    logo = str(record.get("logo_file", "") or "")
    if logo and not Path(logo).is_file():
        logo = ""
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    cfg = {**core.default_branding_config(duration), **(record.get("branding") or {})}
    return {"ok": True, "name": name, "config": cfg,
            "logo_path": logo or str(app.logo_path or ""),
            "preset_names": [x.stem for x in app._branding_preset_files()]}


def _branding_preset_delete(payload: dict) -> dict:
    app = app_instance
    name = str(payload.get("name", "")).strip()
    if not name or Path(name).name != name:
        raise ValueError("Tên preset không hợp lệ.")
    target = app._branding_presets_dir() / f"{name}.json"
    if not target.is_file():
        raise FileNotFoundError("Không tìm thấy preset cần xóa.")
    target.unlink()
    return {"ok": True, "preset_names": [x.stem for x in app._branding_preset_files()]}


def _compare_frame() -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Hãy mở video và tải khung hình trước khi so sánh.")
    source = app.frame.copy()
    mask = app.mask.copy() if app.mask is not None else None
    if mask is None or cv2.countNonZero(mask) == 0:
        raise RuntimeError("Chưa có mask để so sánh. Hãy khoanh vùng rồi tạo mask trước.")
    if mask.shape[:2] != source.shape[:2]:
        raise RuntimeError("Kích thước mask không khớp khung hình hiện tại. Hãy nạp lại phân cảnh hoặc tạo mask mới.")
    expansion = int(app._effective_mask_expansion(mask))
    empty_overlay = np.zeros((source.shape[0], source.shape[1], 4), dtype=np.uint8)
    processed = core.apply_mask_and_overlay(source.copy(), mask, expansion, empty_overlay)
    compare_scale = min(1920.0 / max(1, source.shape[1]), 1080.0 / max(1, source.shape[0]), 1.0)
    if compare_scale < 1.0:
        out_size = (max(1, round(source.shape[1] * compare_scale)),
                    max(1, round(source.shape[0] * compare_scale)))
        source_display = cv2.resize(source, out_size, interpolation=cv2.INTER_AREA)
        processed_display = cv2.resize(processed, out_size, interpolation=cv2.INTER_AREA)
    else:
        source_display, processed_display = source, processed
    before_path = STATE_DIR / f"compare_before_{uuid.uuid4().hex}.jpg"
    after_path = STATE_DIR / f"compare_after_{uuid.uuid4().hex}.jpg"
    if not cv2.imwrite(str(before_path), source_display, [cv2.IMWRITE_JPEG_QUALITY, 91]):
        raise RuntimeError("Không lưu được ảnh gốc để so sánh.")
    if not cv2.imwrite(str(after_path), processed_display, [cv2.IMWRITE_JPEG_QUALITY, 91]):
        raise RuntimeError("Không lưu được ảnh sau Inpaint để so sánh.")
    return {"before_path": str(before_path), "after_path": str(after_path),
            "frame_time": float(core.safe_float(app.frame_time_var.get(), "Thời điểm") if app.frame_time_var.get() else 0.0),
            "width": int(source.shape[1]), "height": int(source.shape[0]),
            "mask_pixels": int(cv2.countNonZero(mask)), "expansion": expansion,
            "note": "Ảnh SAU đã áp dụng Inpaint theo mask và PX hiện tại; chưa bao gồm Branding."}


def _write_cta_thumbnail(path: Path, image_bytes: bytes) -> None:
    """Atomically publish an encoded CTA evidence image for the Qt process."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(image_bytes)
    temporary.replace(path)


def _encode_cta_thumbnail_fallback(frame, candidate: dict) -> bytes | None:
    """Fallback encoder for cache entries created before evidence frames were stored."""
    if frame is None or getattr(frame, "size", 0) == 0:
        return None
    preview = frame.copy()
    height, width = preview.shape[:2]
    x = max(0, min(width - 1, int(candidate.get("x", 0) or 0)))
    y = max(0, min(height - 1, int(candidate.get("y", 0) or 0)))
    w = max(1, int(candidate.get("w", 1) or 1))
    h = max(1, int(candidate.get("h", 1) or 1))
    cv2.rectangle(preview, (x, y), (min(width - 1, x + w), min(height - 1, y + h)), (40, 235, 220), 3)
    frame_h, frame_w = preview.shape[:2]
    scale = min(720.0 / max(1, frame_w), 420.0 / max(1, frame_h), 1.0)
    if scale < 1.0:
        preview = cv2.resize(
            preview,
            (max(1, round(frame_w * scale)), max(1, round(frame_h * scale))),
            interpolation=cv2.INTER_AREA,
        )
    ok, encoded = cv2.imencode(".jpg", preview, [cv2.IMWRITE_JPEG_QUALITY, 86])
    return encoded.tobytes() if ok else None


def _cta_cache_thumbnails(candidates: list[dict]) -> dict:
    """Rebuild temporary CTA preview images from the persistent candidate cache."""
    app = app_instance
    if app is None or not app.video_path or not Path(app.video_path).is_file():
        return {"candidates": list(candidates or [])}
    thumb_root = STATE_DIR / f"cta_cache_thumbs_{uuid.uuid4().hex}"
    thumb_root.mkdir(parents=True, exist_ok=True)
    prepared = []
    for index, raw in enumerate(candidates or []):
        item = dict(raw)
        try:
            sample_time = float(item.get("sample_time", item.get("start", 0.0)) or 0.0)
        except (TypeError, ValueError):
            sample_time = 0.0
        thumb_path = thumb_root / f"cta_cache_{index}.jpg"
        try:
            frame = core.read_frame(str(app.video_path), max(0.0, sample_time))
            encoded = _encode_cta_thumbnail_fallback(frame, item)
            if encoded:
                _write_cta_thumbnail(thumb_path, encoded)
                item["preview_path"] = str(thumb_path)
                item.pop("thumbnail_error", None)
            else:
                item["preview_path"] = ""
                item["thumbnail_error"] = "Không mã hóa được khung hình OCR."
        except Exception as exc:
            # A failed preview must not prevent other cached CTA results from loading.
            item["preview_path"] = ""
            item["thumbnail_error"] = str(exc)[:220]
        prepared.append(item)
    return {"candidates": prepared}



def _batch_cta_save_project(job: dict, scan_result: dict) -> str:
    """Build the normal per-video project and CTA evidence cache without touching current editor state."""
    source = Path(job["source_path"]).expanduser().resolve()
    project_path = Path(job["project_path"]).expanduser().resolve()
    info = core.read_video_info(str(source))
    evidence: dict[int, bytes] = {}
    for index, candidate in enumerate(scan_result.get("candidates", []) or []):
        try:
            sample_time = float(candidate.get("sample_time", candidate.get("start", 0.0)) or 0.0)
            frame = core.read_frame(str(source), max(0.0, sample_time))
            encoded = _encode_cta_thumbnail_fallback(frame, candidate)
            if encoded:
                evidence[index] = encoded
        except Exception:
            # Evidence generation is best-effort; preserve the recognized CTA
            # interval even when a thumbnail for one sampled frame cannot be made.
            continue
    result = save_batch_cta_project(
        source, project_path, info, scan_result, core.APP_VERSION,
        output_dir=core.default_output_directory(source),
        thumbnail_bytes=evidence,
    )
    return str(result["project_path"])


def _start_batch_cta(files: list[str], output_folder: str, resume_existing: bool = False) -> dict:
    """Run the existing image-only CTA detector sequentially and save one project per video."""
    global BATCH_CTA_CANCEL_EVENT, BATCH_CTA_THREAD, BATCH_CTA_RUNNING, BATCH_CTA_QUEUE
    if app_instance is None:
        raise RuntimeError("Engine chưa sẵn sàng.")
    if BATCH_CTA_RUNNING or BATCH_SCAN_RUNNING or CTA_SCAN_RUNNING or bool(app_instance.busy):
        raise RuntimeError("Engine đang bận hoặc một hàng đợi khác đang chạy.")
    folder = Path(output_folder or "").expanduser().resolve()
    if not str(output_folder or "").strip():
        raise ValueError("Hãy chọn thư mục lưu dự án.")
    folder.mkdir(parents=True, exist_ok=True)
    queue_file = folder / "Batch_Queue" / "queue.json"
    if resume_existing:
        if not queue_file.is_file():
            raise FileNotFoundError("Không tìm thấy hàng đợi đã lưu để tiếp tục.")
        batch_queue = BatchCTAQueue.load(queue_file)
    else:
        batch_queue = BatchCTAQueue.create(files or [], folder)
    if not batch_queue.jobs:
        raise ValueError("Hàng đợi không có video.")
    missing = [job["source_path"] for job in batch_queue.jobs
               if job.get("status") in {"queued", "scanning", "saving"}
               and not Path(job.get("source_path", "")).is_file()]
    if missing:
        raise FileNotFoundError("Không tìm thấy video trong hàng đợi: " + Path(missing[0]).name)

    ocr_status = core.get_subscribe_ocr_status()
    if not ocr_status.get("ready"):
        detail = str(ocr_status.get("detail", "")).strip()
        raise RuntimeError(str(ocr_status.get("message", "Tesseract OCR chưa sẵn sàng.")) +
                           (f"\n\n{detail}" if detail else ""))
    cancel = threading.Event()
    BATCH_CTA_CANCEL_EVENT = cancel
    BATCH_CTA_RUNNING = True
    BATCH_CTA_QUEUE = batch_queue
    app_instance.batch_active = True
    app_instance.busy = True

    def emit_snapshot() -> None:
        emit({"type": "batch_cta_snapshot", "payload": {
            "queue_file": str(batch_queue.state_path),
            "output_folder": str(batch_queue.output_folder),
            "jobs": [dict(job) for job in batch_queue.jobs],
            "summary": batch_queue.summary(),
        }})

    emit_snapshot()

    def run() -> None:
        completed_paths: list[str] = []
        failed_items: list[dict] = []
        stopped = False
        try:
            total = len(batch_queue.jobs)
            for index, job in enumerate(batch_queue.jobs):
                if cancel.is_set():
                    stopped = True
                    break
                if job.get("status") in {"completed", "skipped"}:
                    continue
                if job.get("status") == "failed":
                    continue
                source = str(job["source_path"])
                try:
                    batch_queue.set_status(job["id"], "scanning", progress=0, error="")
                    emit({"type": "batch_cta_job", "payload": {
                        "index": index, "job": dict(job), "total": total,
                    }})
                    last_save = [0.0]

                    def progress(done: int, sample_total: int, job_index=index, current=job):
                        pct = int(100 * max(0, min(sample_total, done)) / max(1, sample_total))
                        now = time.monotonic()
                        if now - last_save[0] >= 1.0 or done >= sample_total:
                            current["progress"] = pct
                            current["updated_at"] = datetime.now(timezone.utc).isoformat()
                            batch_queue.save()
                            last_save[0] = now
                        emit({"type": "batch_cta_progress", "payload": {
                            "index": job_index, "total": total, "job_id": current["id"],
                            "percent": pct, "message": f"Đang quét CTA · {done}/{sample_total} ảnh mẫu",
                            "video_name": Path(source).name,
                        }})

                    result = core.detect_cta_image_candidates(
                        source, sample_interval=2.0, max_samples=1800, scan_mode="fast",
                        cancel_event=cancel, progress_callback=progress,
                    )
                    if cancel.is_set():
                        stopped = True
                        break
                    batch_queue.set_status(job["id"], "saving", progress=100)
                    emit({"type": "batch_cta_saving", "payload": {
                        "index": index, "total": total, "job_id": job["id"],
                        "message": f"Đang lưu dự án và ảnh bằng chứng: {Path(source).name}",
                    }})
                    project_path = _batch_cta_save_project(job, result)
                    batch_queue.set_status(job["id"], "completed", progress=100, error="")
                    completed_paths.append(project_path)
                    emit({"type": "batch_cta_job_done", "payload": {
                        "index": index, "total": total, "job_id": job["id"],
                        "project_path": project_path, "candidate_count": len(result.get("candidates", [])),
                    }})
                except Exception as exc:
                    if cancel.is_set() or isinstance(exc, getattr(core, "CTAScanCancelled", Exception)):
                        stopped = True
                        break
                    batch_queue.set_status(job["id"], "failed", error=str(exc))
                    failed_items.append({"source": source, "error": str(exc), "job_id": job["id"]})
                    emit({"type": "batch_cta_job_failed", "payload": {
                        "index": index, "total": total, "job_id": job["id"],
                        "error": str(exc), "video_name": Path(source).name,
                    }})
            if cancel.is_set():
                stopped = True
            if stopped:
                batch_queue.stop_safely()
            elif batch_queue.finished:
                batch_queue.state["status"] = "completed"
                batch_queue.save()
            emit_snapshot()
            emit({"type": "batch_cta_done", "payload": {
                "stopped": stopped, "completed": batch_queue.completed_count,
                "failed": batch_queue.failed_count, "total": len(batch_queue.jobs),
                "queue_file": str(batch_queue.state_path),
                "projects": completed_paths, "failures": failed_items,
                "summary": batch_queue.summary(),
            }})
        except Exception as exc:
            batch_queue.state["status"] = "error"
            batch_queue.save()
            emit({"type": "batch_cta_error", "message": str(exc)})
        finally:
            app_instance.busy = False
            app_instance.batch_active = False
            BATCH_CTA_RUNNING = False
            BATCH_CTA_CANCEL_EVENT = None
            emit({"type": "state", "payload": _snapshot()})

    BATCH_CTA_THREAD = threading.Thread(target=run, name="QtBatchCTAProcessing", daemon=True)
    BATCH_CTA_THREAD.start()
    return {"ok": True, "count": len(batch_queue.jobs), "queue_file": str(batch_queue.state_path)}


def _stop_batch_cta() -> dict:
    if BATCH_CTA_CANCEL_EVENT is not None:
        BATCH_CTA_CANCEL_EVENT.set()
        return {"ok": True, "stopping": True}
    return {"ok": True, "stopping": False}


def _start_batch(files: list[str], output_folder: str) -> dict:
    global BATCH_CANCEL_EVENT, BATCH_SCAN_THREAD, BATCH_SCAN_RUNNING
    app = app_instance
    files = [str(Path(item).expanduser()) for item in (files or []) if str(item).strip()]
    if app is None:
        raise RuntimeError("Engine chưa sẵn sàng.")
    if not files:
        raise ValueError("Hàng đợi đang trống. Hãy thêm ít nhất một video.")
    if bool(app.busy) or CTA_SCAN_RUNNING or BATCH_SCAN_RUNNING:
        raise RuntimeError("Engine đang bận hoặc một hàng đợi khác đang chạy.")
    missing = [item for item in files if not Path(item).is_file()]
    if missing:
        raise ValueError("Không tìm thấy video: " + Path(missing[0]).name)
    folder = Path(output_folder or "").expanduser()
    if not folder:
        raise ValueError("Hãy chọn thư mục xuất.")
    folder.mkdir(parents=True, exist_ok=True)
    if app.mask is None and not any(sc.get("mask") is not None for sc in app.scenes):
        raise ValueError("Hãy tạo Mask hoặc thiết lập Mask theo phân cảnh trước khi chạy hàng loạt.")

    mask = app.mask.copy() if app.mask is not None else None
    expansion = app._effective_mask_expansion(mask)
    scenes = [{
        "name": sc.get("name", "Cảnh"), "start": float(sc["start"]), "end": float(sc["end"]),
        "expansion": int(sc.get("expansion", core.MASK_DEFAULT_EXPANSION)),
        "mask": sc["mask"].copy(), "branding_config": dict(sc.get("branding") or {}),
        "branding_logo_path": sc.get("branding_logo_path")
    } for sc in app.scenes if sc.get("mask") is not None]
    logo_path = app.logo_path
    branding = dict(app.branding_config)
    label = app._branding_text()
    prefer_gpu = bool(app.prefer_gpu_var.get())
    cancel = threading.Event()
    BATCH_CANCEL_EVENT = cancel
    BATCH_SCAN_RUNNING = True
    app.batch_active = True
    app.busy = True

    def report(index: int, pct: float, message: str) -> None:
        emit({"type": "batch_progress", "payload": {
            "index": int(index), "total": len(files),
            "percent": float(((index + max(0, min(100, float(pct))) / 100) / max(1, len(files))) * 100),
            "message": str(message or "")
        }})

    def run() -> None:
        success: list[str] = []
        failed: list[tuple[str, str]] = []
        quality_records: list[dict] = []
        try:
            for index, source in enumerate(files):
                if cancel.is_set():
                    break
                try:
                    report(index, 0, f"Đang chuẩn bị {Path(source).name}…")
                    info = core.read_video_info(source)
                    width, height = info["width"], info["height"]
                    if mask is not None and mask.shape[:2] != (height, width):
                        raise RuntimeError(f"Mask hiện tại {mask.shape[1]}×{mask.shape[0]} không khớp video {width}×{height}.")
                    for scene in scenes:
                        if scene["mask"].shape[:2] != (height, width):
                            raise RuntimeError(f"Mask phân cảnh '{scene['name']}' không khớp độ phân giải {width}×{height}.")
                    if branding.get("logo_enabled", True) and (not logo_path or not Path(logo_path).exists()):
                        raise RuntimeError("Không tìm thấy file logo đang chọn.")
                    overlay = core.build_overlay(width, height, logo_path, label, branding_config=branding)
                    scene_snap = []
                    for scene in scenes:
                        scene_logo = scene.get("branding_logo_path") or logo_path
                        scene_snap.append({**scene, "branding_overlay": (
                            core.build_overlay(width, height, scene_logo, label, branding_config=scene["branding_config"])
                            if scene.get("branding_config") else None
                        )})
                    destination = folder / f"{Path(source).stem}_GocReview.mp4"
                    suffix = 2
                    while destination.exists():
                        destination = folder / f"{Path(source).stem}_GocReview_{suffix}.mp4"
                        suffix += 1
                    core.encode_video(
                        str(source), str(destination), 0.0, None, mask, expansion, overlay,
                        lambda pct, msg, ii=index: report(ii, pct, msg), cancel_event=cancel,
                        prefer_gpu=prefer_gpu, scene_masks=scene_snap or None,
                        branding_range=(float(branding.get("show_from", 0.0)), float(branding.get("show_to", info.get("duration", 0.0))))
                    )
                    if cancel.is_set():
                        raise core.ExportCancelled()
                    quality = core.inspect_output_quality(str(source), str(destination), 0.0, float(info.get("duration", 0.0)))
                    quality_records.append(quality)
                    if quality.get("status") == "FAIL":
                        failed.append((source, f"QC thất bại; file được giữ lại: {destination}. {quality.get('summary', '')}"))
                    else:
                        success.append(str(destination))
                except core.ExportCancelled:
                    break
                except Exception as exc:
                    failed.append((source, str(exc)))
            report_path = folder / f"GocReview_Batch_Quality_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            try:
                text = "\n\n".join(core.format_quality_report(item) for item in quality_records)
                text += "\n\nTỔNG KẾT HÀNG LOẠT\n" + f"Thành công: {len(success)}\nLỗi/QC: {len(failed)}\nChưa chạy: {len(files) - len(success) - len(failed)}\n"
                if failed:
                    text += "\nDANH SÁCH LỖI\n" + "\n".join(f"{Path(src).name}: {err}" for src, err in failed)
                report_path.write_text(text, encoding="utf-8")
            except Exception:
                report_path = None
            emit({"type": "batch_done", "payload": {
                "success": success, "failed": [{"source": src, "error": err} for src, err in failed],
                "cancelled": bool(cancel.is_set()), "report_path": str(report_path or "")
            }})
        except Exception as exc:
            emit({"type": "batch_error", "message": str(exc)})
        finally:
            app.busy = False
            app.batch_active = False
            BATCH_SCAN_RUNNING = False
            BATCH_CANCEL_EVENT = None
            emit({"type": "state", "payload": _state_snapshot()})

    BATCH_SCAN_THREAD = threading.Thread(target=run, name="QtBatchProcessing", daemon=True)
    BATCH_SCAN_THREAD.start()
    return {"ok": True, "count": len(files)}


def _cancel_batch() -> dict:
    if BATCH_CANCEL_EVENT is not None:
        BATCH_CANCEL_EVENT.set()
    return {"ok": True}

def _start_cta_scan(interval: float, scan_mode: str = "balanced", start_at: float = 0.0) -> dict:
    global CTA_CANCEL_EVENT, CTA_PAUSE_EVENT, CTA_SCAN_THREAD, CTA_SCAN_RUNNING
    app = app_instance
    if app is None or not app.video_path or not Path(app.video_path).is_file():
        raise ValueError("Hãy mở video nguồn trước khi quét từ khóa CTA.")
    if bool(app.busy) or CTA_SCAN_RUNNING:
        raise RuntimeError("Engine đang bận hoặc Subscribe Detector đã chạy.")
    ocr_status = core.get_subscribe_ocr_status()
    if not ocr_status.get("ready"):
        message = str(ocr_status.get("message", "Tesseract OCR chưa sẵn sàng."))
        detail = str(ocr_status.get("detail", "")).strip()
        raise RuntimeError(message + (f"\n\nChi tiết kỹ thuật:\n{detail}" if detail else ""))
    if ocr_status.get("warning"):
        emit({"type": "cta_ocr_warning", "message": str(ocr_status["warning"])})
    if interval not in (0.25, 0.5, 1.0, 2.0):
        interval = 1.0
    scan_mode = (
        "deep" if str(scan_mode or "").strip().lower() == "deep"
        else "fast" if str(scan_mode or "").strip().lower() == "fast"
        else "balanced"
    )
    try:
        start_at = max(0.0, float(start_at or 0.0))
    except (TypeError, ValueError):
        start_at = 0.0
    cancel = threading.Event()
    pause = threading.Event()
    CTA_CANCEL_EVENT = cancel
    CTA_PAUSE_EVENT = pause
    CTA_SCAN_RUNNING = True
    app.cta_scan_running = True
    video_path = str(app.video_path)
    thumb_root = STATE_DIR / "cta_thumbs"
    thumb_root.mkdir(parents=True, exist_ok=True)
    scan_token = uuid.uuid4().hex
    thumb_confidences: dict[int, float] = {}
    progress_state = {"phase": "pass1", "resume_time": start_at}

    def _with_live_thumbnails(raw_candidates: list[dict], force: bool = False) -> list[dict]:
        prepared = []
        for raw in raw_candidates:
            item = dict(raw)
            preview_jpeg = item.pop("_preview_jpeg", None)
            try:
                preview_confidence = float(item.pop("_preview_confidence", 0) or 0)
            except (TypeError, ValueError):
                preview_confidence = 0.0
            scan_id = int(item.get("scan_id", len(prepared)))
            sample_time = float(item.get("sample_time", item.get("start", 0.0)))
            thumb_path = thumb_root / f"cta_{scan_token}_{scan_id}.jpg"

            # Save the exact frame already sampled by the OCR detector. No
            # second decoder process is needed to show a live result.
            last_confidence = thumb_confidences.get(scan_id, -1.0)
            if isinstance(preview_jpeg, bytes) and preview_jpeg and (
                not thumb_path.is_file() or preview_confidence > last_confidence
            ):
                try:
                    _write_cta_thumbnail(thumb_path, preview_jpeg)
                    thumb_confidences[scan_id] = preview_confidence
                    item.pop("thumbnail_error", None)
                except OSError as exc:
                    item["thumbnail_error"] = f"Không lưu được ảnh bằng chứng: {exc}"[:220]

            # Older or incomplete candidates have no embedded evidence. Only
            # retry FFmpeg after the scan has finished; one bad frame must not
            # discard the other candidates.
            if force and not thumb_path.is_file():
                try:
                    frame = core.read_frame(video_path, sample_time)
                    encoded = _encode_cta_thumbnail_fallback(frame, item)
                    if encoded:
                        _write_cta_thumbnail(thumb_path, encoded)
                        item.pop("thumbnail_error", None)
                    else:
                        item["thumbnail_error"] = "Không mã hóa được khung hình OCR."
                except Exception as exc:
                    item["thumbnail_error"] = str(exc)[:220]

            item["preview_path"] = str(thumb_path) if thumb_path.is_file() else ""
            prepared.append(item)
        return prepared

    last_progress_emit_at = [0.0]
    last_progress_emit_done = [0]
    last_phase_emit_at = [0.0]
    last_phase_emit_key = [None]
    last_candidate_emit_at = [0.0]

    def report(done: int, total: int) -> None:
        now = time.monotonic()
        if (done >= total or done - last_progress_emit_done[0] >= 64
                or now - last_progress_emit_at[0] >= 1.0):
            last_progress_emit_at[0] = now
            last_progress_emit_done[0] = int(done)
            emit({"type": "cta_progress", "payload": {
                "done": int(done), "total": int(total),
                "resume_time": float(progress_state["resume_time"]),
                "phase": str(progress_state["phase"]),
            }})

    def checkpoint(next_sample_time: float) -> None:
        duration = float((app.info or {}).get("duration", 0.0) or 0.0)
        progress_state["resume_time"] = max(
            float(start_at), min(duration, float(next_sample_time or 0.0))
        )

    def report_candidates(raw_candidates: list[dict], done: int, total: int) -> None:
        if cancel.is_set():
            return
        now = time.monotonic()
        if done < total and last_candidate_emit_at[0] > 0.0 and now - last_candidate_emit_at[0] < 3.0:
            return
        # Attach JPEG evidence encoded from the already sampled OCR frames.
        # This refreshes result rows without launching another decoder process.
        prepared = _with_live_thumbnails(raw_candidates, force=False)
        last_candidate_emit_at[0] = now
        emit({"type": "cta_update", "payload": {
            "done": int(done), "total": int(total),
            "candidates": prepared, "found": len(prepared),
            "phase": progress_state["phase"],
            "resume_time": float(progress_state["resume_time"]),
        }})

    def report_phase(phase: str, done: int, total: int) -> None:
        phase_key = str(phase)
        progress_state["phase"] = phase_key
        # The detector reports the exact next sample through checkpoint(); do
        # not estimate progress from percentages because that can drift when a
        # resumed scan has a different sample count.
        now = time.monotonic()
        phase_changed = last_phase_emit_key[0] != phase_key
        if not (phase_changed or done >= total or now - last_phase_emit_at[0] >= 0.5):
            return
        last_phase_emit_key[0] = phase_key
        last_phase_emit_at[0] = now
        labels = {
            "pass1": f"Quét từ khóa CTA toàn video · {interval:g} giây/ảnh",
            "done": "Hoàn tất quét từ khóa CTA",
        }
        emit({"type": "cta_phase", "payload": {
            "phase": phase_key, "label": labels.get(phase_key, phase_key),
            "done": int(done), "total": int(total),
            "resume_time": float(progress_state["resume_time"]),
        }})

    def on_paused() -> None:
        emit({"type": "cta_paused", "message": "Đã tạm dừng. Các khoảng CTA đã nhận diện vẫn được giữ nguyên.",
              "resume_time": float(progress_state["resume_time"]),
              "phase": str(progress_state["phase"])})

    def scan() -> None:
        global CTA_SCAN_RUNNING
        try:
            result = core.detect_cta_image_candidates(
                video_path, sample_interval=interval,
                max_samples=7200 if scan_mode == "deep" else 1800,
                scan_mode=scan_mode,
                start_at=start_at,
                cancel_event=cancel, pause_event=pause,
                progress_callback=report, pause_callback=on_paused,
                candidate_callback=report_candidates, phase_callback=report_phase,
                checkpoint_callback=checkpoint)
            candidates = _with_live_thumbnails(result.get("candidates", []), force=True)
            emit({"type": "cta_done", "payload": {
                "duration": float(result.get("duration", 0)),
                "samples": int(result.get("samples", 0)),
                "ocr_timeouts": int(result.get("ocr_timeouts", 0) or 0),
                "sample_interval": float(result.get("sample_interval", interval)),
                "requested_sample_interval": float(result.get("requested_sample_interval", interval)),
                "pass1_interval": float(result.get("pass1_interval", interval)),
                "pass2_interval": float(result.get("pass2_interval", 0.0) or 0.0),
                "pass2_requested_interval": float(result.get("pass2_requested_interval", 0.0) or 0.0),
                "sample_cap_reached": bool(result.get("sample_cap_reached", False)),
                "pass2_sample_cap_reached": bool(result.get("pass2_sample_cap_reached", False)),
                "pass1_sample_limit": int(result.get("pass1_sample_limit", 0) or 0),
                "candidates": candidates,
                "pass1_samples": int(result.get("pass1_samples", 0)),
                "pass2_samples": int(result.get("pass2_samples", 0)),
                "resume_time": float(result.get("duration", 0.0) or 0.0),
                "note": str(result.get("note", "")),
            }})
        except Exception as exc:
            if cancel.is_set() or isinstance(exc, getattr(core, "CTAScanCancelled", Exception)):
                emit({"type": "cta_cancelled", "message": str(exc) or "Đã dừng quét CTA. Các ứng viên đã phát hiện vẫn được giữ lại."})
            else:
                emit({"type": "cta_error", "message": str(exc)})
        finally:
            CTA_SCAN_RUNNING = False
            try:
                if app_instance is not None:
                    app_instance.cta_scan_running = False
            except Exception:
                pass

    CTA_SCAN_THREAD = threading.Thread(target=scan, name="QtCTAImageScan", daemon=True)
    CTA_SCAN_THREAD.start()
    return {
        "ok": True, "started": True, "interval": interval,
        "scan_mode": scan_mode,
        "max_samples": 120000,
    }


def _pause_cta_scan() -> dict:
    if CTA_SCAN_RUNNING and CTA_PAUSE_EVENT is not None:
        CTA_PAUSE_EVENT.set()
        return {"ok": True, "pause_requested": True}
    return {"ok": True, "pause_requested": False}


def _resume_cta_scan() -> dict:
    if CTA_SCAN_RUNNING and CTA_PAUSE_EVENT is not None:
        CTA_PAUSE_EVENT.clear()
        emit({"type": "cta_resumed", "message": "Đang tiếp tục quét từ vị trí đã tạm dừng…"})
        return {"ok": True, "resumed": True}
    return {"ok": True, "resumed": False}


def _cancel_cta_scan() -> dict:
    if CTA_CANCEL_EVENT is not None and CTA_SCAN_RUNNING:
        CTA_CANCEL_EVENT.set()
        if CTA_PAUSE_EVENT is not None:
            CTA_PAUSE_EVENT.clear()
        return {"ok": True, "cancelling": True}
    return {"ok": True, "cancelling": False}

def _prepare_cta_ranges(ranges: list[dict], duration: float) -> list[tuple[float, float]]:
    """Validate, clamp and merge user-approved CTA intervals without touching project state."""
    if duration <= 0:
        raise ValueError("Thời lượng video không hợp lệ.")
    proposed = []
    for raw in ranges or []:
        if not isinstance(raw, dict):
            raise ValueError("Dữ liệu khoảng Subscribe không hợp lệ.")
        try:
            start = float(raw.get("start", 0.0))
            end = float(raw.get("end", 0.0))
        except (TypeError, ValueError, OverflowError):
            raise ValueError("Mốc CTA phải là số hợp lệ.")
        if not (np.isfinite(start) and np.isfinite(end)):
            raise ValueError("Mốc CTA không được là NaN hoặc vô cực.")
        start = max(0.0, min(float(duration), start))
        end = max(0.0, min(float(duration), end))
        if end <= start or end - start < 0.05:
            raise ValueError("Một khoảng Subscribe không hợp lệ. Hãy kiểm tra mốc bắt đầu/kết thúc.")
        proposed.append((start, end))
    normalized = core.normalize_excluded_ranges(proposed, duration=duration)
    if not normalized:
        raise ValueError("Chưa có khoảng Subscribe hợp lệ được chọn.")
    return normalized


def _cut_cta_ranges(ranges: list[dict]) -> dict:
    app = app_instance
    if app is None or not app.video_path or not app.info:
        raise RuntimeError("Không có video nguồn để cắt CTA.")
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    if duration <= 0:
        raise RuntimeError("Không đọc được thời lượng video nguồn.")
    proposed = _prepare_cta_ranges(ranges, duration)
    old_ranges = list(getattr(app, "excluded_ranges", []) or [])
    app.excluded_ranges = core.normalize_excluded_ranges(old_ranges + proposed, duration=duration)
    app._mark_project_dirty()
    app.export_full()
    if not bool(app.busy):
        app.excluded_ranges = old_ranges
        app._mark_project_dirty()
        raise RuntimeError("Không thể bắt đầu xuất video. Các khoảng bỏ cũ đã được khôi phục.")
    return {"ok": True, "started": True, "selected_ranges": len(proposed),
            "removed_seconds": round(sum(end-start for start,end in proposed), 3)}


def _cut_manual_ranges(ranges: list[dict]) -> dict:
    """Remove multiple manually selected ranges and export the remaining video."""
    app = app_instance
    if app is None or not app.video_path or not app.info:
        raise RuntimeError("Không có video nguồn để cắt.")
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    proposed = []
    for item in ranges or []:
        start = max(0.0, float(item.get("start", 0.0)))
        end = min(duration, float(item.get("end", 0.0))) if duration else float(item.get("end", 0.0))
        if end <= start:
            raise ValueError("Một khoảng bỏ có mốc kết thúc không lớn hơn mốc bắt đầu.")
        proposed.append((start, end))
    proposed = core.normalize_excluded_ranges(proposed, duration=duration)
    if not proposed:
        raise ValueError("Chưa có khoảng nào được chọn để bỏ.")
    old_ranges = list(getattr(app, "excluded_ranges", []) or [])
    app.excluded_ranges = core.normalize_excluded_ranges(old_ranges + proposed, duration=duration)
    app._mark_project_dirty()
    app.export_full()
    if not bool(app.busy):
        app.excluded_ranges = old_ranges
        app._mark_project_dirty()
        raise RuntimeError("Không thể bắt đầu cắt. Các khoảng bỏ đã được khôi phục.")
    return {"ok": True, "started": True, "selected_ranges": len(proposed),
            "removed_seconds": round(sum(end - start for start, end in proposed), 3)}


def _start_mask_task(cmd: str) -> dict:
    """Run large mask creation away from the Tk event loop."""
    global MASK_TASK_ACTIVE, MASK_TASK_THREAD, MASK_TASK_TOKEN
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Hãy mở video và tải khung hình trước khi tạo Mask.")
    if len(app.lasso_points) < 3:
        raise ValueError("Hãy khoanh vùng logo, chữ hoặc banner trước.")
    if MASK_TASK_ACTIVE:
        raise RuntimeError("Một tác vụ Mask đang xử lý. Hãy chờ hoàn tất.")
    if bool(app.busy) or CTA_SCAN_RUNNING:
        raise RuntimeError("Engine đang bận. Hãy hoàn tất tác vụ hiện tại trước khi tạo Mask.")

    # Capture stable references/coordinates on the Tk thread. The frame itself
    # is read-only during analysis; other mutating commands are guarded below.
    frame_ref = app.frame
    points = tuple((int(x), int(y)) for x, y in app.lasso_points)
    canvas_points = tuple((float(x), float(y)) for x, y in app.canvas_points)
    video_path = str(app.video_path or "")
    old_mask_ref = app.mask
    token = uuid.uuid4().hex
    MASK_TASK_TOKEN = token
    MASK_TASK_ACTIVE = True
    app.mask_busy = True
    task_label = "Đang tự tách nét bằng GrabCut…" if cmd == "auto_extract" else "Đang tạo Mask từ vùng khoanh…"
    app.status_var.set(task_label)
    emit({"type": "mask_task_started", "payload": {"cmd": cmd, "message": task_label}})

    def calculate() -> None:
        try:
            # The undo snapshot copy is also done off the Tk thread.
            undo_snapshot = {
                "mask": old_mask_ref.copy() if old_mask_ref is not None else None,
                "lasso_points": list(points),
                "canvas_points": list(canvas_points),
            }
            if cmd == "auto_extract":
                result_mask, used_fallback = core.extract_text_mask(
                    frame_ref, list(points), return_info=True
                )
            elif cmd == "use_selection_mask":
                result_mask = core.polygon_to_mask(frame_ref.shape, list(points))
                used_fallback = False
            else:
                raise ValueError("Loại tác vụ Mask không hợp lệ.")
            pixel_count = int(cv2.countNonZero(result_mask))
            MASK_TASK_EVENTS.put({
                "token": token, "cmd": cmd, "frame_ref": frame_ref,
                "video_path": video_path, "points": points,
                "undo_snapshot": undo_snapshot, "mask": result_mask,
                "used_fallback": bool(used_fallback), "pixel_count": pixel_count,
                "error": "",
            })
        except Exception as exc:
            MASK_TASK_EVENTS.put({
                "token": token, "cmd": cmd, "frame_ref": frame_ref,
                "video_path": video_path, "points": points,
                "error": str(exc),
            })

    MASK_TASK_THREAD = threading.Thread(
        target=calculate, name="QtMaskBackgroundTask", daemon=True
    )
    try:
        MASK_TASK_THREAD.start()
    except Exception:
        MASK_TASK_ACTIVE = False
        MASK_TASK_THREAD = None
        MASK_TASK_TOKEN = ""
        app.mask_busy = False
        raise
    return {"ok": True, "started": True, "async": True, "task": cmd}


def _poll_mask_task_events() -> None:
    """Apply completed mask data on the Tk thread after background CV work."""
    global MASK_TASK_ACTIVE, MASK_TASK_THREAD, MASK_TASK_TOKEN
    try:
        event = MASK_TASK_EVENTS.get_nowait()
    except queue.Empty:
        return
    if event.get("token") != MASK_TASK_TOKEN:
        return

    app = app_instance
    MASK_TASK_ACTIVE = False
    MASK_TASK_THREAD = None
    MASK_TASK_TOKEN = ""
    if app is None:
        return
    app.mask_busy = False

    if event.get("error"):
        app.status_var.set("Không tạo được Mask: " + str(event["error"]))
        emit({"type": "mask_task_error", "message": str(event["error"])})
        return

    # Never apply a result to a different video or selection.
    if (app.frame is not event.get("frame_ref") or
            str(app.video_path or "") != str(event.get("video_path", "")) or
            tuple((int(x), int(y)) for x, y in app.lasso_points) != tuple(event.get("points", ()))):
        app.status_var.set("Đã bỏ kết quả Mask cũ vì video hoặc vùng khoanh đã thay đổi.")
        emit({"type": "mask_task_error", "message": "Video hoặc vùng khoanh đã thay đổi trong lúc xử lý. Hãy tạo lại Mask."})
        return

    snapshot = event["undo_snapshot"]
    app._mask_undo_stack.append(snapshot)
    if len(app._mask_undo_stack) > app._mask_undo_limit:
        app._mask_undo_stack.pop(0)
    app._mask_redo_stack.clear()
    app._brush_undo_pushed = False
    app.mask = event["mask"]
    app.show_mask.set(True)
    app._mask_clip_cache_key = None
    app._mask_clip_cache = None
    app._mark_project_dirty()

    pixel_count = int(event.get("pixel_count", 0))
    if event.get("cmd") == "auto_extract":
        if event.get("used_fallback"):
            status = (
                f"Không tách được nét riêng biệt; đã dùng toàn bộ vùng khoanh "
                f"({pixel_count:,} pixel). Có thể tinh chỉnh bằng Brush/Eraser."
            )
        else:
            status = (
                f"Đã tự tách Mask gồm {pixel_count:,} pixel. "
                f"Độ nới hiện tại: {app._effective_mask_expansion()} px."
            )
    else:
        status = (
            f"Đã tạo Mask từ vùng khoanh ({pixel_count:,} pixel). "
            f"Dùng Brush/Eraser để tinh chỉnh nếu cần."
        )
    app.status_var.set(status)
    _mark_preview_dirty()
    emit({"type": "mask_task_done", "payload": {
        "cmd": event.get("cmd", ""),
        "mask_pixels": pixel_count,
        "used_fallback": bool(event.get("used_fallback")),
        "message": status,
    }})


def _run_command(payload: dict) -> Any:
    app = app_instance
    cmd = str(payload.get("cmd", ""))
    if MASK_TASK_ACTIVE and cmd in {
        "set_selection", "mask_stroke", "use_selection_mask", "auto_extract",
        "clear_selection", "undo", "redo", "select_scene",
    }:
        raise RuntimeError("Mask đang được xử lý nền. Hãy chờ tác vụ hiện tại hoàn tất.")
    if cmd == "__stdin_closed__":
        return {"shutdown": True}
    if cmd == "state":
        return _snapshot()
    if cmd == "choose_video":
        _load_video(str(payload.get("path", "")))
    elif cmd == "open_project":
        _load_project(str(payload.get("path", "")))
    elif cmd == "save_project":
        _save_project(str(payload.get("path", "")) or None, bool(payload.get("save_as", False)))
    elif cmd == "choose_logo":
        _choose_logo(str(payload.get("path", "")))
    elif cmd == "choose_output":
        _choose_output(str(payload.get("path", "")))
    elif cmd == "set_frame_time":
        _set_frame_time(float(payload.get("seconds", 0.0)), bool(payload.get("preserve_mask", True)))
    elif cmd == "set_range":
        app.segment_start_var.set(str(payload.get("start", 0)))
        app.segment_end_var.set(str(payload.get("end", 0)))
        try:
            app.segment_from_minutes_var.set(str(float(payload.get("start", 0)) / 60.0))
            app.segment_to_minutes_var.set(str(float(payload.get("end", 0)) / 60.0))
        except Exception:
            pass
        app._timeline_redraw()
        app._mark_project_dirty()
    elif cmd == "set_selection":
        _set_selection(payload.get("points", []), str(payload.get("shape", "lasso")))
    elif cmd == "mask_stroke":
        _mask_stroke(payload.get("points", []), bool(payload.get("erase", False)))
    elif cmd == "set_mask_tool":
        app.set_mask_tool(str(payload.get("mode", "lasso")))
    elif cmd == "set_brush_size":
        app.mask_brush_size_var.set(max(4, min(100, int(payload.get("value", 24)))))
    elif cmd == "set_expansion":
        app.expansion_var.set(max(0, min(30, int(payload.get("value", 14)))))
        app._on_expansion_manual_changed()
        app._mark_project_dirty()
        _mark_preview_dirty()
    elif cmd == "set_auto_expansion":
        app.auto_mask_expansion_var.set(bool(payload.get("value", True)))
        app._on_mask_mode_changed(reset_override=False)
        app._mark_project_dirty()
        _mark_preview_dirty()
    elif cmd == "set_show_mask":
        app.show_mask.set(bool(payload.get("value", True)))
        _mark_preview_dirty()
    elif cmd == "use_selection_mask":
        return _start_mask_task("use_selection_mask")
    elif cmd == "auto_extract":
        return _start_mask_task("auto_extract")
    elif cmd == "clear_selection":
        app.clear_selection()
        _mark_preview_dirty()
    elif cmd == "undo":
        app.undo_mask()
        _mark_preview_dirty()
    elif cmd == "redo":
        app.redo_mask()
        _mark_preview_dirty()
    elif cmd == "select_scene":
        app._scene_card_select(int(payload.get("index", 0)))
        _mark_preview_dirty()
    elif cmd == "add_scene":
        app.segment_start_var.set(str(payload.get("start", app.segment_start_var.get())))
        app.segment_end_var.set(str(payload.get("end", app.segment_end_var.get())))
        app.add_scene()
    elif cmd == "update_scene":
        if payload.get("start") is not None:
            start = float(payload.get("start"))
            app.segment_start_var.set(str(start))
            app.segment_from_minutes_var.set(str(start / 60.0))
        if payload.get("end") is not None:
            end = float(payload.get("end"))
            app.segment_end_var.set(str(end))
            app.segment_to_minutes_var.set(str(end / 60.0))
        app.update_selected_scene()
    elif cmd == "split_scene":
        if payload.get("seconds") is not None:
            app.frame_time_var.set(str(payload["seconds"]))
        app.split_selected_scene()
    elif cmd == "delete_scene":
        app.delete_selected_scene()
    elif cmd == "branding_state":
        return _branding_state()
    elif cmd == "branding_preview":
        return _branding_preview(payload)
    elif cmd == "branding_apply":
        return _branding_apply(payload)
    elif cmd == "branding_preset_save":
        return _branding_preset_save(payload)
    elif cmd == "branding_preset_load":
        return _branding_preset_load(payload)
    elif cmd == "branding_preset_delete":
        return _branding_preset_delete(payload)
    elif cmd == "compare_frame":
        return _compare_frame()
    elif cmd == "batch_start":
        return _start_batch(payload.get("files", []), str(payload.get("output_folder", "")))
    elif cmd == "batch_cancel":
        return _cancel_batch()
    elif cmd == "batch_cta_start":
        return _start_batch_cta(
            payload.get("files", []), str(payload.get("output_folder", "")),
            bool(payload.get("resume_existing", False)),
        )
    elif cmd == "batch_cta_stop":
        return _stop_batch_cta()
    elif cmd == "open_branding":
        app.open_branding_studio()
    elif cmd == "open_cta_detector":
        # Compatibility command for older shells; the current Qt shell embeds CTA in its workspace.
        app.open_cta_detection()
    elif cmd == "cta_scan_start":
        return _start_cta_scan(
            float(payload.get("interval", 1.0)),
            str(payload.get("scan_mode", "balanced")),
            float(payload.get("start_at", 0.0) or 0.0),
        )
    elif cmd == "cta_scan_pause":
        return _pause_cta_scan()
    elif cmd == "cta_scan_resume":
        return _resume_cta_scan()
    elif cmd == "cta_scan_cancel":
        return _cancel_cta_scan()
    elif cmd == "cta_cache_thumbnails":
        return _cta_cache_thumbnails(payload.get("candidates", []))
    elif cmd == "cta_cut_selected":
        return _cut_cta_ranges(payload.get("ranges", []))
    elif cmd == "cta_preview_start":
        return _start_cta_preview(float(payload.get("start", 0.0)), float(payload.get("end", 0.0)))
    elif cmd == "cta_preview_stop":
        return _stop_cta_preview()
    elif cmd == "video_preview_start":
        return _start_video_preview(float(payload.get("start", 0.0)), float(payload.get("end", 0.0)))
    elif cmd == "video_preview_stop":
        return _stop_cta_preview()
    elif cmd == "open_compare":
        app.open_mask_comparison()
    elif cmd == "capture_preview":
        path = str(payload.get("path", ""))
        if path:
            _with_dialog_value("asksaveasfilename", path, app.capture_preview_frame)
        else:
            app.capture_preview_frame()
    elif cmd == "open_batch":
        app.open_batch_dialog()
    elif cmd == "open_qc":
        app.open_quality_check_dialog()
    elif cmd == "open_merge":
        app.open_merge_dialog()
    elif cmd == "export_preview":
        if payload.get("start") is not None:
            app.preview_start_var.set(str(max(0.0, float(payload.get("start", 0.0)))))
        app.export_preview()
    elif cmd == "export_segment":
        # Atomic In/Out update plus export; avoids two-message ordering races from Qt.
        if payload.get("start") is not None or payload.get("end") is not None:
            current_start = float(core.safe_float(app.segment_start_var.get(), "Mốc bắt đầu") or 0.0)
            current_end = float(core.safe_float(app.segment_end_var.get(), "Mốc kết thúc") or 0.0)
            start = float(payload.get("start", current_start))
            end = float(payload.get("end", current_end))
            if not (start >= 0.0 and end > start):
                raise ValueError("Khoảng xuất không hợp lệ: mốc kết thúc phải lớn hơn mốc bắt đầu.")
            duration = float((app.info or {}).get("duration", 0.0) or 0.0)
            if duration and end > duration + 0.05:
                raise ValueError(f"Mốc kết thúc vượt thời lượng video ({duration:.2f} giây).")
            app.segment_start_var.set(str(start))
            app.segment_end_var.set(str(end))
            app.segment_from_minutes_var.set(f"{start / 60.0:.4f}".rstrip("0").rstrip("."))
            app.segment_to_minutes_var.set(f"{end / 60.0:.4f}".rstrip("0").rstrip("."))
            app._timeline_redraw()
            app._mark_project_dirty()
        app.export_segment()
    elif cmd == "cut_ranges":
        return _cut_manual_ranges(payload.get("ranges", []))
    elif cmd == "export_full":
        app.export_full()
    elif cmd == "stop_export":
        if getattr(app, "batch_active", False):
            app._batch_stop()
        else:
            app.stop_export()
    elif cmd == "gpu_check":
        app.check_gpu_status()
    elif cmd == "set_autosave":
        app.autosave_enabled_var.set(bool(payload.get("value", True)))
        app._on_autosave_setting_changed()
    elif cmd == "shutdown":
        return {"shutdown": True}
    else:
        raise ValueError(f"Lệnh chưa hỗ trợ: {cmd}")
    return {"ok": True}


def _poll_commands() -> None:
    global shutdown_requested
    try:
        while True:
            payload = COMMANDS.get_nowait()
            request_id = payload.get("id")
            try:
                result = _run_command(payload)
                emit({"type": "reply", "id": request_id, "result": result})
                if isinstance(result, dict) and result.get("shutdown"):
                    shutdown_requested = True
            except Exception as exc:
                emit({"type": "reply", "id": request_id,
                      "error": str(exc), "trace": traceback.format_exc(limit=5)})
    except queue.Empty:
        pass
    _poll_mask_task_events()
    if shutdown_requested:
        if BATCH_CTA_CANCEL_EVENT is not None:
            BATCH_CTA_CANCEL_EVENT.set()
        if BATCH_CTA_THREAD is not None and BATCH_CTA_THREAD.is_alive():
            root.after(100, _poll_commands)
            return
        if BATCH_SCAN_RUNNING and BATCH_CANCEL_EVENT is not None:
            BATCH_CANCEL_EVENT.set()
        if CTA_PREVIEW_STOP_EVENT is not None:
            CTA_PREVIEW_STOP_EVENT.set()
        try:
            if app_instance and app_instance.busy:
                app_instance.stop_export()
        except Exception:
            pass
        try:
            thumb_executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        try:
            root.destroy()
        except Exception:
            pass
        return
    root.after(35, _poll_commands)


def _publish_state() -> None:
    try:
        emit({"type": "state", "payload": _snapshot()})
    except Exception:
        emit({"type": "worker_warning", "message": traceback.format_exc(limit=3)})
    if not shutdown_requested:
        root.after(450, _publish_state)


def _set_background_priority() -> str:
    """Yield CPU scheduling to foreground apps (e.g. games) on Windows."""
    try:
        if os.name == "nt":
            import ctypes
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.GetCurrentProcess.restype = ctypes.c_void_p
            kernel32.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            kernel32.SetPriorityClass.restype = ctypes.c_int
            handle = kernel32.GetCurrentProcess()
            # BELOW_NORMAL_PRIORITY_CLASS: FFmpeg children inherit the worker priority.
            if kernel32.SetPriorityClass(handle, 0x00004000):
                return "BELOW_NORMAL"
            return f"UNCHANGED(winerror={ctypes.get_last_error()})"
        try:
            os.nice(5)
            return "NICE+5"
        except Exception:
            return "DEFAULT"
    except Exception:
        return "DEFAULT"


def main() -> int:
    global app_instance, root
    priority_mode = _set_background_priority()
    # Keep stdout reserved for JSON protocol; legacy logs go to stderr.
    sys.stdout = sys.stderr
    root = tk.Tk()
    root.withdraw()
    app_instance = core.VideoToolApp(root)
    root.withdraw()
    # Export completion reports are forwarded to the Qt shell instead of opening a second legacy report window.
    app_instance._show_quality_report = lambda report: emit({"type": "qc_report", "payload": report})
    threading.Thread(target=reader, name="QtBridgeReader", daemon=True).start()
    emit({"type": "engine_ready", "version": core.APP_VERSION, "priority_mode": priority_mode,
          "opencv_threads": 2})
    root.after(40, _poll_commands)
    root.after(300, _publish_state)
    root.mainloop()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc(file=sys.stderr)
        raise

