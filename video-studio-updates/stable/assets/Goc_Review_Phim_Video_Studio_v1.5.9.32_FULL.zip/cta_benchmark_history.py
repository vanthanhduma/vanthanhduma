from __future__ import annotations

import json
import math
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1


def benchmark_history_directory() -> Path:
    """Return a per-user store, separate from project CTA caches and temp files."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return base / "GocReviewPhim" / "cta_benchmark_history"


def _inside_root(path: Path, root: Path) -> Path:
    resolved = path.expanduser().resolve()
    base = root.expanduser().resolve()
    try:
        resolved.relative_to(base)
    except ValueError:
        raise ValueError("Đường dẫn lịch sử benchmark nằm ngoài thư mục lưu trữ cho phép.") from None
    return resolved


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, bytes):
        return None
    if isinstance(value, dict):
        return {
            str(key): safe
            for key, item in value.items()
            if not str(key).startswith("_") and str(key) != "preview_path"
            for safe in [_json_safe(item)]
            if safe is not None
        }
    if isinstance(value, (list, tuple)):
        return [safe for item in value if (safe := _json_safe(item)) is not None]
    return str(value)


def _write_json_atomic(path: Path, document: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    payload = json.dumps(document, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    temporary.write_text(payload, encoding="utf-8")
    os.replace(temporary, path)


def create_benchmark_history(
    *,
    video_path: str,
    start_at: float,
    end_at: float,
    results: list[dict],
    expected_cta_count: int = 0,
    source_version: str = "",
    cancelled: bool = False,
    root: Path | str | None = None,
) -> dict:
    """Persist one benchmark run, copying evidence thumbnails into its own folder."""
    store = Path(root) if root is not None else benchmark_history_directory()
    store.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc)
    run_id = uuid.uuid4().hex
    run_folder = store / (now.strftime("%Y%m%d_%H%M%S") + "_" + run_id[:8])
    evidence_root = run_folder / "evidence"
    evidence_root.mkdir(parents=True, exist_ok=False)

    source = Path(str(video_path or "")).expanduser()
    video = {
        "path": str(source),
        "name": source.name if str(video_path or "") else "Không rõ video",
        "size_bytes": None,
        "modified_ns": None,
    }
    try:
        stat = source.stat()
        video["size_bytes"] = int(stat.st_size)
        video["modified_ns"] = int(stat.st_mtime_ns)
    except OSError:
        pass

    profiles = []
    for raw_profile in results or []:
        profile = _json_safe({
            key: value for key, value in dict(raw_profile).items()
            if key != "candidates"
        })
        profile_candidates = []
        profile_index = int(raw_profile.get("profile_index", len(profiles) + 1) or 1)
        for candidate_index, raw_candidate in enumerate(raw_profile.get("candidates", []) or []):
            candidate = _json_safe({
                key: value for key, value in dict(raw_candidate).items()
                if key not in {"preview_path", "_preview_jpeg", "_preview_confidence", "_preview_sample_time"}
            })
            candidate["review_label"] = max(0, min(2, int(raw_candidate.get("review_label", 0) or 0)))
            preview_source = Path(str(raw_candidate.get("preview_path", "") or ""))
            if preview_source.is_file():
                relative = Path("evidence") / f"profile_{profile_index}" / f"candidate_{candidate_index:04d}{preview_source.suffix or '.jpg'}"
                destination = run_folder / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(preview_source, destination)
                    candidate["evidence_file"] = relative.as_posix()
                except OSError:
                    candidate["evidence_file"] = ""
            else:
                candidate["evidence_file"] = ""
            profile_candidates.append(candidate)
        profile["candidates"] = profile_candidates
        profiles.append(profile)

    document = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "created_at": now.isoformat(timespec="seconds"),
        "app_version": str(source_version or ""),
        "video": video,
        "segment": {"start_seconds": float(start_at), "end_seconds": float(end_at)},
        "expected_cta_count": max(0, int(expected_cta_count or 0)),
        "cancelled": bool(cancelled),
        "profiles": profiles,
    }
    history_file = run_folder / "benchmark.json"
    _write_json_atomic(history_file, document)
    return load_benchmark_history(history_file, root=store)


def save_benchmark_history(
    history_file: str | Path,
    document: dict,
    *,
    root: Path | str | None = None,
) -> Path:
    """Atomically update labels/expected counts without rewriting evidence images."""
    store = Path(root) if root is not None else benchmark_history_directory()
    path = _inside_root(Path(history_file), store)
    if path.name != "benchmark.json" or not path.parent.is_dir():
        raise ValueError("Tệp lịch sử benchmark không hợp lệ.")
    existing = json.loads(path.read_text(encoding="utf-8"))
    if int(existing.get("schema_version", 0)) != SCHEMA_VERSION:
        raise ValueError("Phiên bản dữ liệu lịch sử benchmark không được hỗ trợ.")
    safe_document = _json_safe(document)
    safe_document["schema_version"] = SCHEMA_VERSION
    safe_document["run_id"] = existing.get("run_id", safe_document.get("run_id", ""))
    safe_document["created_at"] = existing.get("created_at", safe_document.get("created_at", ""))
    _write_json_atomic(path, safe_document)
    return path


def load_benchmark_history(
    history_file: str | Path,
    *,
    root: Path | str | None = None,
) -> dict:
    store = Path(root) if root is not None else benchmark_history_directory()
    path = _inside_root(Path(history_file), store)
    if path.name != "benchmark.json" or not path.is_file():
        raise FileNotFoundError("Không tìm thấy bản ghi lịch sử benchmark.")
    document = json.loads(path.read_text(encoding="utf-8"))
    if int(document.get("schema_version", 0)) != SCHEMA_VERSION:
        raise ValueError("Phiên bản dữ liệu lịch sử benchmark không được hỗ trợ.")
    run_folder = path.parent.resolve()
    for profile in document.get("profiles", []) or []:
        for candidate in profile.get("candidates", []) or []:
            relative = str(candidate.get("evidence_file", "") or "")
            if not relative:
                candidate["preview_path"] = ""
                continue
            image_path = _inside_root(run_folder / relative, run_folder)
            candidate["preview_path"] = str(image_path) if image_path.is_file() else ""
    document["_history_path"] = str(path)
    return document


def list_benchmark_history(*, root: Path | str | None = None) -> list[dict]:
    store = Path(root) if root is not None else benchmark_history_directory()
    if not store.is_dir():
        return []
    records = []
    for path in store.glob("*/benchmark.json"):
        try:
            records.append(load_benchmark_history(path, root=store))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    return sorted(records, key=lambda item: str(item.get("created_at", "")), reverse=True)


def delete_benchmark_history(
    history_file: str | Path,
    *,
    root: Path | str | None = None,
) -> None:
    store = Path(root) if root is not None else benchmark_history_directory()
    path = _inside_root(Path(history_file), store)
    if path.name != "benchmark.json" or not path.is_file():
        raise FileNotFoundError("Không tìm thấy bản ghi lịch sử benchmark.")
    folder = _inside_root(path.parent, store)
    if folder.parent != store.resolve():
        raise ValueError("Không thể xóa thư mục lịch sử không hợp lệ.")
    shutil.rmtree(folder)
