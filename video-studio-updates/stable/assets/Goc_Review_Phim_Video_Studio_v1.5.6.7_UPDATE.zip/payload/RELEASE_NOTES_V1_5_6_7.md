# Góc Review Phim Video Studio v1.5.6.7

## Overlay Detector parity với CTA

- Thêm **Tạm dừng / Tiếp tục** cho lượt quét lớp phủ, giữ kết quả khi tạm dừng.
- Giữ thumbnail xem lại, danh sách ứng viên và thao tác đưa vùng đang chọn vào Mask ngay trong workspace.
- Overlay vẫn áp dụng theo vùng hình ảnh; CTA vẫn xử lý theo khoảng thời gian để cắt, đúng bản chất từng chức năng.
- Không mở cửa sổ riêng và không thay đổi dữ liệu dự án, cài đặt hoặc môi trường xử lý.
