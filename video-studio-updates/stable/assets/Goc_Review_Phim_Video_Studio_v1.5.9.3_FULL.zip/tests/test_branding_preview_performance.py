from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import cv2
import numpy as np

import engine_worker


class _Value:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value


class BrandingPreviewPerformanceTests(unittest.TestCase):
    def test_4k_preview_builds_overlay_only_at_ui_resolution_once(self):
        source = np.zeros((2160, 3840, 3), dtype=np.uint8)
        fake_app = SimpleNamespace(
            frame=source,
            info={"duration": 600.0},
            frame_time_var=_Value("30"),
            logo_path="",
            _branding_text=lambda: "Tập 1",
        )
        observed = {}

        def build_components(width, height, logo_path, label_text, config):
            observed["component_size"] = (width, height)
            logo = np.zeros((height, width, 4), dtype=np.uint8)
            label = np.zeros_like(logo)
            logo[10:30, 20:40, 3] = 255
            return logo, label

        def apply_overlay(frame, mask, expansion, overlay):
            observed["apply_size"] = (frame.shape[1], frame.shape[0])
            observed["overlay_size"] = (overlay.shape[1], overlay.shape[0])
            self.assertIsNone(mask)
            self.assertEqual(expansion, 0)
            return frame

        with tempfile.TemporaryDirectory(prefix="gocreview-branding-preview-") as temp:
            with (
                mock.patch.object(engine_worker, "app_instance", fake_app),
                mock.patch.object(engine_worker, "STATE_DIR", Path(temp)),
                mock.patch.object(
                    engine_worker.core, "build_branding_components",
                    side_effect=build_components,
                ) as components,
                mock.patch.object(
                    engine_worker.core, "build_overlay",
                    side_effect=AssertionError("Preview must not build the full-size overlay twice."),
                ),
                mock.patch.object(
                    engine_worker.core, "apply_mask_and_overlay",
                    side_effect=apply_overlay,
                ),
            ):
                result = engine_worker._branding_preview({
                    "config": {"show_from": 0.0, "show_to": 600.0},
                    "logo_path": "",
                    "label_text": "Tập 1",
                    "preview_token": 17,
                })

            self.assertEqual(components.call_count, 1)
            self.assertEqual(observed["component_size"], (1280, 720))
            self.assertEqual(observed["apply_size"], (1280, 720))
            self.assertEqual(observed["overlay_size"], (1280, 720))
            self.assertEqual(result["frame_width"], 3840)
            self.assertEqual(result["frame_height"], 2160)
            self.assertEqual(result["preview_width"], 1280)
            self.assertEqual(result["preview_height"], 720)
            self.assertEqual(result["logo_rect"], [60, 30, 120, 90])
            preview_path = Path(result["preview_path"])
            self.assertTrue(preview_path.is_file())
            preview = cv2.imread(str(preview_path))
            self.assertIsNotNone(preview)
            self.assertEqual(preview.shape[:2], (720, 1280))


if __name__ == "__main__":
    unittest.main()
