from __future__ import annotations


def _box_iou(a: dict, b: dict) -> float:
    try:
        ax, ay, aw, ah = (float(a.get(k, 0) or 0) for k in ("x", "y", "w", "h"))
        bx, by, bw, bh = (float(b.get(k, 0) or 0) for k in ("x", "y", "w", "h"))
    except (TypeError, ValueError):
        return 0.0
    if aw <= 0 or ah <= 0 or bw <= 0 or bh <= 0:
        return 0.0
    intersection_w = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    intersection_h = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    intersection = intersection_w * intersection_h
    union = aw * ah + bw * bh - intersection
    return intersection / union if union > 0 else 0.0


def merge_boundary_candidate(existing: dict, incoming: dict, max_gap: float = 2.25) -> dict | None:
    """Join two detections only when they are temporally adjacent and spatially the same CTA.

    This is used only when continuing a previously interrupted/partial scan. It
    avoids splitting one persistent Subscribe banner into two rows at a checkpoint
    while leaving unrelated detections alone.
    """
    try:
        old_start, old_end = float(existing.get("start", 0)), float(existing.get("end", 0))
        new_start, new_end = float(incoming.get("start", 0)), float(incoming.get("end", 0))
    except (TypeError, ValueError):
        return None
    gap = max(0.0, max(old_start, new_start) - min(old_end, new_end))
    if gap > max(0.0, float(max_gap)):
        return None
    if _box_iou(existing, incoming) < 0.12:
        return None

    old_terms = {str(value).strip().upper() for value in existing.get("terms", []) if str(value).strip()}
    new_terms = {str(value).strip().upper() for value in incoming.get("terms", []) if str(value).strip()}
    if old_terms and new_terms and not (old_terms & new_terms):
        return None

    merged = dict(existing)
    merged["start"] = round(min(old_start, new_start), 3)
    merged["end"] = round(max(old_end, new_end), 3)
    merged["duration"] = round(max(0.0, merged["end"] - merged["start"]), 3)
    merged["confidence"] = round(max(float(existing.get("confidence", 0) or 0),
                                      float(incoming.get("confidence", 0) or 0)), 1)
    merged["peak_confidence"] = round(max(float(existing.get("peak_confidence", existing.get("confidence", 0)) or 0),
                                           float(incoming.get("peak_confidence", incoming.get("confidence", 0)) or 0)), 1)
    # Live updates are cumulative snapshots, not independent samples. Use max
    # to avoid counting the same later-scan samples again on every UI refresh.
    merged["samples"] = max(int(existing.get("samples", 1) or 1), int(incoming.get("samples", 1) or 1))
    ordered_terms = [term for term in ("LIKE", "SHARE", "SUBSCRIBE") if term in old_terms | new_terms]
    merged["terms"] = ordered_terms or list(dict.fromkeys(list(existing.get("terms", []) or []) + list(incoming.get("terms", []) or [])))
    merged["evidence"] = sorted(set(existing.get("evidence", []) or []) | set(incoming.get("evidence", []) or []))
    merged["label"] = " · ".join(merged["terms"] or [existing.get("label") or incoming.get("label") or "CTA"])
    if str(incoming.get("text", "")).strip() and float(incoming.get("confidence", 0) or 0) >= float(existing.get("confidence", 0) or 0):
        merged["text"] = incoming.get("text")
    if str(incoming.get("preview_path", "") or "").strip() and (
        not str(existing.get("preview_path", "") or "").strip()
        or float(incoming.get("confidence", 0) or 0) >= float(existing.get("confidence", 0) or 0)
    ):
        merged["preview_path"] = incoming.get("preview_path")
        merged["sample_time"] = incoming.get("sample_time", existing.get("sample_time"))
    if not merged.get("location") or merged.get("location") == "—":
        merged["location"] = incoming.get("location", "—")
    return merged
