# Góc Review Phim Video Studio v1.5.9.7

**Minimal Studio · Downloader · Overlay Detector · Subscribe CTA Detector · Batch CTA Processing · Stable Updater**

## Phiên bản
- **Stable:** v1.5.9.7
- **Bản nền UPDATE:** v1.5.9.6
- **Source repository:** `vanthanhduma/Goc-Review-Phim-Video-Studio` (private)
- **Public update feed:** [Stable latest.json](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json)

## Cải tiến v1.5.9.7 — Global UI Polish
- Đồng bộ typography trên tất cả workspace: Branding, Mask/Before-After, CTA Detector, Downloader, Batch CTA, Ghép video và Xuất & kiểm tra.
- Tăng nhẹ cỡ chữ cơ sở lên 10.5 pt, dùng Segoe UI với fallback tiếng Việt phù hợp; phân cấp rõ tiêu đề, nhãn, nút, tab và bảng.
- Đặt bề mặt QLabel, checkbox, radio, slider, group box, frame và vùng nội dung dạng stack trong suốt khi không phải card/ô nhập liệu, tránh các dải nền đen phía sau chữ.
- Nới vùng tên dự án và tên video trên thanh công cụ, vẫn giữ tooltip đường dẫn đầy đủ.
- Không thay đổi bố cục chức năng, Engine commands, detector, FFmpeg pipeline, project/Auto Save, backup hoặc updater.

## Cải tiến v1.5.9.6 — Export Typography Polish
- Đồng bộ font UI về Segoe UI (fallback font hệ thống phù hợp), cỡ chữ cơ sở 10.1 pt và weight Medium.
- Đặt nền QLabel trong suốt để chữ nằm trực tiếp trên card, loại bỏ các dải nền đen sau tiêu đề và trạng thái.
- Chuẩn hóa độ lớn/độ đậm cho tiêu đề nhóm, metadata, timecode, bảng khoảng cắt và nút thao tác.
- Sửa hiển thị dấu “&” trong nút “Cắt bỏ & xuất phần còn lại” bằng helper escape mnemonic của Qt.
- Giữ nguyên bố cục workspace, logic cắt, preview, thư mục đầu ra, QC và pipeline xuất.

## Cải tiến v1.5.9.5 — Export & Quality Workspace
- Tách trang **Xuất & kiểm tra** thành workspace riêng, không còn dồn toàn bộ thao tác vào panel cuộn bên phải.
- Preview và thanh vị trí phát nằm ở cột trung tâm; danh sách khoảng cắt, điều khiển Từ–Đến và xem video gốc/xem thử đặt ngay bên dưới.
- Thêm timeline trực quan: màu cyan là phần giữ lại, vùng gạch chéo màu cam là phần sẽ cắt; nhấp timeline để chuyển tới thời điểm tương ứng.
- Cột phải tập trung vào thư mục xuất, xuất toàn bộ, cắt bỏ các khoảng đã chọn, kiểm tra chất lượng và dừng tác vụ.
- Giữ nguyên các lệnh Engine đang có; không thêm giả các lựa chọn codec/FPS/độ phân giải mà backend chưa cung cấp.

## Cải tiến v1.5.9.4 — Smooth Studio Branding Drag
- Tách ảnh nền preview và logo trong suốt thành hai lớp độc lập.
- Qt vẽ và di chuyển lớp logo trực tiếp theo chuột; không gọi Engine khi rê chuột.
- Giữ điểm nắm trên logo, giới hạn logo trong khung video và chỉ gửi một lần cập nhật khi thả chuột.
- Preview cuối cùng vẫn được Engine dựng lại để đồng bộ cấu hình; chất lượng video xuất không thay đổi.

## Cải tiến v1.5.9.3 — Studio Branding Preview Performance
- Studio Branding dựng preview ở tối đa 1280×720 thay vì dựng nhiều lớp ảnh ở độ phân giải gốc 4K rồi mới thu nhỏ.
- Chỉ tạo lớp logo/nhãn một lần trong mỗi preview; không dựng lại overlay đầy đủ lần thứ hai.
- Gom các thay đổi slider/toggle, tối đa một preview đang chạy và chỉ xử lý trạng thái mới nhất.
- Giữ tọa độ logo theo khung video gốc để kéo/thả chính xác.
- Không thay đổi độ phân giải hoặc chất lượng video xuất, preset, phạm vi thời gian và cấu hình theo phân cảnh.

## Cải tiến v1.5.9.2 — Project Toolbar & Backup History
- Đưa Mở dự án, Lưu, Lưu thành, Lịch sử sao lưu, Nhập ZIP và Đóng gói ZIP thành các nút riêng luôn hiển thị trên thanh công cụ phía trên.
- Bỏ menu Dự án dạng nút xổ xuống để thao tác dự án không còn bị ẩn.
- Chuyển icon Công cụ video xuống đúng nút điều hướng, đồng bộ với CTA Detector, Mask và Branding; tiêu đề nhóm chỉ còn chữ.
- Lịch sử sao lưu luôn mở được, kể cả khi chưa lưu dự án thủ công hoặc chưa có mốc nào; hộp thoại giải thích rõ trạng thái thay vì bị khóa.
- Giữ nguyên khôi phục an toàn thành dự án mới, giới hạn tối đa 8 mốc và quy tắc Auto Save không tự tạo snapshot.

## Cải tiến v1.5.9.1 — Batch CTA & Backup History UI
- Làm lại bố cục Batch CTA theo các vùng tiêu đề, hàng đợi, thư mục project và tiến độ; bổ sung icon cho các thao tác thường dùng.
- Thêm icon cho tiêu đề nhóm **CÔNG CỤ VIDEO** ở sidebar.
- Đưa nút khôi phục lịch sử sao lưu lên thanh tiêu đề của hộp thoại.
- Không tự chọn bản sao lưu khi mở; người dùng click/Enter vào một mốc để bật nút khôi phục, sau đó xác nhận.
- Khôi phục vẫn tạo và mở một project mới, không ghi đè project hiện tại.
- Không thay đổi thuật toán nhận diện CTA, quy tắc quét tuần tự hoặc quyền duyệt/cắt thủ công.

## Batch CTA Processing (kế thừa từ v1.5.9.0)
- Thêm nhiều video hoặc thêm toàn bộ thư mục vào một hàng đợi.
- Chọn một thư mục lưu dự án; Batch CTA quét tuần tự từng video bằng CTA Detector hiện có.
- Mỗi video được lưu thành một file `.grproj` riêng, kèm CTA cache, mốc thời gian, độ tin cậy và thumbnail bằng chứng.
- Video nguồn vẫn ở vị trí ban đầu, không bị sao chép vào thư mục dự án.
- Hàng đợi được lưu an toàn. Có thể tiếp tục các video chưa hoàn thành; các video đã hoàn thành được bỏ qua.
- Khi hoàn tất toàn bộ, ứng dụng trở về workspace Video Tools. Dừng thủ công vẫn giữ trang Batch để có thể tiếp tục.

## Cách duyệt và cắt video
Batch CTA chỉ làm nhiệm vụ quét và lưu dự án. Người dùng mở từng dự án, xem ảnh bằng chứng và mốc thời gian, sau đó tự chọn các khoảng cần cắt rồi xuất video. Ứng dụng không tự phê duyệt ứng viên và không tự động cắt.

CTA Detector chỉ xử lý nội dung hiển thị trong hình ảnh/video; không phân tích âm thanh hoặc lời nói.

## Các chức năng được giữ lại
- Biên tập và phân cảnh; Mask và Before/After.
- Branding, Downloader, Overlay Detector.
- CTA Subscribe Detector và duyệt thủ công trước khi cắt.
- Xuất MP4, kiểm tra chất lượng (QC), lưu/mở dự án, Auto Save và lịch sử sao lưu.
- Lệnh Batch export cũ vẫn được giữ trong engine để tương thích.

## Dữ liệu và an toàn
- Dự án Batch CTA dùng schema v4 và cache CTA trong bố cục hiện có.
- Video nguồn được tham chiếu theo đường dẫn/fingerprint; không nhân bản.
- Không ghi đè projects, autosave, settings, branding cá nhân, downloads, renders, video nguồn, output hoặc môi trường `.venv`.
- Updater xác minh HTTPS + SHA-256, sao lưu trước khi áp dụng và hỗ trợ rollback.

## Cài đặt và cập nhật
- Máy đang ở **v1.5.9.6** cập nhật trực tiếp lên **v1.5.9.7** bằng nút **Kiểm tra & cập nhật**.
- Máy đang ở **v1.5.9.5** cần nâng cấp lên v1.5.9.6 trước, sau đó mới lên v1.5.9.7.
- Máy đang ở **v1.5.9.4** cần nâng cấp lên v1.5.9.5, sau đó v1.5.9.6 rồi mới lên v1.5.9.7.
- Máy đang ở **v1.5.9.3** cần nâng cấp theo thứ tự v1.5.9.4 → v1.5.9.5 → v1.5.9.6 → v1.5.9.7.
- Máy đang ở **v1.5.8.0** cần nâng cấp theo lộ trình cũ trước khi lên v1.5.9.7.
- Gói UPDATE không phải bộ cài mới; không giải nén thủ công đè lên thư mục ứng dụng.
- Máy mới sử dụng gói FULL riêng.

## Kiểm thử
- Windows E2E: hai MP4 tổng hợp, OCR nhận SUBSCRIBE và LIKE; Batch quét tuần tự, lưu hai project, cache và thumbnail, sau đó mở lại project và xác nhận ứng viên được nạp vào giao diện.
- Qt/Engine smoke test và Batch CTA queue/project tests: PASS.
- E2E tổng hợp xác minh pipeline tự động; vẫn cần người dùng xem lại kết quả trên video thực tế trước khi cắt.
