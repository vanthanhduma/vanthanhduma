from __future__ import annotations

import sys
import tempfile
import threading
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import download_engine as de


class URLValidationTests(unittest.TestCase):
    def test_supported_youtube_urls(self):
        valid = [
            "https://www.youtube.com/watch?v=abc123",
            "https://youtu.be/abc123",
            "https://www.youtube.com/shorts/abc123",
            "https://www.youtube.com/live/abc123",
        ]
        for url in valid:
            with self.subTest(url=url):
                self.assertEqual(de.validate_video_url(url), url)
                self.assertEqual(de.detect_platform(url), "YouTube")

    def test_supported_facebook_urls(self):
        valid = [
            "https://www.facebook.com/reel/123456",
            "https://www.facebook.com/watch/?v=123456",
            "https://www.facebook.com/share/r/abcdef/",
            "https://fb.watch/abcdef/",
        ]
        for url in valid:
            with self.subTest(url=url):
                self.assertEqual(de.validate_video_url(url), url)
                self.assertEqual(de.detect_platform(url), "Facebook")

    def test_rejects_playlist_channel_and_untrusted_hosts(self):
        invalid = [
            "https://www.youtube.com/playlist?list=PL123",
            "https://www.youtube.com/@somechannel",
            "https://www.facebook.com/profile.php?id=123",
            "https://facebook.com.evil.example/reel/123",
            "file:///C:/video.mp4",
            "",
        ]
        for url in invalid:
            with self.subTest(url=url), self.assertRaises(ValueError):
                de.validate_video_url(url)


class FormatSelectorTests(unittest.TestCase):
    def test_best_quality_uses_separate_streams_when_ffmpeg_available(self):
        self.assertEqual(de._format_selector(None, False, True), "bestvideo*+bestaudio/best")

    def test_resolution_limit_is_applied(self):
        selector = de._format_selector(1080, False, True)
        self.assertIn("height<=1080", selector)
        self.assertNotIn("height<=720", selector)

    def test_no_ffmpeg_uses_single_file(self):
        self.assertEqual(de._format_selector(None, False, False), "best")
        self.assertIn("best[ext=mp4]", de._format_selector(None, True, False))


class FakeYoutubeDL:
    last_options = None

    def __init__(self, options):
        self.options = options
        FakeYoutubeDL.last_options = options

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def extract_info(self, url, download=True):
        self.options["progress_hooks"][0]({
            "status": "downloading", "downloaded_bytes": 50, "total_bytes": 100,
            "speed": 1024 * 1024, "eta": 2,
        })
        self.options["progress_hooks"][0]({"status": "finished"})
        return {"id": "abc123", "title": "Video test", "height": 1080, "ext": "mp4"}


class DownloadAdapterTests(unittest.TestCase):
    def test_download_passes_local_browser_cookie_and_reports_progress(self):
        fake_module = types.SimpleNamespace(YoutubeDL=FakeYoutubeDL)
        events = []
        with tempfile.TemporaryDirectory() as folder, \
             patch.dict(sys.modules, {"yt_dlp": fake_module}), \
             patch.object(de, "_resolve_ffmpeg", return_value="/fake/ffmpeg.exe"):
            result = de.download_video(
                "https://www.youtube.com/watch?v=abc123", folder,
                browser="chrome", progress_callback=events.append,
            )
        self.assertEqual(result["title"], "Video test")
        self.assertEqual(FakeYoutubeDL.last_options["cookiesfrombrowser"], ("chrome", None, None, None))
        self.assertTrue(FakeYoutubeDL.last_options["continuedl"])
        self.assertFalse(FakeYoutubeDL.last_options["nopart"])
        self.assertFalse(FakeYoutubeDL.last_options["overwrites"])
        self.assertEqual(events[0]["percent"], 50)
        self.assertEqual(events[-1]["status"], "finished")

    def test_cancel_before_start(self):
        fake_module = types.SimpleNamespace(YoutubeDL=FakeYoutubeDL)
        event = threading.Event(); event.set()
        with tempfile.TemporaryDirectory() as folder, \
             patch.dict(sys.modules, {"yt_dlp": fake_module}):
            with self.assertRaises(de.DownloadCancelled):
                de.download_video("https://youtu.be/abc123", folder, cancel_event=event)


if __name__ == "__main__":
    unittest.main()
