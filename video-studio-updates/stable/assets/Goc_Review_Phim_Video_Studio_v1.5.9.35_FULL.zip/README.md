# Góc Review Phim – Video Studio

**Stable hiện tại: v1.5.9.34** · Windows 10/11 · Python 3.11+

Góc Review Phim Video Studio là ứng dụng desktop hỗ trợ biên tập video review phim, quản lý dự án, xử lý watermark/branding, phát hiện CTA hiển thị và xuất video.

- **Stable update feed:** [latest.json](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json)
- **Repository nguồn:** `vanthanhduma/Goc-Review-Phim-Video-Studio` (private)
- **Release notes mới nhất:** [v1.5.9.34](RELEASE_NOTES_V1_5_9_34.md)

## Chức năng chính

- **Biên tập & phân cảnh:** xem video, quản lý dự án và các khoảng cần xử lý.
- **Làm sạch – Mask:** xử lý watermark/logo theo vùng và phân cảnh.
- **Studio Branding:** bố trí logo, nhãn và branding trên video.
- **CTA Detector:** quét CTA xuất hiện trong hình ảnh/video, xem bằng chứng và duyệt thủ công; không tự động cắt.
- **Batch CTA Processing:** đưa nhiều video vào hàng đợi, lưu project riêng và tiếp tục xử lý.
- **Tải video:** quản lý tác vụ tải, trạng thái và tiếp tục tải khi nguồn hỗ trợ.
- **Xuất & kiểm tra:** xem trước, nhập và duyệt khoảng cắt, xem timeline, xuất video và kiểm tra chất lượng đầu ra.
- **Dự án & sao lưu:** lưu/mở project, Auto Save, lịch sử sao lưu và đóng gói ZIP.
- **Stable Updater:** kiểm tra phiên bản, xác minh SHA-256 và cập nhật ứng dụng.

## Phiên bản Stable v1.5.9.34

### CTA Results Table Readability
- Chuyển phần tiêu đề, chọn đoạn, mô tả chiến lược và bảng kết quả vào vùng cuộn; trạng thái, tiến trình và nút thao tác luôn nằm ở chân hộp thoại.
- Tự giới hạn chiều rộng/chiều cao theo vùng hiển thị khả dụng và căn giữa cửa sổ để không che mất phần tiêu đề hoặc trường nhập trên màn hình có DPI/kích thước nhỏ.
- Giữ nguyên các chế độ benchmark và dữ liệu; không thay đổi detector, ngưỡng nhận diện, cache CTA chính hoặc Batch CTA.

### CTA Two-Strategy Benchmark & History
- Thêm nút **So sánh hiệu năng** trong CTA Detector để kiểm thử một đoạn video, không phải quét lại toàn bộ video dài.
- So sánh đúng hai chiến lược: **2 giây/ảnh, một lượt** và **4 giây/ảnh lượt đầu + 1 giây/ảnh lượt hai tại vùng nghi vấn**.
- Cả hai dùng chung OCR balanced và nhận diện đồ họa Subscribe; bảng ghi thời gian, số ảnh từng lượt, tổng ảnh, số ứng viên và confidence trung bình.
- Cho phép duyệt ứng viên Đúng CTA/Nhận diện nhầm. Khi nhập số sự kiện CTA thật trong đoạn, bảng tính Precision, Recall và F1; confidence không thay thế độ chính xác thật.
- Kết quả benchmark tách biệt, không ghi đè cache CTA chính, không tự động chọn hoặc cắt khoảng.
- Mỗi lần kiểm thử tự lưu lịch sử JSON cùng ảnh bằng chứng, video/đoạn nguồn, số liệu và nhãn đánh giá; có thể mở lại, sửa nhãn hoặc xóa riêng từng bản ghi.
- Giới hạn kết thúc được áp dụng trực tiếp trong detector; bộ test xác nhận không quét tiếp phần video ngoài đoạn đã chọn.

### Giữ nguyên CTA Detector v1.5.9.29
- Giữ quét toàn video mặc định 0,5 giây/ảnh với OCR balanced/adaptive fallback và nhận diện đồ họa Subscribe.
- Batch CTA giữ nguyên xử lý tuần tự và duyệt thủ công trước khi cắt.

## Nền tảng giao diện từ v1.5.9.28

### Unified Studio UI & Direct Source Player
- Bỏ bước render clip tạm; nút mở video sử dụng trực tiếp file gốc và trình phát mặc định của hệ điều hành.
- Đồng bộ ngôn ngữ giao diện navy/teal/cyan trên thanh tiêu đề, sidebar, workspace, card, nút, tab, bảng, biểu mẫu, menu và hộp thoại.
- Chuẩn hóa trạng thái hover/selected/disabled/focus, độ tương phản, viền, bo góc, khoảng đệm và thanh cuộn trên các workspace.
- Giữ nguyên bố cục thao tác, tính năng, pipeline xử lý/xuất video, dự án và dữ liệu người dùng.
- Duy trì các tinh chỉnh Studio Branding từ v1.5.9.26.
- Tinh chỉnh bảng Branding theo dạng Studio gọn, cân đối; bốn tab Logo/Nhãn/Thời gian/Preset giãn đều theo chiều rộng bảng điều khiển.
- Thu gọn inspector, cải thiện card, trường nhập, checkbox và slider; dành thêm không gian cho khung Preview.
- Giữ nguyên kéo logo trực tiếp, kích thước/độ trong suốt/xoay/vị trí, nội dung và màu nhãn, thời gian, phạm vi phân cảnh và Preset.
- Đổi thao tác xem video gốc sang ứng dụng phát video mặc định của hệ điều hành; không ép gọi ffplay. Video mở ở trình phát ngoài, có thể tua, thoát toàn màn hình và đóng bằng điều khiển sẵn có của trình phát.
- Giữ nguyên pipeline preview Engine, lệnh xuất, cấu hình video và dữ liệu dự án.

### Các bản trước
- **v1.5.9.31:** bổ sung lịch sử benchmark CTA có thể mở lại, kèm ảnh bằng chứng và nhãn đánh giá.
- **v1.5.9.25:** làm mới Xuất & kiểm tra, gom preview/phát lại, quản lý khoảng cắt, timeline, thư mục đầu ra và QC.

### Các bản gần đây
- **v1.5.9.30:** bổ sung benchmark so sánh hai chiến lược quét CTA trên đoạn video.
- **v1.5.9.24:** làm mới Studio Branding và tổ chức lại Xuất & kiểm tra; bỏ thao tác cắt trực tiếp khỏi CTA Detector.
- **v1.5.9.23:** cải thiện bố cục Downloader và trạng thái sidebar theo kích thước cửa sổ.
- **v1.5.9.22:** cải thiện tải video, kiểm tra luồng hình sau tải và nhãn Branding.

Các release notes và biên bản kiểm thử phiên bản cũ được lưu trong `docs/releases/` và `docs/testing/`. Tài liệu phát triển, workflow CI và bộ test được giữ trong repository nhưng không đưa vào gói cài đặt.

## Cài đặt trên Windows

1. Tải gói **FULL** từ [Stable update feed](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json) và giải nén toàn bộ vào một thư mục riêng, ví dụ `D:\GocReviewVideoStudio`.
2. Chạy `CAI_DAT_VA_CHAY.bat` để tạo môi trường `.venv` và cài thư viện cần thiết.
3. Khi cài xong, mở bằng shortcut Desktop hoặc `MO_GOC_REVIEW_PHIM.vbs`.
4. Cài Tesseract OCR bằng `CAI_TESSERACT_OCR.bat` khi cần OCR cho CTA Detector. Bộ dữ liệu ngôn ngữ English và Vietnamese được cung cấp trong `assets/tessdata`.

**Cập nhật phiên bản:** mở ứng dụng → **Kiểm tra, cập nhật**. Không giải nén gói UPDATE đè thủ công lên thư mục đang chạy.

## Dữ liệu người dùng

Updater và gói cài đặt được cấu hình để không ghi đè các vùng dữ liệu cá nhân như `.venv`, `projects`, `downloads`, `renders`, `logs`, `autosave`, `_backups`, `assets/user` và `user_settings.json`.

Không xóa các thư mục dự án, autosave, tải xuống hoặc sao lưu nếu chúng đang chứa dữ liệu cần giữ. Video Studio không kèm FFmpeg system; có thể cài/tải FFmpeg riêng khi cần.

## Cấu trúc repository

- `app.py`, `qt_app.py`, `engine_worker.py`: ứng dụng và engine.
- `updater/`: kiểm tra, xác minh và áp dụng bản cập nhật.
- `assets/`: logo, icon và dữ liệu OCR được đóng gói.
- `tests/`: kiểm thử hồi quy, UI smoke test và Batch CTA (chỉ có trong source).
- `tools/`: công cụ đóng gói FULL/UPDATE (chỉ có trong source).
- `docs/releases/`: lịch sử phát hành.
- `docs/testing/`: biên bản kiểm thử các phiên bản.
- `docs/`: đặc tả, tài liệu kỹ thuật và hướng dẫn hỗ trợ.
- `RELEASE_NOTES_V1_5_9_31.md`: ghi chú bản phát hành hiện tại; các bản cũ nằm trong `docs/releases/` và `docs/testing/`.

## Kiểm thử phát hành

Quy trình phát hành v1.5.9.31 kiểm tra compile, Branding workspace, luồng mở video bằng trình phát mặc định, các workspace chính, Qt UI/engine smoke test và bộ hồi quy hiện có. Gói FULL/UPDATE được kiểm tra cấu trúc ZIP và SHA-256 trước khi xuất bản Stable.


## Bản chuẩn bị Stable v1.5.9.35

- Đưa toàn bộ So sánh hiệu năng CTA, Lịch sử kiểm thử và trang xem lại kết quả vào chính tab CTA hiện có; thao tác không mở cửa sổ riêng.
- Giữ nguyên ba profile benchmark 2 / 3 / 4 giây, biểu đồ đánh giá, ảnh bằng chứng và lịch sử đã lưu.
- Tinh chỉnh Gap Watcher để tích lũy biến đổi hình ảnh nhỏ/fade-in so với khung neo gần nhất; bỏ qua scene cut lớn và đặt lại khung neo để tiếp tục theo dõi ở cảnh mới.
- Giữ lượt quét chính 4 giây/ảnh và phân tích OCR + đồ họa ở các mốc nghi vấn; không giảm chất lượng nhận diện để đổi lấy tốc độ.
- Batch CTA hiển thị thống kê riêng cho từng video: ảnh lượt chính, mẫu Gap Watcher, số lần chuyển sang phân tích sâu, OCR timeout, số CTA và thời gian xử lý.
- Cho phép thử lại đúng video bị lỗi trong hàng đợi đã lưu; các project hoàn thành và trạng thái lỗi của video khác được giữ nguyên.
- Không tự duyệt hoặc tự cắt CTA; người dùng vẫn kiểm tra thủ công trước khi đưa khoảng vào danh sách cắt.
