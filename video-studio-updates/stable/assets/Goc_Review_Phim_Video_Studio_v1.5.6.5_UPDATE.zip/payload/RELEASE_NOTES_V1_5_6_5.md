# Góc Review Phim Video Studio v1.5.6.5

## Navigation Naming Cleanup

- Đổi workspace sidebar thành **Dựng video**.
- Đổi inspector thành **Thuộc tính cảnh**.
- Giữ **Phân cảnh** riêng cho timeline.
- Loại bỏ cảm giác trùng tên giữa điều hướng, timeline và inspector; không thay đổi chức năng xử lý.
