# Góc Review Phim Video Studio v1.5.6.21

## CTA Subscribe

- Quét kỹ đọc OCR trực tiếp trên từng vùng nút đỏ đã phát hiện, kể cả khi OCR toàn khung hình không đọc được.
- Gộp nhãn `SUBSCRIBE` / `SUBSCRIBED` vào cùng ứng viên đồ họa, tránh một CTA bị tách thành hai loại kết quả.
- Giữ nguyên chế độ quét thường để không làm chậm các video dài.
