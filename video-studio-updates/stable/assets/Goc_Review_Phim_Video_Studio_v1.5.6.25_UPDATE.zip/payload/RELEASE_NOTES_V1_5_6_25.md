# Góc Review Phim Video Studio v1.5.6.25

## Cắt nhiều khoảng

- Thêm nhiều khoảng Từ–Đến vào danh sách rồi cắt bỏ trong một lần.
- Video xuất ra giữ phần còn lại, nối hình và tiếng đồng bộ; video gốc không bị ghi đè.

## Phát video gốc

- Nút xem gốc mở thẳng file nguồn bằng trình phát video native (`ffplay` nếu có, nếu không dùng trình phát mặc định của Windows).
- Không còn giải mã/ghi JPEG từng frame trong Studio cho thao tác xem video gốc, tránh lag với video dài.
