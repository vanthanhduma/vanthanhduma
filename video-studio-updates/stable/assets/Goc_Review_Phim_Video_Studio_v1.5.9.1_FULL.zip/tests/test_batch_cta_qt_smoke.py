from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QPoint, QTimer, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QDialog

from qt_app import MainWindow, ProjectBackupHistoryDialog


def main() -> int:
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    result = {"code": 1, "checked": False}

    def finish(code: int, message: str) -> None:
        result["code"] = code
        result["checked"] = True
        print(message, flush=True)
        window.close()
        QTimer.singleShot(250, app.quit)

    def check_ready() -> None:
        if not window.engine_ready:
            detail = ""
            try:
                if window._worker_log_path.is_file():
                    detail = window._worker_log_path.read_text(encoding="utf-8", errors="replace")[-4000:]
            except Exception:
                pass
            finish(1, "Qt engine did not become ready. " + detail)
            return
        if not hasattr(window, "batch_table") or window.batch_table.columnCount() != 4:
            finish(1, "Batch CTA page is missing or does not expose four queue columns.")
            return
        if not hasattr(window, "batch_open_project_btn") or not hasattr(window, "batch_start_btn"):
            finish(1, "Batch CTA controls are missing.")
            return

        # Exercise the actual backup history dialog: no implicit selection,
        # restore action stays in the top header, and selecting a row enables it.
        try:
            with tempfile.TemporaryDirectory(prefix="gocreview-backup-ui-") as temp:
                backups = []
                for index in range(2):
                    path = Path(temp) / f"Project_backup_{index + 1}.grproj"
                    path.write_text("{}", encoding="utf-8")
                    backups.append(path)

                dialog = ProjectBackupHistoryDialog(backups, window)
                dialog.show()
                app.processEvents()

                if dialog.items.selectedItems() or dialog.selected_backup or dialog.restore_button.isEnabled():
                    raise AssertionError("Backup history must open with no snapshot selected and restore disabled.")

                button_y = dialog.restore_button.mapTo(dialog, QPoint(0, 0)).y()
                list_y = dialog.items.mapTo(dialog, QPoint(0, 0)).y()
                if button_y >= list_y:
                    raise AssertionError("Backup restore button must be aligned in the top dialog header.")

                second_item = dialog.items.item(1)
                item_rect = dialog.items.visualItemRect(second_item)
                QTest.mouseClick(
                    dialog.items.viewport(), Qt.MouseButton.LeftButton, pos=item_rect.center()
                )
                app.processEvents()
                if not dialog.restore_button.isEnabled():
                    raise AssertionError("Selecting a backup snapshot must enable the top restore button.")
                if dialog.selected_backup != str(backups[1]):
                    raise AssertionError("Selected backup path does not match the highlighted row.")

                dialog.restore_button.click()
                if dialog.result() != QDialog.DialogCode.Accepted:
                    raise AssertionError("Restore button did not accept the selected backup.")
                dialog.close()
        except Exception as exc:
            finish(1, "Backup history UI smoke test failed: " + str(exc))
            return

        finish(0, "Windows Qt/engine smoke test passed: engine ready, Batch CTA controls wired, backup history explicit selection and top restore button passed.")

    QTimer.singleShot(20000, lambda: (None if result["checked"] else finish(1, "Timed out waiting for Qt engine startup.")))
    poll = QTimer()
    poll.setInterval(100)
    poll.timeout.connect(lambda: check_ready() if window.engine_ready and not result["checked"] else None)
    poll.start()
    app.exec()
    return int(result["code"])


if __name__ == "__main__":
    raise SystemExit(main())
