# Góc Review Phim Video Studio v1.5.6.3

## Studio Workspace Structure

- Tách CTA Subscribe thành workspace riêng để danh sách ứng viên, thumbnail xem lại và thao tác cắt không bị thu nhỏ trong timeline.
- Sidebar trở thành nơi điều hướng duy nhất với sáu khu vực: Biên tập & Phân cảnh, Tải Video, CTA Subscribe, Mask & Before / After, Branding, Xuất video & QC.
- Giữ một hàng thao tác dự án cố định cho Mở video, Mở dự án, Ghép video, Xử lý nhiều video, Lưu dự án, Lưu thành và Xuất video.
- Timeline biên tập chỉ còn quản lý phân cảnh; không lặp CTA hoặc thao tác dự án.
- Giữ nguyên engine, dự án, Auto Save, branding, mask, QC, xuất video, dữ liệu tải xuống và môi trường `.venv`.

## Kiểm tra

- Python compile: PASS.
- Điều hướng sáu workspace: PASS.
- CTA workspace độc lập, timeline chỉ còn một tab Phân cảnh: PASS.
- Thanh thao tác dự án hiển thị nhất quán ở mọi workspace: PASS.
