from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class UnifiedWorkspaceLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt = (ROOT / "qt_app.py").read_text(encoding="utf-8")
        cls.core = (ROOT / "app.py").read_text(encoding="utf-8")

    def test_version_is_consistent(self):
        self.assertIn('APP_VERSION = _load_app_version()', self.qt)
        self.assertRegex((ROOT / 'PHIEN_BAN.txt').read_text(encoding='utf-8'), r'v1\.5\.6\.\d+')
        self.assertIn('APP_VERSION', self.core)

    def test_edit_and_mask_have_distinct_inspector_pages(self):
        self.assertIn('self.inspector_stack.addWidget(self._build_edit_tab())', self.qt)
        self.assertIn('self.inspector_stack.addWidget(self._build_watermark_tab())', self.qt)
        self.assertIn('"edit": (0, "Thuộc tính cảnh")', self.qt)
        self.assertIn('"mask": (1, "Làm sạch · Mask & Before / After")', self.qt)

    def test_cta_is_a_timeline_tab_not_a_sidebar_or_workspace_page(self):
        self.assertIn('self.cta_page = self._build_cta_page()', self.qt)
        self.assertIn('self.workspace_stack.addWidget(self.cta_page)', self.qt)
        self.assertIn('self.cta_page = self._build_cta_page()', self.qt)
        self.assertIn('def _cta_start_scan(self):', self.qt)
        self.assertIn('def _cta_cut_selected(self):', self.qt)

    def test_before_after_uses_large_central_preview(self):
        self.assertIn('self.compare_before_large = FitPixmapLabel()', self.qt)
        self.assertIn('self.compare_after_large = FitPixmapLabel()', self.qt)
        self.assertIn('self.preview_tabs.addTab(compare_page, "Before / After")', self.qt)
        self.assertIn('self.preview_tabs.setCurrentIndex(1)', self.qt)
        self.assertIn('Tạo & xem so sánh lớn', self.qt)

    def test_quick_tips_are_removed_and_sidebar_is_system_status_only(self):
        self.assertNotIn('QLabel("Mẹo nhanh")', self.qt)
        self.assertNotIn('Mở video → chia cảnh → xử lý Mask/CTA → xuất MP4.', self.qt)
        self.assertIn('Trạng thái hệ thống', self.qt)
        self.assertIn('self.sidebar_engine_status', self.qt)
        self.assertIn('self.sidebar_autosave_status', self.qt)
        self.assertIn('self.resource_hint', self.qt)


    def test_seek_previews_selected_time_while_dragging(self):
        self.assertIn('self.seek.sliderMoved.connect(self._seek_preview_position)', self.qt)
        self.assertIn('def _seek_preview_position(self, milliseconds: int):', self.qt)
        self.assertIn('preview_time = self.seek.value() / 1000.0', self.qt)

    def test_project_save_and_export_controls_are_preserved(self):
        self.assertIn('self.save_btn = QPushButton("Lưu dự án")', self.qt)
        self.assertIn('self.save_as_btn = QPushButton("Lưu thành")', self.qt)
        self.assertIn('self.export_top_btn = QPushButton("Xuất video")', self.qt)
        self.assertIn('more_menu.addAction("Xử lý nhiều video")', self.qt)


    def test_cta_has_pause_resume_and_stop_controls(self):
        self.assertIn('self.cta_pause_btn = QPushButton("Tạm dừng")', self.qt)
        self.assertIn('self.cta_pause_btn.setText("Tiếp tục")', self.qt)
        self.assertIn('self.send("cta_scan_pause")', self.qt)
        self.assertIn('self.send("cta_scan_resume")', self.qt)
        self.assertIn('self.cta_stop_btn = QPushButton("Dừng quét")', self.qt)

    def test_manual_cut_plays_original_video_without_scene_controls(self):
        self.assertIn('Cắt thủ công · Từ–Đến (phút)', self.qt)
        self.assertIn('Phát video gốc Từ–Đến', self.qt)
        self.assertNotIn('QPushButton("Thêm cảnh")', self.qt)
        self.assertNotIn('QPushButton("Tách cảnh")', self.qt)
        self.assertNotIn('QPushButton("Xóa cảnh")', self.qt)
        worker = (ROOT / 'engine_worker.py').read_text(encoding='utf-8')
        self.assertIn('video_preview_start', worker)
        self.assertIn('if len(paths) > 8:', worker)

    def test_cta_live_results_are_rendered_while_scanning(self):
        self.assertIn('elif msg_type == "cta_update":', self.qt)
        self.assertIn('def _cta_live_update(self, payload):', self.qt)
        self.assertIn('đã phát hiện {len(self.cta_candidates)} khoảng CTA', self.qt)
        self.assertIn('candidate_callback=report_candidates', (ROOT / "engine_worker.py").read_text(encoding="utf-8"))

    def test_cta_worker_supports_pause_resume_commands(self):
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn('elif cmd == "cta_scan_pause":', worker)
        self.assertIn('elif cmd == "cta_scan_resume":', worker)
        self.assertIn('pause_event=pause', worker)

    def test_subscribe_detector_supports_visual_and_vietnamese_cta(self):
        detector = (ROOT / "cta_detector.py").read_text(encoding="utf-8")
        self.assertIn('"SUBSCRIBE"', detector)
        self.assertIn('"DANGKY"', detector)
        self.assertIn('_find_graphic_subscribe_buttons', detector)
        self.assertIn('phase_callback=report_phase', (ROOT / "engine_worker.py").read_text(encoding="utf-8"))
        self.assertIn('vie.traineddata', detector)
        self.assertIn('pytesseract>=0.3.13', (ROOT / "requirements.txt").read_text(encoding="utf-8"))

    def test_seek_slider_supports_direct_click_and_timecode_entry(self):
        self.assertIn('class ClickSeekSlider(QSlider)', self.qt)
        self.assertIn('self.seek.sliderReleased.connect(self._seek_released)', self.qt)
        self.assertIn('self.seek_input.returnPressed.connect(self._seek_from_timecode)', self.qt)
        self.assertIn('self._seek_to_seconds(self.seek.value() / 1000.0)', self.qt)
        self.assertIn('self.seek.setRange(0, max(1, int(round(duration * 1000))))', self.qt)
        self.assertIn('if not self.seek.isSliderDown():', self.qt)


if __name__ == "__main__":
    unittest.main()
