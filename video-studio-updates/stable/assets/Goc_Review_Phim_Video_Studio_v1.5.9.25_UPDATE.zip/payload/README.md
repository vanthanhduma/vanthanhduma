# Góc Review Phim – Video Studio

**Stable hiện tại: v1.5.9.25** · Windows 10/11 · Python 3.11+

Góc Review Phim Video Studio là ứng dụng desktop hỗ trợ biên tập video review phim, quản lý dự án, xử lý watermark/branding, phát hiện CTA hiển thị và xuất video.

- **Stable update feed:** [latest.json](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json)
- **Repository nguồn:** `vanthanhduma/Goc-Review-Phim-Video-Studio` (private)
- **Release notes mới nhất:** [v1.5.9.25](RELEASE_NOTES_V1_5_9_25.md)

## Chức năng chính

- **Biên tập & phân cảnh:** xem video, quản lý dự án và các khoảng cần xử lý.
- **Làm sạch – Mask:** xử lý watermark/logo theo vùng và phân cảnh.
- **Studio Branding:** bố trí logo, nhãn và branding trên video.
- **CTA Detector:** quét CTA xuất hiện trong hình ảnh/video, xem bằng chứng và duyệt thủ công; không tự động cắt.
- **Batch CTA Processing:** đưa nhiều video vào hàng đợi, lưu project riêng và tiếp tục xử lý.
- **Tải video:** quản lý tác vụ tải, trạng thái và tiếp tục tải khi nguồn hỗ trợ.
- **Xuất & kiểm tra:** xem trước, nhập và duyệt khoảng cắt, xem timeline, xuất video và kiểm tra chất lượng đầu ra.
- **Dự án & sao lưu:** lưu/mở project, Auto Save, lịch sử sao lưu và đóng gói ZIP.
- **Stable Updater:** kiểm tra phiên bản, xác minh SHA-256 và cập nhật ứng dụng.

## Phiên bản Stable v1.5.9.25

### Xuất & QC Workspace Refinement
- Gom preview và thanh tua vào cùng một nhóm.
- Tách rõ nhập mốc bắt đầu/kết thúc, thêm/xóa khoảng và bảng các khoảng cắt.
- Đưa timeline thành bước kiểm tra phần giữ lại/phần sẽ cắt.
- Nhóm thư mục đầu ra, kiểu xuất và kiểm tra chất lượng riêng biệt.
- Thêm vùng cuộn độc lập cho cột nội dung và cột thiết lập để hạn chế control bị khuất ở cửa sổ thấp hoặc DPI khác nhau.
- Giữ nguyên Engine command, callback và pipeline xuất video hiện có.

### Các bản gần đây
- **v1.5.9.24:** làm mới Studio Branding và tổ chức lại Xuất & kiểm tra; bỏ thao tác cắt trực tiếp khỏi CTA Detector.
- **v1.5.9.23:** cải thiện bố cục Downloader và trạng thái sidebar theo kích thước cửa sổ.
- **v1.5.9.22:** cải thiện tải video, kiểm tra luồng hình sau tải và nhãn Branding.

Các release notes và biên bản kiểm thử phiên bản cũ được lưu trong `docs/releases/` và `docs/testing/`. Tài liệu phát triển, workflow CI và bộ test được giữ trong repository nhưng không đưa vào gói cài đặt.

## Cài đặt trên Windows

1. Tải gói **FULL** từ [Stable update feed](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json) và giải nén toàn bộ vào một thư mục riêng, ví dụ `D:\GocReviewVideoStudio`.
2. Chạy `CAI_DAT_VA_CHAY.bat` để tạo môi trường `.venv` và cài thư viện cần thiết.
3. Khi cài xong, mở bằng shortcut Desktop hoặc `MO_GOC_REVIEW_PHIM.vbs`.
4. Cài Tesseract OCR bằng `CAI_TESSERACT_OCR.bat` khi cần OCR cho CTA Detector. Bộ dữ liệu ngôn ngữ English và Vietnamese được cung cấp trong `assets/tessdata`.

**Cập nhật phiên bản:** mở ứng dụng → **Kiểm tra, cập nhật**. Không giải nén gói UPDATE đè thủ công lên thư mục đang chạy.

## Dữ liệu người dùng

Updater và gói cài đặt được cấu hình để không ghi đè các vùng dữ liệu cá nhân như `.venv`, `projects`, `downloads`, `renders`, `logs`, `autosave`, `_backups`, `assets/user` và `user_settings.json`.

Không xóa các thư mục dự án, autosave, tải xuống hoặc sao lưu nếu chúng đang chứa dữ liệu cần giữ. Video Studio không kèm FFmpeg system; có thể cài/tải FFmpeg riêng khi cần.

## Cấu trúc repository

- `app.py`, `qt_app.py`, `engine_worker.py`: ứng dụng và engine.
- `updater/`: kiểm tra, xác minh và áp dụng bản cập nhật.
- `assets/`: logo, icon và dữ liệu OCR được đóng gói.
- `tests/`: kiểm thử hồi quy, UI smoke test và Batch CTA (chỉ có trong source).
- `tools/`: công cụ đóng gói FULL/UPDATE (chỉ có trong source).
- `docs/releases/`: lịch sử phát hành.
- `docs/testing/`: biên bản kiểm thử các phiên bản.
- `docs/`: đặc tả, tài liệu kỹ thuật và hướng dẫn hỗ trợ.
- `RELEASE_NOTES_V1_5_9_25.md`: ghi chú bản phát hành hiện tại; các bản cũ nằm trong `docs/releases/` và `docs/testing/`.

## Kiểm thử phát hành

Quy trình phát hành v1.5.9.25 đã kiểm tra compile, Export & Quality workspace layout, global UI theme, các workspace chính, Qt UI/engine smoke test và Batch CTA Windows end-to-end. Gói FULL/UPDATE được kiểm tra cấu trúc ZIP và SHA-256 trước khi xuất bản Stable.
