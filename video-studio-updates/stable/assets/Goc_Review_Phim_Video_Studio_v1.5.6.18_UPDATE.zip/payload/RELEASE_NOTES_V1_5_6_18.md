# Góc Review Phim Video Studio v1.5.6.18

## CTA Subscribe

- Khóa chiều cao phần mô tả để không che hoặc ép co thumbnail xem lại.
- Dòng trạng thái sau khi quét được rút gọn, phần ghi chú dài chuyển vào tooltip.
- Giữ đầy đủ mô tả chi tiết khi rê chuột hoặc chọn nội dung để sao chép.
