# Góc Review Phim Video Studio v1.5.6.14

## Xem lại trước khi cắt CTA

- Thêm nút `Xem đoạn đã chọn` ngay dưới thumbnail CTA.
- Phát video gốc từ mốc bắt đầu đến mốc kết thúc của ứng viên đang chọn, không mở cửa sổ phụ và không render file trung gian.
- Có thể dừng xem bất kỳ lúc nào; khi hết đoạn, trình xem tự dừng và trả lại thumbnail ứng viên.
- Khóa mốc bắt đầu/kết thúc trong lúc xem để tránh thay đổi phạm vi giữa chừng.
