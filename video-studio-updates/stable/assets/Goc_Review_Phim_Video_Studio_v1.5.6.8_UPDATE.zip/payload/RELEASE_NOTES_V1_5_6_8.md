# Góc Review Phim Video Studio v1.5.6.8

## Cấu trúc workspace

- Đưa `Xử lý nhiều video` vào tab `Dự án → Xử lý hàng loạt`, không mở cửa sổ Tk legacy.
- Hàng đợi có thêm video, xóa, đổi thứ tự, chọn thư mục xuất, dừng an toàn và báo cáo QC tổng hợp.
- Giữ `Ghép video`, tạo bản sao dự án và kiểm tra cập nhật trong menu `Thêm` để thanh trên không bị trùng chức năng.

## Tên gọi và khả năng đọc

- Chuẩn hóa các nhãn `Dự án`, `Dựng video`, `Làm sạch · Mask`, `Thương hiệu`, `Xuất & kiểm tra`.
- Đổi nút xuất đoạn thành `Xuất đoạn Từ–Đến`, làm rõ khác biệt với cảnh đã lưu và xuất toàn bộ.
- Tăng độ tương phản cho ô nhập, bảng, vùng cuộn và trạng thái focus trên nền navy tối.

## An toàn dữ liệu

- Xử lý hàng loạt dùng cấu hình Mask/Brand đang có và ghi kết quả sang thư mục xuất riêng.
- Không thay đổi thư mục dự án, cài đặt, virtualenv hoặc dữ liệu người dùng.
- Bản cập nhật vẫn đi qua kiểm tra manifest/SHA-256, backup trước khi thay file và health-check/rollback của updater.
