# Góc Review Phim Video Studio v1.5.6.16

## CTA Subscribe

- Thêm chế độ `Quét kỹ`: lấy mẫu dày hơn trên toàn video và quét rất dày quanh vùng có dấu hiệu Subscribe, phù hợp CTA ngắn hoặc chuyển động nhanh.
- Thêm ô `Tìm trong kết quả` để tìm theo chữ OCR, vị trí, phương pháp và bằng chứng nhận diện.
- Thêm bộ lọc `Có chữ OCR`, `Nút / biểu tượng`, `Có chuyển động` và `Tin cậy từ 80%`.
- Đổi cột `Phương pháp` thành `Mô tả nhận diện`, kèm tooltip và mô tả chi tiết ở khung xem lại.
- Giữ nguyên xem đoạn đã chọn, chỉnh mốc, chọn nhiều khoảng và cắt CTA.
