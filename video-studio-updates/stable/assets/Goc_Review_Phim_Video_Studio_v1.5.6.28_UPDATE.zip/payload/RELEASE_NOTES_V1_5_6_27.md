# Gốc Review Phim Video Studio v1.5.6.27

## Quét bổ sung CTA

- Thêm nút **Quét bổ sung** trong workspace CTA Subscribe.
- Các CTA đã nạp từ cache hoặc đã quét trước đó được giữ nguyên trong khi detector rà lại video.
- Kết quả mới được gộp vào danh sách cũ, tránh mất các ứng viên đã duyệt.
- Cache CTA tiếp tục được lưu theo từng video và thumbnail được dựng lại khi cần.

Quét bổ sung hiện rà lại video để tìm thêm ứng viên; nút Tạm dừng/Tiếp tục vẫn dùng để điều khiển lượt quét đang chạy.
