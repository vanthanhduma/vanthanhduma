from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from qt_app import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    result = {"code": 1, "checked": False}

    def finish(code: int, message: str) -> None:
        result["code"] = code
        result["checked"] = True
        print(message, flush=True)
        window.close()
        QTimer.singleShot(250, app.quit)

    def check_ready() -> None:
        if not window.engine_ready:
            detail = ""
            try:
                if window._worker_log_path.is_file():
                    detail = window._worker_log_path.read_text(encoding="utf-8", errors="replace")[-4000:]
            except Exception:
                pass
            finish(1, "Qt engine did not become ready. " + detail)
            return
        if not hasattr(window, "batch_table") or window.batch_table.columnCount() != 4:
            finish(1, "Batch CTA page is missing or does not expose four queue columns.")
            return
        if not hasattr(window, "batch_open_project_btn") or not hasattr(window, "batch_start_btn"):
            finish(1, "Batch CTA controls are missing.")
            return
        finish(0, "Windows Qt/engine smoke test passed: engine ready, Batch CTA UI has four columns and controls are wired.")

    QTimer.singleShot(20000, lambda: (None if result["checked"] else finish(1, "Timed out waiting for Qt engine startup.")))
    poll = QTimer()
    poll.setInterval(100)
    poll.timeout.connect(lambda: check_ready() if window.engine_ready and not result["checked"] else None)
    poll.start()
    app.exec()
    return int(result["code"])


if __name__ == "__main__":
    raise SystemExit(main())
