# Góc Review Phim Video Studio v1.5.6.12

## CTA Subscribe

- Bấm tiêu đề cột `Dài` để sắp xếp các khoảng CTA từ ngắn đến dài.
- Bấm lần nữa để đảo sang dài đến ngắn; tiêu đề có mũi tên chỉ rõ chiều sắp xếp.
- Giữ nguyên thứ tự mặc định theo vị trí trên video khi chưa bấm sắp xếp.
- Giữ nguyên dòng đang chọn, checkbox đã đánh dấu và thumbnail khi bảng được cập nhật trong lúc quét.
