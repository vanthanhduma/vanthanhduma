# Góc Review Phim Video Studio v1.5.6.11

## Hiển thị mốc thời gian

- Đổi dạng số phút thập phân khó đọc như `3,44 phút` thành dạng tự nhiên `3 phút 26,4 giây`.
- Các mốc ngắn vẫn hiển thị `12,5 giây`.
- Ô chỉnh CTA và bảng kết quả dùng cùng một cách hiển thị; giá trị gửi cho engine vẫn là giây chính xác.
- Giữ nguyên giây cho mật độ quét ảnh, chế độ lấy mẫu và thời lượng xem thử.
