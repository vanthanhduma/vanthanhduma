# Góc Review Phim Video Studio v1.5.9.18


## Sửa lỗi Batch CTA
- Sửa khâu tìm và nạp cache CTA khi mở lại project đã quét hàng loạt.
- Nếu cache không còn đúng tên chuẩn, ứng dụng dò cache trong workspace của project và chỉ nhận cache có fingerprint trùng chính xác video nguồn.
- Không ghép nhầm CTA giữa các video; cache có fingerprint khác vẫn bị từ chối.
- Xác minh file cache, fingerprint và số ứng viên trước khi đánh dấu video Batch CTA là hoàn thành.
- Hàng đợi hiển thị rõ số ứng viên đã lưu, kể cả trường hợp quét xong nhưng không phát hiện CTA.
- Khi mở project không có cache hoặc cache không có ứng viên, CTA Detector hiển thị trạng thái cụ thể thay vì giữ thông báo cũ và bảng 0/0 khó hiểu.

## Giữ nguyên
- Không tự động duyệt hoặc cắt CTA.
- Không thay đổi video nguồn, project schema 4, mask, branding, xuất video, Auto Save, sao lưu hoặc hàng đợi tải video.
- Không xóa hay ghi đè cache của video khác; chỉ khôi phục cache có fingerprint trùng.

## Kiểm thử
- Bổ sung kiểm thử dò cache theo fingerprint khi tên file cache thay đổi.
- Bổ sung kiểm thử bảo đảm không nạp cache của video khác.
- Chạy lại Batch CTA project/queue, Qt smoke test và Windows Batch CTA E2E trước khi phát hành.


## v1.5.9.16 — Downloader Resume
- Thêm nút **Tiếp tục** riêng cho từng video tạm dừng và **Thử lại** cho mục lỗi.
- Nút hàng đợi đổi thành **Tiếp tục tải** khi có video tạm dừng hoặc chờ.
- Giữ nguyên thư mục lưu, chất lượng, định dạng và cookie đã chọn ở lần tải đầu; yt-dlp có thể tiếp tục file `.part` khi nguồn hỗ trợ.
- **Xóa mục đã xong** không xóa các hàng tải đang tạm dừng.

## v1.5.9.15 — Python 3.15 / PySide6 Lazy Import Compatibility
- Tắt PEP 810 lazy imports bằng `sys.set_lazy_imports("none")` ngay ở đầu các runtime entrypoint, trước khi nạp PySide6, yt-dlp hoặc thư viện xử lý.
- Giữ nguyên hành vi trên Python 3.11–3.14; phiên bản không có API này được bỏ qua an toàn.
- Khắc phục lỗi `'lazy_import' object is not callable` trên một số môi trường Python 3.15/PySide6.
- Không thay đổi cài đặt chất lượng, MP4, cookie, hàng đợi hoặc engine tải yt-dlp.

## v1.5.9.15 — Download Error Diagnostics
- Lỗi tải video được lưu riêng theo từng mục, hiển thị ngay tại vùng trạng thái bên dưới hàng đợi.
- Chọn một dòng để xem nguyên nhân lỗi đầy đủ; không còn phụ thuộc tooltip hover.
- Sau khi hàng đợi kết thúc, thông báo tổng không ghi đè chi tiết lỗi.
- Tăng giới hạn thông điệp lỗi được chuyển từ worker để giữ lại đủ thông tin chẩn đoán.

## v1.5.9.15 — Export & Branding UI Refinement
- Bỏ nút Xuất video trùng lặp trên thanh thao tác dự án; thao tác xuất toàn bộ chỉ còn trong workspace Xuất & kiểm tra.
- Chuẩn hóa chiều cao, khoảng cách và phân cấp các nút thao tác xuất video.
- Làm mới bảng điều khiển Studio Branding: tăng không gian, tab rõ ràng hơn, card điều khiển đồng nhất, footer Áp dụng tách bạch.
- Giữ nguyên toàn bộ chức năng, callback, giá trị cấu hình, preview debounce và hành vi áp dụng Branding.

# Góc Review Phim Video Studio v1.5.9.15

**Minimal Studio · Downloader · Overlay Detector · Subscribe CTA Detector · Batch CTA Processing · Stable Updater**

## Phiên bản
- **Stable:** v1.5.9.15
- **Bản nền UPDATE:** v1.5.6.41 (full compatibility bridge)
- **Source repository:** `vanthanhduma/Goc-Review-Phim-Video-Studio` (private)
- **Public update feed:** [Stable latest.json](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json)


## Cải tiến v1.5.9.15 — Downloader Workspace Refinement
- Tổ chức lại bốn thiết lập tải thành một hàng thẻ gọn, nhãn ở trên và điều khiển ở dưới.
- Giảm chiều cao vùng thiết lập để ưu tiên diện tích danh sách tải.
- Thu gọn khoảng cách, chiều cao trường liên kết và nút thao tác; giữ nguyên toàn bộ hành vi tải và hàng đợi.

## Nền tảng tương thích UPDATE

- Phát hành gói UPDATE dạng full snapshot để máy đang ở v1.5.6.41, v1.5.7.0, v1.5.8.0 và các bản v1.5.9.0–v1.5.9.10 có thể nâng cấp trực tiếp.
- Gói chứa toàn bộ file ứng dụng và module cần thiết, thay vì chỉ chứa phần thay đổi nhỏ của bản trước.
- Updater vẫn xác minh SHA-256 từng file, kiểm tra đường dẫn an toàn, sao lưu file ứng dụng và rollback khi health-check thất bại.
- Không đóng gói hoặc ghi đè .venv, projects, autosave, user_settings.json, assets/user, downloads, renders, logs hoặc _backups.
- Không thay đổi project schema, dữ liệu dự án, video nguồn, output hoặc preset cá nhân.

## Cải tiến v1.5.9.10 — Branding Inspector Tabs
- Thiết kế lại bảng điều khiển Studio Branding thành bốn tab riêng: **Logo**, **Nhãn**, **Thời gian** và **Preset**.
- Chuyển logo, kích thước/độ mờ, xoay và vị trí vào tab Logo; gom nội dung nhãn, kích thước, độ mờ, vị trí và màu sắc vào tab Nhãn.
- Tách thời gian hiển thị/phạm vi phân cảnh và quản lý preset thành hai tab riêng.
- Giữ preview rộng ở trung tâm, inspector có chiều rộng ổn định, nội dung mỗi tab có thể cuộn độc lập và nút **Áp dụng** luôn nằm cố định bên dưới.
- Giữ nguyên toàn bộ widget/state/callback, kéo logo trực tiếp, preview debounce, màu sắc, preset, thời gian và thao tác áp dụng.

## Cải tiến v1.5.9.9 — Branding / Download Workspace Polish
- **Studio Branding:** thu gọn panel điều khiển phải còn khoảng 290–325 px; tăng vùng preview; giảm nút định vị logo và khoảng cách; chuẩn hóa lề/spacing cho nhóm Logo, Nhãn, Thời gian và Preset; giữ đầy đủ mọi thông số và thao tác.
- **Tải video:** chuyển bốn thẻ thiết lập sang bố cục ngang, tên/mô tả bên trái và ô chọn/đường dẫn bên phải; đặt chiều cao tối thiểu cho từng thẻ/vùng thiết lập để không bị cắt; bảng hàng đợi có thể co trước.
- Giữ nguyên lựa chọn chất lượng, định dạng, cookie trình duyệt, thư mục lưu, các callback tải video, thao tác Branding, luồng preview và Engine commands.

## Cải tiến v1.5.9.8 — Download / Batch CTA Workspace Redesign
- Thu gọn panel điều khiển bên phải của Studio Branding về khoảng 315–360 px để tăng không gian preview, vẫn giữ đầy đủ logo, nhãn, thời gian, preset và Áp dụng.
- Thiết kế lại **Tải video**: thiết lập tải được chia thành các thẻ riêng cho chất lượng, định dạng, cookie trình duyệt và thư mục lưu; nhãn nằm trên ô điều khiển, kích thước và khoảng cách nhất quán.
- Thiết kế lại **Batch CTA** theo hai cột: hàng đợi và các nút quản lý video ở bên trái; thư mục project, tiến độ, Bắt đầu và Dừng ở rail bên phải.
- Thêm empty state cho hàng đợi Batch CTA, tự chuyển sang bảng khi có video.
- Giữ nguyên giá trị lựa chọn, widget binding, callback, lệnh Engine, quy tắc quét tuần tự, lưu project riêng và dừng/tiếp tục an toàn.

## Cải tiến v1.5.9.7 — Global UI Polish
- Đồng bộ typography trên tất cả workspace: Branding, Mask/Before-After, CTA Detector, Downloader, Batch CTA, Ghép video và Xuất & kiểm tra.
- Tăng nhẹ cỡ chữ cơ sở lên 10.5 pt, dùng Segoe UI với fallback tiếng Việt phù hợp; phân cấp rõ tiêu đề, nhãn, nút, tab và bảng.
- Đặt bề mặt QLabel, checkbox, radio, slider, group box, frame và vùng nội dung dạng stack trong suốt khi không phải card/ô nhập liệu, tránh các dải nền đen phía sau chữ.
- Nới vùng tên dự án và tên video trên thanh công cụ, vẫn giữ tooltip đường dẫn đầy đủ.
- Không thay đổi bố cục chức năng, Engine commands, detector, FFmpeg pipeline, project/Auto Save, backup hoặc updater.

## Cải tiến v1.5.9.6 — Export Typography Polish
- Đồng bộ font UI về Segoe UI (fallback font hệ thống phù hợp), cỡ chữ cơ sở 10.1 pt và weight Medium.
- Đặt nền QLabel trong suốt để chữ nằm trực tiếp trên card, loại bỏ các dải nền đen sau tiêu đề và trạng thái.
- Chuẩn hóa độ lớn/độ đậm cho tiêu đề nhóm, metadata, timecode, bảng khoảng cắt và nút thao tác.
- Sửa hiển thị dấu “&” trong nút “Cắt bỏ & xuất phần còn lại” bằng helper escape mnemonic của Qt.
- Giữ nguyên bố cục workspace, logic cắt, preview, thư mục đầu ra, QC và pipeline xuất.

## Cải tiến v1.5.9.5 — Export & Quality Workspace
- Tách trang **Xuất & kiểm tra** thành workspace riêng, không còn dồn toàn bộ thao tác vào panel cuộn bên phải.
- Preview và thanh vị trí phát nằm ở cột trung tâm; danh sách khoảng cắt, điều khiển Từ–Đến và xem video gốc/xem thử đặt ngay bên dưới.
- Thêm timeline trực quan: màu cyan là phần giữ lại, vùng gạch chéo màu cam là phần sẽ cắt; nhấp timeline để chuyển tới thời điểm tương ứng.
- Cột phải tập trung vào thư mục xuất, xuất toàn bộ, cắt bỏ các khoảng đã chọn, kiểm tra chất lượng và dừng tác vụ.
- Giữ nguyên các lệnh Engine đang có; không thêm giả các lựa chọn codec/FPS/độ phân giải mà backend chưa cung cấp.

## Cải tiến v1.5.9.4 — Smooth Studio Branding Drag
- Tách ảnh nền preview và logo trong suốt thành hai lớp độc lập.
- Qt vẽ và di chuyển lớp logo trực tiếp theo chuột; không gọi Engine khi rê chuột.
- Giữ điểm nắm trên logo, giới hạn logo trong khung video và chỉ gửi một lần cập nhật khi thả chuột.
- Preview cuối cùng vẫn được Engine dựng lại để đồng bộ cấu hình; chất lượng video xuất không thay đổi.

## Cải tiến v1.5.9.3 — Studio Branding Preview Performance
- Studio Branding dựng preview ở tối đa 1280×720 thay vì dựng nhiều lớp ảnh ở độ phân giải gốc 4K rồi mới thu nhỏ.
- Chỉ tạo lớp logo/nhãn một lần trong mỗi preview; không dựng lại overlay đầy đủ lần thứ hai.
- Gom các thay đổi slider/toggle, tối đa một preview đang chạy và chỉ xử lý trạng thái mới nhất.
- Giữ tọa độ logo theo khung video gốc để kéo/thả chính xác.
- Không thay đổi độ phân giải hoặc chất lượng video xuất, preset, phạm vi thời gian và cấu hình theo phân cảnh.

## Cải tiến v1.5.9.2 — Project Toolbar & Backup History
- Đưa Mở dự án, Lưu, Lưu thành, Lịch sử sao lưu, Nhập ZIP và Đóng gói ZIP thành các nút riêng luôn hiển thị trên thanh công cụ phía trên.
- Bỏ menu Dự án dạng nút xổ xuống để thao tác dự án không còn bị ẩn.
- Chuyển icon Công cụ video xuống đúng nút điều hướng, đồng bộ với CTA Detector, Mask và Branding; tiêu đề nhóm chỉ còn chữ.
- Lịch sử sao lưu luôn mở được, kể cả khi chưa lưu dự án thủ công hoặc chưa có mốc nào; hộp thoại giải thích rõ trạng thái thay vì bị khóa.
- Giữ nguyên khôi phục an toàn thành dự án mới, giới hạn tối đa 8 mốc và quy tắc Auto Save không tự tạo snapshot.

## Cải tiến v1.5.9.1 — Batch CTA & Backup History UI
- Làm lại bố cục Batch CTA theo các vùng tiêu đề, hàng đợi, thư mục project và tiến độ; bổ sung icon cho các thao tác thường dùng.
- Thêm icon cho tiêu đề nhóm **CÔNG CỤ VIDEO** ở sidebar.
- Đưa nút khôi phục lịch sử sao lưu lên thanh tiêu đề của hộp thoại.
- Không tự chọn bản sao lưu khi mở; người dùng click/Enter vào một mốc để bật nút khôi phục, sau đó xác nhận.
- Khôi phục vẫn tạo và mở một project mới, không ghi đè project hiện tại.
- Không thay đổi thuật toán nhận diện CTA, quy tắc quét tuần tự hoặc quyền duyệt/cắt thủ công.

## Batch CTA Processing (kế thừa từ v1.5.9.0)
- Thêm nhiều video hoặc thêm toàn bộ thư mục vào một hàng đợi.
- Chọn một thư mục lưu dự án; Batch CTA quét tuần tự từng video bằng CTA Detector hiện có.
- Mỗi video được lưu thành một file `.grproj` riêng, kèm CTA cache, mốc thời gian, độ tin cậy và thumbnail bằng chứng.
- Video nguồn vẫn ở vị trí ban đầu, không bị sao chép vào thư mục dự án.
- Hàng đợi được lưu an toàn. Có thể tiếp tục các video chưa hoàn thành; các video đã hoàn thành được bỏ qua.
- Khi hoàn tất toàn bộ, ứng dụng trở về workspace Video Tools. Dừng thủ công vẫn giữ trang Batch để có thể tiếp tục.

## Cách duyệt và cắt video
Batch CTA chỉ làm nhiệm vụ quét và lưu dự án. Người dùng mở từng dự án, xem ảnh bằng chứng và mốc thời gian, sau đó tự chọn các khoảng cần cắt rồi xuất video. Ứng dụng không tự phê duyệt ứng viên và không tự động cắt.

CTA Detector chỉ xử lý nội dung hiển thị trong hình ảnh/video; không phân tích âm thanh hoặc lời nói.

## Các chức năng được giữ lại
- Biên tập và phân cảnh; Mask và Before/After.
- Branding, Downloader, Overlay Detector.
- CTA Subscribe Detector và duyệt thủ công trước khi cắt.
- Xuất MP4, kiểm tra chất lượng (QC), lưu/mở dự án, Auto Save và lịch sử sao lưu.
- Lệnh Batch export cũ vẫn được giữ trong engine để tương thích.

## Dữ liệu và an toàn
- Dự án Batch CTA dùng schema v4 và cache CTA trong bố cục hiện có.
- Video nguồn được tham chiếu theo đường dẫn/fingerprint; không nhân bản.
- Không ghi đè projects, autosave, settings, branding cá nhân, downloads, renders, video nguồn, output hoặc môi trường `.venv`.
- Updater xác minh HTTPS + SHA-256, sao lưu trước khi áp dụng và hỗ trợ rollback.

## Cài đặt và cập nhật
- Máy đang ở **v1.5.9.9** cập nhật trực tiếp lên **v1.5.9.10** bằng nút **Kiểm tra & cập nhật**.
- Máy đang ở **v1.5.9.8** cần nâng cấp lên v1.5.9.9 trước, sau đó mới lên v1.5.9.10.
- Máy đang ở **v1.5.9.7** cần nâng cấp lên v1.5.9.8, sau đó v1.5.9.9 rồi mới lên v1.5.9.10.
- Máy đang ở **v1.5.9.6** cần nâng cấp theo thứ tự v1.5.9.7 → v1.5.9.8 → v1.5.9.9 → v1.5.9.10.
- Máy đang ở **v1.5.8.0** cần nâng cấp theo lộ trình cũ trước khi lên v1.5.9.10.
- Gói UPDATE không phải bộ cài mới; không giải nén thủ công đè lên thư mục ứng dụng.
- Máy mới sử dụng gói FULL riêng.

## Kiểm thử
- Windows E2E: hai MP4 tổng hợp, OCR nhận SUBSCRIBE và LIKE; Batch quét tuần tự, lưu hai project, cache và thumbnail, sau đó mở lại project và xác nhận ứng viên được nạp vào giao diện.
- Qt/Engine smoke test và Batch CTA queue/project tests: PASS.
- E2E tổng hợp xác minh pipeline tự động; vẫn cần người dùng xem lại kết quả trên video thực tế trước khi cắt.
