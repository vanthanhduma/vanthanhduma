from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DownloadBatchBrandingWorkspaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt = (ROOT / "qt_app.py").read_text(encoding="utf-8")

    def test_branding_uses_four_focused_inspector_tabs(self):
        self.assertIn('inspector.setObjectName("BrandingInspector")', self.qt)
        self.assertIn("inspector.setMinimumWidth(330)", self.qt)
        self.assertIn("inspector.setMaximumWidth(370)", self.qt)
        self.assertIn('self.branding_tabs = QTabWidget()', self.qt)
        self.assertIn('self.branding_tabs.addTab(scroll, title)', self.qt)
        for title in ("Logo", "Nhãn", "Thời gian", "Preset"):
            self.assertIn(f'add_tab("{title}")', self.qt)
        self.assertIn('QTabWidget#BrandingTabs::pane', self.qt)
        self.assertIn('QFrame#BrandingInspector', self.qt)
        self.assertIn('QScrollArea#BrandingTabScroll', self.qt)
        self.assertIn('self.apply_btn = QPushButton("Áp dụng")', self.qt)
        self.assertIn("self.apply_btn.setMinimumHeight(42)", self.qt)

    def test_branding_tabs_keep_all_existing_edit_controls_and_callbacks(self):
        for widget in (
            "self.logo_enabled", "self.choose_logo_btn", "self.logo_size",
            "self.logo_opacity", "self.logo_rotation", "self._anchor_buttons",
            "self.label_enabled", "self.label_text_edit", "self.label_scale",
            "self.label_opacity", "self.label_anchor", "self.text_color_btn",
            "self.bg_color_btn", "self.show_from", "self.show_to",
            "self.scene_scope", "self.preset_combo", "self.preset_save",
            "self.preset_load", "self.preset_delete",
        ):
            self.assertIn(widget, self.qt)
        self.assertIn(
            'button.clicked.connect(lambda _=False, a=anchor: self._set_logo_anchor(a))',
            self.qt,
        )
        self.assertIn('self.preset_save.clicked.connect(self._save_preset)', self.qt)
        self.assertIn('self.preset_load.clicked.connect(self._load_preset)', self.qt)
        self.assertIn('self.preset_delete.clicked.connect(self._delete_preset)', self.qt)
        self.assertIn('signal.connect(lambda *_: self._schedule_preview())', self.qt)
        self.assertIn('self.apply_btn.clicked.connect(self._apply)', self.qt)

    def test_download_settings_use_separate_readable_cards(self):
        self.assertIn('options.setObjectName("DownloadSettingsCard")', self.qt)
        self.assertIn('quality_card.setObjectName("DownloadOptionCard")', self.qt)
        self.assertIn('format_card.setObjectName("DownloadOptionCard")', self.qt)
        self.assertIn('browser_card.setObjectName("DownloadOptionCard")', self.qt)
        self.assertIn('folder_card.setObjectName("DownloadOptionCard")', self.qt)
        self.assertIn('options_title = QLabel("Thiết lập tải")', self.qt)
        self.assertIn('quality_label = QLabel("Chất lượng video")', self.qt)
        self.assertIn('format_label = QLabel("Định dạng tệp")', self.qt)
        self.assertIn('browser_label = QLabel("Cookie trình duyệt")', self.qt)
        self.assertIn('folder_label = QLabel("Thư mục lưu video")', self.qt)

    def test_download_settings_use_compact_single_row_vertical_cards(self):
        for layout in (
            "quality_layout = QVBoxLayout(quality_card)",
            "format_layout = QVBoxLayout(format_card)",
            "browser_layout = QVBoxLayout(browser_card)",
            "folder_layout = QVBoxLayout(folder_card)",
        ):
            self.assertIn(layout, self.qt)
        self.assertIn("settings_grid.addWidget(quality_card, 0, 0)", self.qt)
        self.assertIn("settings_grid.addWidget(format_card, 0, 1)", self.qt)
        self.assertIn("settings_grid.addWidget(browser_card, 0, 2)", self.qt)
        self.assertIn("settings_grid.addWidget(folder_card, 0, 3)", self.qt)
        self.assertIn("options.setMinimumHeight(128)", self.qt)
        self.assertIn("self.download_table.setMinimumHeight(88)", self.qt)
        self.assertIn("root.setSpacing(7)", self.qt)
        self.assertIn("quality_layout.addWidget(self.download_quality, 2)", self.qt)
        self.assertIn("format_layout.addWidget(self.download_format, 2)", self.qt)
        self.assertIn("browser_layout.addWidget(self.download_browser, 2)", self.qt)
        self.assertIn("folder_layout.addLayout(folder_row, 2)", self.qt)

    def test_download_options_preserve_supported_values_and_behavior(self):
        self.assertIn('self.download_quality.addItem("Cao nhất (tự động)", None)', self.qt)
        self.assertIn('self.download_quality.addItem("Tối đa 1080p", 1080)', self.qt)
        self.assertIn('self.download_quality.addItem("Tối đa 720p", 720)', self.qt)
        self.assertIn('self.download_format.addItem("Tự động (khuyến nghị)", "auto")', self.qt)
        self.assertIn('self.download_format.addItem("Ưu tiên MP4", "mp4")', self.qt)
        self.assertIn('self.download_browser.addItem("Chrome", "chrome")', self.qt)
        self.assertIn('self.download_browser.addItem("Edge", "edge")', self.qt)
        self.assertIn('self.download_browser.addItem("Firefox", "firefox")', self.qt)
        self.assertIn("self.download_folder_edit = QLineEdit(", self.qt)
        self.assertIn("self.download_start_btn.clicked.connect(self._download_start_queue)", self.qt)
        self.assertIn("self.download_stop_btn.clicked.connect(self._download_stop)", self.qt)
        self.assertIn("self.download_clear_btn.clicked.connect(self._download_clear_finished)", self.qt)
        self.assertIn("self.download_remove_btn.clicked.connect(self._download_remove_selected_waiting)", self.qt)

    def test_batch_workspace_uses_queue_and_control_rail_columns(self):
        self.assertIn("body = QHBoxLayout()", self.qt)
        self.assertIn('queue_panel.setObjectName("Inspector")', self.qt)
        self.assertIn('rail.setObjectName("BatchRail")', self.qt)
        self.assertIn("body.addWidget(queue_panel, 7)", self.qt)
        self.assertIn("body.addWidget(rail, 3)", self.qt)
        self.assertIn('folder_card.setObjectName("BatchOptionCard")', self.qt)
        self.assertIn('self.batch_start_btn = QPushButton("Bắt đầu quét CTA")', self.qt)
        self.assertIn('self.batch_stop_btn = QPushButton("Dừng hàng đợi")', self.qt)

    def test_batch_empty_state_switches_to_table_when_queue_has_rows(self):
        self.assertIn("self.batch_queue_stack = QStackedWidget()", self.qt)
        self.assertIn('empty_title = QLabel("Hàng đợi đang trống")', self.qt)
        self.assertIn("self.batch_queue_stack.addWidget(empty_queue)", self.qt)
        self.assertIn("self.batch_queue_stack.addWidget(self.batch_table)", self.qt)
        self.assertIn("self.batch_queue_stack.setCurrentIndex(1 if self.batch_table.rowCount() else 0)", self.qt)
        self.assertIn("self.batch_queue_stack.setCurrentIndex(1 if self.batch_table.rowCount() else 0)", self.qt)

    def test_batch_queue_actions_and_persisted_project_flow_are_preserved(self):
        self.assertIn("self.batch_add_btn.clicked.connect(self._batch_add_files)", self.qt)
        self.assertIn("self.batch_add_folder_btn.clicked.connect(self._batch_add_folder)", self.qt)
        self.assertIn("self.batch_remove_btn.clicked.connect(self._batch_remove_selected)", self.qt)
        self.assertIn("self.batch_up_btn.clicked.connect(lambda: self._batch_move_selected(-1))", self.qt)
        self.assertIn("self.batch_down_btn.clicked.connect(lambda: self._batch_move_selected(1))", self.qt)
        self.assertIn("self.batch_open_project_btn.clicked.connect(self._batch_open_selected_project)", self.qt)
        self.assertIn('self.send("batch_cta_start"', self.qt)
        self.assertIn('self.send("batch_cta_stop")', self.qt)
        self.assertIn('self.send("open_project", path=project_path)', self.qt)

    def test_new_workspace_surfaces_have_explicit_styles(self):
        self.assertIn("QFrame#DownloadSettingsCard", self.qt)
        self.assertIn("QFrame#DownloadOptionCard", self.qt)
        self.assertIn("QFrame#BatchRail", self.qt)
        self.assertIn("QFrame#BatchEmptyState", self.qt)
        self.assertIn("QTableWidget#BatchQueueTable", self.qt)


if __name__ == "__main__":
    unittest.main()
