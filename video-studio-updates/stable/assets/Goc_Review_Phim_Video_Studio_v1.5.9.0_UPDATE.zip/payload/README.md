# Góc Review Phim Video Studio v1.5.9.0

**Minimal Studio · Downloader · Overlay Detector · Subscribe CTA Detector · Batch CTA Processing · Stable Updater**

## Phiên bản
- **Stable:** v1.5.9.0
- **Bản nền UPDATE:** v1.5.8.0
- **Source repository:** `vanthanhduma/Goc-Review-Phim-Video-Studio` (private)
- **Public update feed:** [Stable latest.json](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json)

## Điểm mới trong v1.5.9.0 — Batch CTA Processing
- Thêm nhiều video hoặc thêm toàn bộ thư mục vào một hàng đợi.
- Chọn một thư mục lưu dự án; Batch CTA quét tuần tự từng video bằng CTA Detector hiện có.
- Mỗi video được lưu thành một file `.grproj` riêng, kèm CTA cache, mốc thời gian, độ tin cậy và thumbnail bằng chứng.
- Video nguồn vẫn ở vị trí ban đầu, không bị sao chép vào thư mục dự án.
- Hàng đợi được lưu an toàn. Có thể tiếp tục các video chưa hoàn thành; các video đã hoàn thành được bỏ qua.
- Khi hoàn tất toàn bộ, ứng dụng trở về workspace Video Tools. Dừng thủ công vẫn giữ trang Batch để có thể tiếp tục.

## Cách duyệt và cắt video
Batch CTA chỉ làm nhiệm vụ quét và lưu dự án. Người dùng mở từng dự án, xem ảnh bằng chứng và mốc thời gian, sau đó tự chọn các khoảng cần cắt rồi xuất video. Ứng dụng không tự phê duyệt ứng viên và không tự động cắt.

CTA Detector chỉ xử lý nội dung hiển thị trong hình ảnh/video; không phân tích âm thanh hoặc lời nói.

## Các chức năng được giữ lại
- Biên tập và phân cảnh; Mask và Before/After.
- Branding, Downloader, Overlay Detector.
- CTA Subscribe Detector và duyệt thủ công trước khi cắt.
- Xuất MP4, kiểm tra chất lượng (QC), lưu/mở dự án, Auto Save và lịch sử sao lưu.
- Lệnh Batch export cũ vẫn được giữ trong engine để tương thích.

## Dữ liệu và an toàn
- Dự án Batch CTA dùng schema v4 và cache CTA trong bố cục hiện có.
- Video nguồn được tham chiếu theo đường dẫn/fingerprint; không nhân bản.
- Không ghi đè projects, autosave, settings, branding cá nhân, downloads, renders, video nguồn, output hoặc môi trường `.venv`.
- Updater xác minh HTTPS + SHA-256, sao lưu trước khi áp dụng và hỗ trợ rollback.

## Cài đặt và cập nhật
- Cập nhật từ v1.5.8.0 bằng nút **Kiểm tra & cập nhật** trong ứng dụng.
- Máy đang ở phiên bản cũ hơn cần cập nhật lên v1.5.8.0 trước.
- Gói UPDATE không phải bộ cài mới; không giải nén thủ công đè lên thư mục ứng dụng.
- Máy mới sử dụng gói FULL riêng.

## Kiểm thử
- Windows E2E: hai MP4 tổng hợp, OCR nhận SUBSCRIBE và LIKE; Batch quét tuần tự, lưu hai project, cache và thumbnail, sau đó mở lại project và xác nhận ứng viên được nạp vào giao diện.
- Qt/Engine smoke test và Batch CTA queue/project tests: PASS.
- E2E tổng hợp xác minh pipeline tự động; vẫn cần người dùng xem lại kết quả trên video thực tế trước khi cắt.
