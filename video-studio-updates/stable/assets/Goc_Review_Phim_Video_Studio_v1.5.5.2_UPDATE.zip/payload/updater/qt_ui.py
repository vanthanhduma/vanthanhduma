from __future__ import annotations

import threading
import tempfile
import shutil
from pathlib import Path

from PySide6.QtCore import QObject, Signal, Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar,
    QTextEdit, QMessageBox,
)

from updater.core import (
    UpdateError, check_for_update, download_update,
)


class UpdateSignals(QObject):
    checked = Signal(object)
    progress = Signal(int, int)
    downloaded = Signal(object)


class UpdateDialog(QDialog):
    """In-app release information and one-click download/installation workflow."""
    update_available = Signal(object)

    def __init__(self, current_version: str, public_key_path: Path, parent=None):
        super().__init__(parent)
        self.current_version = current_version
        self.public_key_path = Path(public_key_path)
        self.manifest = None
        self.stage_root = None
        self.signals = UpdateSignals(self)
        self.signals.checked.connect(self._on_checked)
        self.signals.progress.connect(self._on_progress)
        self.signals.downloaded.connect(self._on_downloaded)
        self._check_thread = None
        self._download_thread = None
        self._cancel_requested = False
        self._cancel_event = threading.Event()
        self._silent_check = False
        self._build_ui()

    def _build_ui(self):
        self.setWindowTitle("Trung tâm cập nhật")
        self.setMinimumWidth(560)
        self.resize(650, 520)
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 22, 24, 20)
        root.setSpacing(12)
        title = QLabel("TRUNG TÂM CẬP NHẬT")
        title.setStyleSheet("font-size:13pt;font-weight:750;color:#eaf8fb;letter-spacing:0.5px;")
        root.addWidget(title)
        self.status = QLabel("Đang kiểm tra phiên bản…")
        self.status.setStyleSheet("color:#9ab2bf;font-weight:600;")
        root.addWidget(self.status)

        version_row = QHBoxLayout()
        self.current_label = QLabel(f"ĐANG DÙNG\nv{self.current_version}")
        self.current_label.setStyleSheet("background:#102b3a;border:1px solid #245064;border-radius:9px;padding:14px;font-weight:650;")
        self.new_label = QLabel("PHIÊN BẢN MỚI\nChưa kiểm tra")
        self.new_label.setStyleSheet("background:#102b3a;border:1px solid #245064;border-radius:9px;padding:14px;font-weight:650;")
        version_row.addWidget(self.current_label, 1)
        version_row.addWidget(self.new_label, 1)
        root.addLayout(version_row)

        self.notes = QTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setPlaceholderText("Nội dung phát hành sẽ hiển thị tại đây.")
        self.notes.setMaximumHeight(210)
        root.addWidget(self.notes, 1)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setVisible(False)
        root.addWidget(self.progress)
        self.progress_label = QLabel("")
        self.progress_label.setStyleSheet("color:#9ab2bf;font-size:9pt;")
        root.addWidget(self.progress_label)

        actions = QHBoxLayout()
        self.check_btn = QPushButton("Kiểm tra cập nhật")
        self.check_btn.setToolTip("Kiểm tra phiên bản Stable mới nhất; không cần đăng nhập GitHub")
        self.check_btn.clicked.connect(lambda: self.start_check(silent=False))
        actions.addWidget(self.check_btn)
        actions.addStretch(1)
        self.skip_btn = QPushButton("Bỏ qua phiên bản")
        self.skip_btn.setEnabled(False)
        self.skip_btn.clicked.connect(self._skip_version)
        actions.addWidget(self.skip_btn)
        self.later_btn = QPushButton("Để sau")
        self.later_btn.clicked.connect(self.reject)
        actions.addWidget(self.later_btn)
        self.update_btn = QPushButton("Cập nhật ngay")
        self.update_btn.setObjectName("Primary")
        self.update_btn.setEnabled(False)
        self.update_btn.clicked.connect(self._start_update)
        actions.addWidget(self.update_btn)
        root.addLayout(actions)
        self.cancel_btn = QPushButton("Hủy tải cập nhật")
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self._cancel_download)
        root.addWidget(self.cancel_btn, alignment=Qt.AlignmentFlag.AlignRight)

    def start_check(self, silent: bool = False):
        if self._check_thread and self._check_thread.is_alive():
            return
        self._silent_check = silent
        self.status.setText("Đang kiểm tra bản phát hành Stable công khai…")
        self.notes.setPlainText("Đang kết nối máy chủ cập nhật. Không cần tài khoản GitHub hoặc mã token.")
        self.check_btn.setEnabled(False)
        self.update_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)

        def worker():
            try:
                result = check_for_update(self.current_version, self.public_key_path)
                self.signals.checked.emit({"ok": True, "result": result})
            except Exception as exc:
                self.signals.checked.emit({"ok": False, "error": str(exc)})
        self._check_thread = threading.Thread(target=worker, name="UpdaterCheck", daemon=True)
        self._check_thread.start()

    def _on_checked(self, response):
        self.check_btn.setEnabled(True)
        if not response.get("ok"):
            self.manifest = None
            self.status.setText("Chưa thể kiểm tra cập nhật.")
            self.notes.setPlainText(response.get("error", "Lỗi không xác định."))
            self.update_btn.setEnabled(False)
            self.skip_btn.setEnabled(False)
            return
        result = response.get("result")
        if result is None:
            self.manifest = None
            self.status.setText("Bạn đang sử dụng phiên bản Stable mới nhất.")
            self.new_label.setText("PHIÊN BẢN MỚI\nKhông có")
            self.notes.setPlainText("Chưa có bản cập nhật mới hơn trên kênh Stable.")
            self.update_btn.setEnabled(False)
            self.skip_btn.setEnabled(False)
            return
        manifest, release = result
        self.manifest = manifest
        self.update_available.emit(manifest)
        self.new_label.setText(f"PHIÊN BẢN MỚI\nv{manifest['version']}")
        notes = str(manifest.get("release_notes", release.get("body", ""))).strip()
        self.notes.setPlainText(notes or "Bản phát hành không có ghi chú.")
        size_mb = int(manifest["asset_size"]) / (1024 * 1024)
        self.status.setText(f"Có phiên bản mới · {size_mb:.1f} MB · {manifest.get('_release_date', '')[:10]}")
        self.update_btn.setEnabled(True)
        self.skip_btn.setEnabled(True)

    def _skip_version(self):
        if not self.manifest:
            return
        self.done(42)  # MainWindow stores the skipped version.

    def _start_update(self):
        if not self.manifest or self._download_thread and self._download_thread.is_alive():
            return
        answer = QMessageBox.question(
            self, "Xác nhận cập nhật",
            f"Tải và cài v{self.manifest['version']} ngay bây giờ? Ứng dụng sẽ tự đóng và mở lại "
            "sau khi các tác vụ đang chạy hoàn tất.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.update_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)
        self.later_btn.setEnabled(False)
        self.cancel_btn.setVisible(True)
        self.cancel_btn.setEnabled(True)
        self.progress.setVisible(True)
        self.progress.setRange(0, 100)
        self.status.setText("Đang tải gói cập nhật…")
        stage = Path(tempfile.mkdtemp(prefix="gocreview-update-"))
        self._cancel_requested = False
        self._cancel_event.clear()

        def worker():
            try:
                result = download_update(
                    self.manifest, self.public_key_path, stage,
                    progress=lambda done, total: self.signals.progress.emit(done, total),
                    cancel_event=self._cancel_event,
                )
                self.signals.downloaded.emit({"ok": True, "stage": str(stage), "verified": str(result)})
            except Exception as exc:
                self.signals.downloaded.emit({"ok": False, "error": str(exc), "stage": str(stage), "cancelled": self._cancel_event.is_set()})
        self._download_thread = threading.Thread(target=worker, name="UpdaterDownload", daemon=True)
        self._download_thread.start()

    def _on_progress(self, done: int, total: int):
        pct = int(done * 100 / total) if total else 0
        self.progress.setValue(max(0, min(100, pct)))
        self.progress_label.setText(f"{done / 1048576:.1f} / {total / 1048576:.1f} MB")

    def _on_downloaded(self, response):
        self.cancel_btn.setVisible(False)
        self.cancel_btn.setEnabled(True)
        if not response.get("ok"):
            if response.get("cancelled"):
                shutil.rmtree(response.get("stage", ""), ignore_errors=True)
                self.status.setText("Đã hủy tải cập nhật. Ứng dụng chưa bị thay đổi.")
            else:
                shutil.rmtree(response.get("stage", ""), ignore_errors=True)
                self.status.setText("Tải hoặc xác minh thất bại. Chưa file nào bị thay đổi.")
                self.notes.append("\n\nLỗi: " + response.get("error", "Không rõ lỗi."))
            self.update_btn.setEnabled(True)
            self.later_btn.setEnabled(True)
            self.check_btn.setEnabled(True)
            return
        self.stage_root = Path(response["stage"])
        self.status.setText("Đã tải và xác minh an toàn. Đang kiểm tra tác vụ của Video Studio…")
        self.progress.setValue(100)
        self.progress_label.setText("Gói cập nhật đã xác minh; chưa thay đổi file ứng dụng.")
        self.update_btn.setText("Đang chờ ứng dụng rảnh…")
        self.update_btn.setEnabled(False)
        self.notes.append("\n\nGói đã xác minh. Ứng dụng sẽ tự áp dụng sau khi tác vụ đang chạy kết thúc.")
        self.accept()  # MainWindow takes ownership of the verified staging folder.

    def _cancel_download(self):
        self._cancel_requested = True
        self._cancel_event.set()
        self.cancel_btn.setEnabled(False)
        self.status.setText("Đang hủy tải… file ứng dụng hiện tại vẫn an toàn.")
