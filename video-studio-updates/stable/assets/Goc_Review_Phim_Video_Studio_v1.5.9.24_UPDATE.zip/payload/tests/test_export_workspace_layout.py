from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ExportWorkspaceLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt = (ROOT / "qt_app.py").read_text(encoding="utf-8")
        cls.worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")

    def test_export_is_a_dedicated_workspace_not_an_inspector_scroll(self):
        self.assertIn("def _build_export_workspace(self):", self.qt)
        self.assertIn("self.export_workspace = self._build_export_workspace()", self.qt)
        self.assertIn("self.workspace_stack.addWidget(self.export_workspace)", self.qt)
        self.assertIn("self.workspace_stack.setCurrentWidget(self.export_workspace)", self.qt)
        self.assertIn("def _build_export_tab(self):", self.qt)
        self.assertIn("workspace riêng", self.qt)

    def test_preview_cut_list_and_timeline_are_in_the_main_column(self):
        self.assertIn("self.export_preview_image = FitPixmapLabel()", self.qt)
        self.assertIn("self.manual_cut_list = QTableWidget(0, 4)", self.qt)
        self.assertIn("self.cut_timeline = CutTimelineWidget()", self.qt)
        self.assertIn("self.cut_timeline.seekRequested.connect(self._seek_to_seconds)", self.qt)
        self.assertIn("def _refresh_export_timeline(self):", self.qt)
        self.assertIn("self.cut_timeline.set_data(duration, self.manual_cut_ranges, current)", self.qt)

    def test_cut_range_table_and_time_fields_stay_connected(self):
        self.assertIn("def _select_manual_cut_row(", self.qt)
        self.assertIn("def _refresh_manual_cut_list(self):", self.qt)
        self.assertIn("self.manual_cut_list.currentCellChanged.connect(self._select_manual_cut_row)", self.qt)
        self.assertIn("def _add_manual_cut_range(self):", self.qt)
        self.assertIn("def _remove_manual_cut_range(self):", self.qt)
        self.assertIn("self.manual_cut_ranges.append(current)", self.qt)

    def test_global_project_toolbar_does_not_duplicate_full_export_action(self):
        self.assertNotIn("self.export_top_btn", self.qt)
        self.assertIn('self.export_full_workspace_btn = QPushButton("Xuất toàn bộ video")', self.qt)
        self.assertIn('self.export_full_workspace_btn.clicked.connect(lambda: self.send("export_full"))', self.qt)

    def test_export_action_buttons_use_consistent_heights(self):
        self.assertIn("self.export_full_workspace_btn.setFixedHeight(46)", self.qt)
        self.assertIn("self.export_segment_btn.setFixedHeight(44)", self.qt)
        self.assertIn("self.qc_btn.setFixedHeight(44)", self.qt)
        self.assertIn("self.stop_export_btn.setFixedHeight(44)", self.qt)

    def test_export_actions_keep_existing_engine_commands(self):
        self.assertIn('self.send("export_full")', self.qt)
        self.assertIn('self.send("cut_ranges", ranges=', self.qt)
        self.assertIn('self.send("export_preview", start=start)', self.qt)
        self.assertIn('self.send("open_qc")', self.qt)
        self.assertIn('self.send("stop_export")', self.qt)
        self.assertIn('elif cmd == "cut_ranges":', self.worker)
        self.assertIn('elif cmd == "open_qc":', self.worker)

    def test_output_destination_remains_the_existing_engine_setting(self):
        self.assertIn("self.output_path_label = QLabel", self.qt)
        self.assertIn("outbtn.clicked.connect(self.choose_output)", self.qt)
        self.assertIn('self.send("choose_output", path=path)', self.qt)
        self.assertIn('self.output_path_label.setText(s.get("output_dir") or "Mặc định theo video nguồn")', self.qt)

    def test_export_typography_uses_transparent_labels_and_consistent_font(self):
        self.assertIn(
            "QLabel, QCheckBox, QRadioButton, QSlider, QGroupBox, QTabWidget, QStackedWidget, QFrame {{\n"
            "  background: transparent;",
            self.qt,
        )
        self.assertIn("QLabel#SectionTitle", self.qt)
        self.assertIn("QLabel#ExportMeta", self.qt)
        self.assertIn("QLabel#ExportTime", self.qt)
        self.assertIn("font-size: 10.5pt", self.qt)
        self.assertIn("ui_font.setPointSizeF(10.5)", self.qt)
        self.assertIn("ui_font.setWeight(QFont.Weight.Medium)", self.qt)

    def test_export_cut_action_escapes_qt_ampersand_mnemonic(self):
        self.assertIn(
            'QPushButton(_qt_button_label("Cắt bỏ & xuất phần còn lại"))',
            self.qt,
        )
        self.assertIn('return str(text).replace("&", "&&")', self.qt)

    def test_manual_cut_table_has_dedicated_readable_typography(self):
        self.assertIn('self.manual_cut_list.setObjectName("ManualCutTable")', self.qt)
        self.assertIn("QTableWidget#ManualCutTable", self.qt)
        self.assertIn("font-size: 10pt; font-weight: 500;", self.qt)


    def test_branding_workspace_has_a_balanced_preview_and_wider_inspector(self):
        self.assertIn('preview_title = QLabel("XEM TRƯỚC VIDEO")', self.qt)
        self.assertIn('inspector.setMinimumWidth(420)', self.qt)
        self.assertIn('inspector.setMaximumWidth(470)', self.qt)
        self.assertIn('footer_frame.setObjectName("BrandingFooter")', self.qt)
        self.assertIn("QFrame#BrandingFooter", self.qt)
        self.assertIn("QTabWidget#BrandingTabs QTabBar::tab", self.qt)

    def test_export_workspace_uses_separate_preview_cut_timeline_and_qc_cards(self):
        self.assertIn('heading = QLabel("Xuất & kiểm tra")', self.qt)
        self.assertIn('preview_card.setObjectName("ExportPreviewCard")', self.qt)
        self.assertIn('cut_card.setObjectName("ExportCutCard")', self.qt)
        self.assertIn('timeline_card.setObjectName("ExportTimelineCard")', self.qt)
        self.assertIn('action_card.setObjectName("ExportActionCard")', self.qt)
        self.assertIn('status_card.setObjectName("ExportQCStatusCard")', self.qt)
        self.assertIn('inspector.setMinimumWidth(340)', self.qt)
        self.assertIn("QFrame#ExportPreviewCard", self.qt)
        self.assertIn("QFrame#ExportQCStatusCard", self.qt)

    def test_cta_detector_is_review_only_without_a_direct_cut_button(self):
        self.assertNotIn("cta_cut_btn", self.qt)
        self.assertNotIn("Cắt các khoảng đã chọn", self.qt)
        self.assertIn("Hãy kiểm tra ảnh mẫu và chữ OCR trước khi xác nhận.", self.qt)


if __name__ == "__main__":
    unittest.main()
