from __future__ import annotations

"""Hidden Tk processing engine bridge for the PySide6 desktop shell.

The existing processing engine remains in app.py. This worker owns the Tk
interpreter and all legacy processing methods; the Qt UI communicates with it
through newline-delimited JSON over stdin/stdout. No FFmpeg work runs on the Qt
GUI thread.
"""

import json
import os
import sys
# Keep OpenCV/BLAS from multiplying worker threads while games or other heavy apps run.
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "2")
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
import tempfile
import traceback
import time
import shutil
import re
import uuid
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox

import cv2
import numpy as np
from PIL import Image

try:
    cv2.setNumThreads(2)
except Exception:
    pass

import app as core

OUT = sys.__stdout__
IN = sys.__stdin__
COMMANDS: queue.Queue[dict] = queue.Queue()
STATE_DIR = Path(tempfile.gettempdir()) / "GocReviewPhim_QtBridge"
STATE_DIR.mkdir(parents=True, exist_ok=True)
PREVIEW_PATH = STATE_DIR / "preview.jpg"
MASK_PATH = STATE_DIR / "mask.png"
THUMB_DIR = STATE_DIR / "thumbs"
THUMB_DIR.mkdir(parents=True, exist_ok=True)

app_instance: core.VideoToolApp | None = None
root: tk.Tk | None = None
last_preview_signature: tuple | None = None
preview_revision = 0
thumb_cache: dict[str, str] = {}
thumb_pending: set[str] = set()
CTA_CANCEL_EVENT: threading.Event | None = None
CTA_PAUSE_EVENT: threading.Event | None = None
CTA_SCAN_THREAD: threading.Thread | None = None
CTA_SCAN_RUNNING = False
OVERLAY_CANCEL_EVENT: threading.Event | None = None
OVERLAY_SCAN_THREAD: threading.Thread | None = None
OVERLAY_SCAN_RUNNING = False
EMIT_LOCK = threading.Lock()
thumb_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="QtSceneThumb")
shutdown_requested = False


def emit(payload: dict) -> None:
    try:
        line = json.dumps(payload, ensure_ascii=True, separators=(",", ":")) + "\n"
        with EMIT_LOCK:
            OUT.write(line)
            OUT.flush()
    except Exception:
        pass


def reader() -> None:
    while True:
        line = IN.readline()
        if not line:
            COMMANDS.put({"cmd": "__stdin_closed__"})
            return
        try:
            payload = json.loads(line)
            if isinstance(payload, dict):
                COMMANDS.put(payload)
        except Exception:
            emit({"type": "error", "message": "Lệnh Qt bridge không phải JSON hợp lệ."})


def _notify(kind: str, title: str, message: str, **_kwargs):
    # Export completion and QC are shown in the main workspace, not a second modal window.
    if str(title).startswith("Đã xuất"):
        emit({"type": "export_notice", "kind": kind, "title": str(title), "message": str(message)})
    else:
        emit({"type": "notice", "kind": kind, "title": str(title), "message": str(message)})
    return "ok"


def _confirm(_title: str, _message: str, **_kwargs) -> bool:
    # Destructive actions are confirmed in the Qt shell before reaching this worker.
    return True


# Avoid a second, unstyled Tk message-box layer on top of the Qt window.
messagebox.showinfo = lambda title, message, **kw: _notify("info", title, message, **kw)
messagebox.showwarning = lambda title, message, **kw: _notify("warning", title, message, **kw)
messagebox.showerror = lambda title, message, **kw: _notify("error", title, message, **kw)
messagebox.askyesno = _confirm
messagebox.askokcancel = _confirm
messagebox.askretrycancel = _confirm


def _with_dialog_value(dialog_name: str, value: str, callback):
    original = getattr(filedialog, dialog_name)
    setattr(filedialog, dialog_name, lambda **_kwargs: value)
    try:
        return callback()
    finally:
        setattr(filedialog, dialog_name, original)


def _mark_preview_dirty() -> None:
    global preview_revision
    preview_revision += 1


def _render_preview(force: bool = False) -> None:
    global last_preview_signature
    app = app_instance
    if app is None or app.frame is None:
        return
    signature = (id(app.frame), id(app.mask), preview_revision,
                 app.frame_time_var.get() if hasattr(app, "frame_time_var") else "")
    if not force and signature == last_preview_signature and PREVIEW_PATH.exists():
        return
    frame = app.frame.copy()
    if app.mask is not None and app.show_mask.get():
        show = app.mask
        try:
            expansion = int(app._effective_mask_expansion())
        except Exception:
            expansion = 0
        if expansion > 0:
            k = max(1, expansion * 2 + 1)
            show = cv2.dilate(show, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        tint = np.zeros_like(frame)
        tint[:, :, 2] = 255
        alpha = (show > 0)[:, :, None].astype(np.float32) * 0.38
        frame = np.clip(frame.astype(np.float32) * (1.0 - alpha) + tint.astype(np.float32) * alpha,
                        0, 255).astype(np.uint8)
    if app.lasso_points and app.frame is not None:
        try:
            pts = np.array(app.lasso_points, dtype=np.int32).reshape((-1, 1, 2))
            cv2.polylines(frame, [pts], True, (203, 193, 49), 3, cv2.LINE_AA)
        except Exception:
            pass
    h, w = frame.shape[:2]
    scale = min(1600.0 / max(1, w), 900.0 / max(1, h), 1.0)
    if scale < 1.0:
        frame = cv2.resize(frame, (max(1, round(w * scale)), max(1, round(h * scale))),
                           interpolation=cv2.INTER_AREA)
    cv2.imwrite(str(PREVIEW_PATH), frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if app.mask is not None:
        try:
            cv2.imwrite(str(MASK_PATH), app.mask)
        except Exception:
            pass
    last_preview_signature = signature


def _thumb_key(video_path: str, start: float) -> str:
    return f"{str(Path(video_path).resolve())}|{float(start):.3f}"


def _make_thumb(video_path: str, start: float, key: str) -> None:
    try:
        frame = core.read_frame(video_path, start)
        h, w = frame.shape[:2]
        scale = min(180 / max(1, w), 100 / max(1, h))
        resized = cv2.resize(frame, (max(1, int(w * scale)), max(1, int(h * scale))),
                             interpolation=cv2.INTER_AREA)
        path = THUMB_DIR / (str(abs(hash(key))) + ".jpg")
        cv2.imwrite(str(path), resized, [cv2.IMWRITE_JPEG_QUALITY, 82])
        thumb_cache[key] = str(path)
    except Exception:
        thumb_cache[key] = ""
    finally:
        thumb_pending.discard(key)


def _snapshot() -> dict:
    app = app_instance
    if app is None:
        return {"ready": False}
    _render_preview()
    video_path = str(app.video_path or "")
    info = app.info or {}
    scenes = []
    if video_path:
        for i, scene in enumerate(app.scenes):
            start = float(scene.get("start", 0.0))
            end = float(scene.get("end", 0.0))
            key = _thumb_key(video_path, start)
            thumb = thumb_cache.get(key, "")
            if key not in thumb_cache and key not in thumb_pending:
                thumb_pending.add(key)
                thumb_executor.submit(_make_thumb, video_path, start, key)
            scenes.append({
                "index": i,
                "name": str(scene.get("name", f"Cảnh {i + 1}")),
                "start": start,
                "end": end,
                "start_text": app._fmt_time(start),
                "end_text": app._fmt_time(end),
                "thumbnail": thumb,
            })
    try:
        progress = float(app.progress["value"])
    except Exception:
        progress = 0.0
    frame_w = int(info.get("width", 0) or (app.frame.shape[1] if app.frame is not None else 0))
    frame_h = int(info.get("height", 0) or (app.frame.shape[0] if app.frame is not None else 0))
    return {
        "ready": True,
        "version": core.APP_VERSION,
        "project_name": app.project_name_var.get(),
        "project_path": str(app.current_project_path or ""),
        "dirty": bool(app.project_dirty),
        "autosave": bool(app.autosave_enabled_var.get()),
        "autosave_label": app.autosave_nav_var.get(),
        "video_path": video_path,
        "video_name": Path(video_path).name if video_path else "Chưa chọn video",
        "logo_path": str(app.logo_path or ""),
        "output_dir": str(app.output_dir or ""),
        "meta": app.meta_var.get(),
        "status": app.status_var.get(),
        "busy": bool(app.busy),
        "batch_active": bool(getattr(app, "batch_active", False)),
        "progress": progress,
        "duration": float(info.get("duration", 0.0) or 0.0),
        "width": frame_w,
        "height": frame_h,
        "fps": float(info.get("fps", 0.0) or 0.0),
        "codec": str(info.get("codec", "")),
        "frame_time": float(core.safe_float(app.frame_time_var.get(), "Thời điểm") if app.frame_time_var.get() else 0.0),
        "range_start": str(app.segment_start_var.get()),
        "range_end": str(app.segment_end_var.get()),
        "minute_start": str(app.segment_from_minutes_var.get()),
        "minute_end": str(app.segment_to_minutes_var.get()),
        "selected_scene": app.selected_scene_index,
        "scene_count": len(app.scenes),
        "scenes": scenes,
        "has_mask": app.mask is not None,
        "mask_pixels": int(cv2.countNonZero(app.mask)) if app.mask is not None else 0,
        "mask_tool": str(app.mask_tool_var.get()),
        "brush_size": int(app.mask_brush_size_var.get()),
        "expansion": int(app.expansion_var.get()),
        "auto_expansion": bool(app.auto_mask_expansion_var.get()),
        "show_mask": bool(app.show_mask.get()),
        "smart_mask": bool(app.auto_mask_expansion_var.get()),
        "preview_path": str(PREVIEW_PATH) if PREVIEW_PATH.exists() else "",
        "mask_path": str(MASK_PATH) if MASK_PATH.exists() else "",
        "frame_revision": preview_revision,
        "ffmpeg_status": str(app.ffmpeg_status_var.get()),
        "gpu_status": str(app.gpu_status_label.cget("text")) if getattr(app, "gpu_status_label", None) else "",
    }


def _load_video(path: str) -> None:
    app = app_instance
    if not path or not Path(path).is_file():
        raise ValueError("Không tìm thấy video nguồn.")
    # JSON commands are ASCII-escaped by the Qt shell. This avoids Windows
    # ANSI-code-page corruption of Vietnamese/non-ASCII file names.
    loaded = app.load_video_path(str(Path(path).expanduser().resolve()))
    if not loaded:
        raise RuntimeError("Không nạp video: thao tác bị hủy hoặc engine đang bận.")
    _mark_preview_dirty()


def _load_project(path: str) -> None:
    app = app_instance
    if not path or not Path(path).is_file():
        raise ValueError("Không tìm thấy file dự án.")
    if not app._confirm_unsaved_project():
        return
    ok = app._load_project_file(Path(path).expanduser().resolve())
    if not ok:
        raise RuntimeError("Không mở được dự án. Kiểm tra video nguồn và tài nguyên liên kết.")
    _mark_preview_dirty()


def _save_project(path: str | None = None, save_as: bool = False) -> None:
    app = app_instance
    if path:
        _with_dialog_value("asksaveasfilename", path, lambda: app.save_project(save_as=save_as))
    else:
        app.save_project(save_as=save_as)


def _choose_logo(path: str) -> None:
    app = app_instance
    _with_dialog_value("askopenfilename", path, app.choose_logo)


def _choose_output(path: str) -> None:
    app = app_instance
    _with_dialog_value("askdirectory", path, app.choose_output_dir)


def _set_frame_time(seconds: float, preserve_mask: bool = True) -> None:
    app = app_instance
    if not app.video_path or not app.info:
        return
    duration = float(app.info.get("duration", 0.0))
    seconds = max(0.0, min(float(seconds), max(0.0, duration - 0.05)))
    frame = core.read_frame(app.video_path, seconds)
    app.frame = frame
    app.frame_time_var.set(f"{seconds:.3f}".rstrip("0").rstrip("."))
    app.preview_seek_var.set(seconds)
    app.preview_seek_label_var.set(app._fmt_time(seconds))
    if not preserve_mask:
        app.mask = None
        app.lasso_points = []
        app.canvas_points = []
        app._clear_mask_history()
    try:
        app.refresh_canvas()
    except Exception:
        pass
    _mark_preview_dirty()


def _set_selection(points: list[list[float]], shape: str) -> None:
    app = app_instance
    if app.frame is None or len(points) < 3:
        return
    h, w = app.frame.shape[:2]
    pts = [(max(0, min(w - 1, int(round(p[0])))),
            max(0, min(h - 1, int(round(p[1]))))) for p in points]
    app._push_mask_undo()
    app.lasso_points = pts
    app.canvas_points = []
    app.mask = None
    app.show_mask.set(True)
    app._mark_project_dirty()
    app.status_var.set("Đã khoanh vùng. Chọn Tự tách nét hoặc Dùng toàn bộ vùng khoanh.")
    try:
        app.refresh_canvas()
    except Exception:
        pass
    _mark_preview_dirty()


def _mask_stroke(points: list[list[float]], erase: bool = False) -> None:
    app = app_instance
    if app.frame is None or app.mask is None or not points:
        return
    app._push_mask_undo()
    app._brush_undo_pushed = True
    for p in points:
        x, y = int(round(p[0])), int(round(p[1]))
        app._paint_mask_at(x, y, erase=erase)
    app._brush_last = None
    app._brush_undo_pushed = False
    app._mark_project_dirty()
    _mark_preview_dirty()



def _current_scene():
    app = app_instance
    idx = getattr(app, "selected_scene_index", None)
    if idx is not None and 0 <= int(idx) < len(getattr(app, "scenes", [])):
        return app.scenes[int(idx)]
    return None


def _branding_state() -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Hãy mở video và tải khung hình trước khi mở Studio Branding.")
    scene = _current_scene()
    has_override = bool(scene and isinstance(scene.get("branding"), dict))
    cfg = dict(scene.get("branding") or app.branding_config) if scene else dict(app.branding_config)
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    cfg = {**core.default_branding_config(duration), **cfg}
    logo_path = str((scene.get("branding_logo_path") if has_override else None) or app.logo_path or "")
    return {
        "config": cfg,
        "logo_path": logo_path,
        "label_text": app._branding_text(),
        "frame_time": float(core.safe_float(app.frame_time_var.get(), "Thời điểm") if app.frame_time_var.get() else 0.0),
        "duration": duration,
        "scene_index": getattr(app, "selected_scene_index", None),
        "scene_name": str(scene.get("name", "Phân cảnh đang chọn")) if scene else "",
        "scene_has_override": has_override,
        "preset_names": [x.stem for x in app._branding_preset_files()],
    }


def _branding_preview(payload: dict) -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Chưa có khung hình video để xem trước Branding.")
    frame = app.frame.copy()
    h, w = frame.shape[:2]
    cfg = {**core.default_branding_config(float((app.info or {}).get("duration", 0.0) or 0.0)),
           **(payload.get("config") if isinstance(payload.get("config"), dict) else {})}
    logo_path = str(payload.get("logo_path", app.logo_path or ""))
    label_text = str(payload.get("label_text") or app._branding_text())
    try:
        seconds = float(app.frame_time_var.get() or 0.0)
    except Exception:
        seconds = 0.0
    start = max(0.0, float(cfg.get("show_from", 0.0)))
    end = max(start, float(cfg.get("show_to", (app.info or {}).get("duration", 0.0) or 0.0)))
    logo_layer, _label_layer = core.build_branding_components(w, h, logo_path, label_text, cfg)
    alpha = logo_layer[:, :, 3]
    ys, xs = np.where(alpha > 4)
    logo_rect = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1] if xs.size else None
    if start <= seconds < end:
        overlay = core.build_overlay(w, h, logo_path, label_text, branding_config=cfg)
        rendered = core.apply_mask_and_overlay(frame, None, 0, overlay)
    else:
        rendered = frame
    preview_frame = rendered
    preview_scale = min(1600.0 / max(1, w), 900.0 / max(1, h), 1.0)
    if preview_scale < 1.0:
        preview_frame = cv2.resize(rendered, (max(1, round(w * preview_scale)),
                                               max(1, round(h * preview_scale))),
                                   interpolation=cv2.INTER_AREA)
    target = STATE_DIR / f"branding_preview_{uuid.uuid4().hex}.jpg"
    if not cv2.imwrite(str(target), preview_frame, [cv2.IMWRITE_JPEG_QUALITY, 90]):
        raise RuntimeError("Không ghi được ảnh xem trước Branding.")
    return {
        "preview_path": str(target), "logo_rect": logo_rect,
        "frame_width": int(w), "frame_height": int(h),
        "preview_token": payload.get("preview_token"),
    }


def _branding_apply(payload: dict) -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Chưa có video để áp dụng Branding.")
    cfg = payload.get("config")
    if not isinstance(cfg, dict):
        raise ValueError("Thiết lập Branding không hợp lệ.")
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    new_cfg = {**core.default_branding_config(duration), **cfg}
    show_from = max(0.0, float(new_cfg.get("show_from", 0.0)))
    show_to = max(0.0, float(new_cfg.get("show_to", duration)))
    if show_to < show_from:
        raise ValueError("Mốc kết thúc Branding phải lớn hơn hoặc bằng mốc bắt đầu.")
    if duration and show_to > duration + 0.05:
        raise ValueError(f"Mốc kết thúc vượt thời lượng video ({app._fmt_time(duration)}).")
    logo_path = str(payload.get("logo_path", "") or "")
    if bool(new_cfg.get("logo_enabled", True)) and (not logo_path or not Path(logo_path).is_file()):
        raise ValueError("Logo đang bật nhưng file ảnh không tồn tại. Hãy chọn lại logo hoặc tắt hiển thị logo.")
    # The label text remains a project-level field shared by the renderer.
    # Parse it into the existing legacy label variables so Qt and export stay in sync.
    label_text = str(payload.get("label_text", "") or "").strip()
    if label_text:
        known_types = ("Tập", "Phần", "Chương")
        matched = False
        for label_type in known_types:
            prefix = label_type + " "
            if label_text.casefold().startswith(prefix.casefold()):
                app.label_type_var.set(label_type)
                app.label_value_var.set(label_text[len(prefix):].strip())
                matched = True
                break
        if not matched:
            app.label_type_var.set("Tùy chỉnh")
            app.label_value_var.set(label_text)

    scene_scope = bool(payload.get("scene_scope", False))
    scene = _current_scene()
    if scene_scope:
        if scene is None:
            raise ValueError("Chưa chọn phân cảnh để áp dụng Branding riêng.")
        scene["branding"] = new_cfg
        scene["branding_logo_path"] = logo_path
        message = f"Đã áp dụng Branding riêng cho {scene.get('name', 'phân cảnh')}."
    else:
        app.branding_config = new_cfg
        app.logo_path = logo_path
        try:
            app.logo_var.set(Path(logo_path).name if logo_path else "")
        except Exception:
            pass
        message = "Đã áp dụng Branding cho toàn dự án."
    app._mark_project_dirty()
    try:
        app.refresh_canvas()
    except Exception:
        pass
    _mark_preview_dirty()
    app.status_var.set(message)
    return {"ok": True, "message": message, "branding_state": _branding_state()}


def _branding_preset_save(payload: dict) -> dict:
    app = app_instance
    name = re.sub(r"[^\w.-]+", "_", str(payload.get("name", "")).strip(), flags=re.UNICODE).strip("._ ")
    if not name:
        raise ValueError("Tên preset không hợp lệ.")
    if len(name) > 64:
        name = name[:64]
    cfg = payload.get("config")
    if not isinstance(cfg, dict):
        raise ValueError("Thiết lập preset không hợp lệ.")
    folder = app._branding_presets_dir()
    logo_path = str(payload.get("logo_path", "") or "")
    stored_logo = ""
    if logo_path:
        source = Path(logo_path)
        if not source.is_file():
            raise FileNotFoundError("Không tìm thấy file logo để đóng gói vào preset.")
        asset_dir = folder / "assets"
        asset_dir.mkdir(parents=True, exist_ok=True)
        target = asset_dir / f"{name}{source.suffix.lower()}"
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        stored_logo = str(target)
    target_json = folder / f"{name}.json"
    record = {"format": "goc-review-phim-branding-preset", "version": 1,
              "branding": cfg, "logo_file": stored_logo}
    tmp = target_json.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(target_json)
    return {"ok": True, "name": name, "preset_names": [x.stem for x in app._branding_preset_files()]}


def _branding_preset_load(payload: dict) -> dict:
    app = app_instance
    name = str(payload.get("name", "")).strip()
    if not name or Path(name).name != name:
        raise ValueError("Tên preset không hợp lệ.")
    target = app._branding_presets_dir() / f"{name}.json"
    if not target.is_file():
        raise FileNotFoundError("Không tìm thấy preset đã chọn.")
    record = json.loads(target.read_text(encoding="utf-8"))
    if record.get("format") != "goc-review-phim-branding-preset":
        raise ValueError("File preset không đúng định dạng Góc Review Phim.")
    logo = str(record.get("logo_file", "") or "")
    if logo and not Path(logo).is_file():
        logo = ""
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    cfg = {**core.default_branding_config(duration), **(record.get("branding") or {})}
    return {"ok": True, "name": name, "config": cfg,
            "logo_path": logo or str(app.logo_path or ""),
            "preset_names": [x.stem for x in app._branding_preset_files()]}


def _branding_preset_delete(payload: dict) -> dict:
    app = app_instance
    name = str(payload.get("name", "")).strip()
    if not name or Path(name).name != name:
        raise ValueError("Tên preset không hợp lệ.")
    target = app._branding_presets_dir() / f"{name}.json"
    if not target.is_file():
        raise FileNotFoundError("Không tìm thấy preset cần xóa.")
    target.unlink()
    return {"ok": True, "preset_names": [x.stem for x in app._branding_preset_files()]}


def _compare_frame() -> dict:
    app = app_instance
    if app is None or app.frame is None:
        raise RuntimeError("Hãy mở video và tải khung hình trước khi so sánh.")
    source = app.frame.copy()
    mask = app.mask.copy() if app.mask is not None else None
    if mask is None or cv2.countNonZero(mask) == 0:
        raise RuntimeError("Chưa có mask để so sánh. Hãy khoanh vùng rồi tạo mask trước.")
    if mask.shape[:2] != source.shape[:2]:
        raise RuntimeError("Kích thước mask không khớp khung hình hiện tại. Hãy nạp lại phân cảnh hoặc tạo mask mới.")
    expansion = int(app._effective_mask_expansion(mask))
    empty_overlay = np.zeros((source.shape[0], source.shape[1], 4), dtype=np.uint8)
    processed = core.apply_mask_and_overlay(source.copy(), mask, expansion, empty_overlay)
    compare_scale = min(1920.0 / max(1, source.shape[1]), 1080.0 / max(1, source.shape[0]), 1.0)
    if compare_scale < 1.0:
        out_size = (max(1, round(source.shape[1] * compare_scale)),
                    max(1, round(source.shape[0] * compare_scale)))
        source_display = cv2.resize(source, out_size, interpolation=cv2.INTER_AREA)
        processed_display = cv2.resize(processed, out_size, interpolation=cv2.INTER_AREA)
    else:
        source_display, processed_display = source, processed
    before_path = STATE_DIR / f"compare_before_{uuid.uuid4().hex}.jpg"
    after_path = STATE_DIR / f"compare_after_{uuid.uuid4().hex}.jpg"
    if not cv2.imwrite(str(before_path), source_display, [cv2.IMWRITE_JPEG_QUALITY, 91]):
        raise RuntimeError("Không lưu được ảnh gốc để so sánh.")
    if not cv2.imwrite(str(after_path), processed_display, [cv2.IMWRITE_JPEG_QUALITY, 91]):
        raise RuntimeError("Không lưu được ảnh sau Inpaint để so sánh.")
    return {"before_path": str(before_path), "after_path": str(after_path),
            "frame_time": float(core.safe_float(app.frame_time_var.get(), "Thời điểm") if app.frame_time_var.get() else 0.0),
            "width": int(source.shape[1]), "height": int(source.shape[0]),
            "mask_pixels": int(cv2.countNonZero(mask)), "expansion": expansion,
            "note": "Ảnh SAU đã áp dụng Inpaint theo mask và PX hiện tại; chưa bao gồm Branding."}


def _overlay_thumbnails(video_path: str, candidates: list[dict], token: str) -> list[dict]:
    """Attach readable preview thumbnails to overlay candidates for the Qt page."""
    thumb_root = STATE_DIR / "overlay_thumbs"
    thumb_root.mkdir(parents=True, exist_ok=True)
    prepared = []
    for index, raw in enumerate(candidates):
        item = dict(raw)
        sample_time = float(item.get("sample_time", 0.0) or 0.0)
        frame = core.read_frame(video_path, sample_time)
        thumb_path = thumb_root / f"overlay_{token}_{index}.jpg"
        if frame is not None and getattr(frame, "size", 0):
            h, w = frame.shape[:2]
            x = max(0, min(w - 1, int(item.get("x", 0))))
            y = max(0, min(h - 1, int(item.get("y", 0))))
            x2 = max(x + 1, min(w - 1, x + max(1, int(item.get("w", 1)))))
            y2 = max(y + 1, min(h - 1, y + max(1, int(item.get("h", 1)))))
            cv2.rectangle(frame, (x, y), (x2, y2), (40, 235, 220), 4)
            cv2.putText(frame, str(item.get("category", "Overlay")), (x, max(26, y - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.85, (40, 235, 220), 2, cv2.LINE_AA)
            fh, fw = frame.shape[:2]
            scale = min(900.0 / max(1, fw), 520.0 / max(1, fh), 1.0)
            if scale < 1.0:
                frame = cv2.resize(frame, (max(1, round(fw * scale)), max(1, round(fh * scale))), interpolation=cv2.INTER_AREA)
            if cv2.imwrite(str(thumb_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 88]):
                item["preview_path"] = str(thumb_path)
        prepared.append(item)
    return prepared


def _start_overlay_scan(scan_mode: str) -> dict:
    global OVERLAY_CANCEL_EVENT, OVERLAY_SCAN_THREAD, OVERLAY_SCAN_RUNNING
    app = app_instance
    if app is None or not app.video_path or not Path(app.video_path).is_file():
        raise ValueError("Hãy mở video nguồn trước khi phát hiện lớp phủ.")
    if bool(app.busy) or CTA_SCAN_RUNNING or OVERLAY_SCAN_RUNNING:
        raise RuntimeError("Engine đang bận hoặc một lượt quét khác đang chạy.")
    mode = str(scan_mode or "standard").strip().lower()
    if mode not in {"quick", "standard", "deep", "transient"}:
        mode = "standard"
    cancel = threading.Event()
    OVERLAY_CANCEL_EVENT = cancel
    OVERLAY_SCAN_RUNNING = True
    video_path = str(app.video_path)
    scan_token = uuid.uuid4().hex

    def progress(done: int, total: int) -> None:
        emit({"type": "overlay_progress", "payload": {"done": int(done), "total": int(total)}})

    def scan() -> None:
        global OVERLAY_SCAN_RUNNING, OVERLAY_CANCEL_EVENT
        try:
            result = core.detect_static_watermark_candidates(
                video_path, max_samples=20, cancel_event=cancel,
                progress_callback=progress, scan_mode=mode)
            if cancel.is_set():
                emit({"type": "overlay_cancelled", "message": "Đã dừng quét lớp phủ."})
            else:
                candidates = _overlay_thumbnails(video_path, result.get("candidates", []), scan_token)
                payload = dict(result)
                payload["candidates"] = candidates
                emit({"type": "overlay_done", "payload": payload})
        except Exception as exc:
            if cancel.is_set():
                emit({"type": "overlay_cancelled", "message": "Đã dừng quét lớp phủ."})
            else:
                emit({"type": "overlay_error", "message": str(exc)})
        finally:
            OVERLAY_SCAN_RUNNING = False
            OVERLAY_CANCEL_EVENT = None

    OVERLAY_SCAN_THREAD = threading.Thread(target=scan, name="QtOverlayScan", daemon=True)
    OVERLAY_SCAN_THREAD.start()
    return {"ok": True, "scan_mode": mode}


def _cancel_overlay_scan() -> dict:
    if OVERLAY_CANCEL_EVENT is not None:
        OVERLAY_CANCEL_EVENT.set()
    return {"ok": True}


def _apply_overlay_candidate(candidate: dict) -> dict:
    app = app_instance
    if app is None or not app.video_path:
        raise RuntimeError("Hãy mở video nguồn trước khi áp dụng vùng lớp phủ.")
    x = int(candidate.get("x", 0)); y = int(candidate.get("y", 0))
    w = max(1, int(candidate.get("w", 1))); h = max(1, int(candidate.get("h", 1)))
    _set_frame_time(float(candidate.get("sample_time", 0.0) or 0.0), preserve_mask=False)
    _set_selection([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], "rect")
    app.use_selection_mask()
    _mark_preview_dirty()
    return {"ok": True, "category": str(candidate.get("category", "Overlay")), "x": x, "y": y, "w": w, "h": h}

def _start_cta_scan(interval: float) -> dict:
    global CTA_CANCEL_EVENT, CTA_PAUSE_EVENT, CTA_SCAN_THREAD, CTA_SCAN_RUNNING
    app = app_instance
    if app is None or not app.video_path or not Path(app.video_path).is_file():
        raise ValueError("Hãy mở video nguồn trước khi quét CTA.")
    if bool(app.busy) or CTA_SCAN_RUNNING:
        raise RuntimeError("Engine đang bận hoặc Subscribe Detector đã chạy.")
    ocr_status = core.get_subscribe_ocr_status()
    if not ocr_status.get("ready"):
        message = str(ocr_status.get("message", "Tesseract OCR chưa sẵn sàng."))
        detail = str(ocr_status.get("detail", "")).strip()
        raise RuntimeError(message + (f"\n\nChi tiết kỹ thuật:\n{detail}" if detail else ""))
    if ocr_status.get("warning"):
        emit({"type": "cta_ocr_warning", "message": str(ocr_status["warning"])})
    if interval not in (0.5, 1.0, 2.0):
        interval = 1.0
    cancel = threading.Event()
    pause = threading.Event()
    CTA_CANCEL_EVENT = cancel
    CTA_PAUSE_EVENT = pause
    CTA_SCAN_RUNNING = True
    app.cta_scan_running = True
    video_path = str(app.video_path)
    thumb_root = STATE_DIR / "cta_thumbs"
    thumb_root.mkdir(parents=True, exist_ok=True)
    scan_token = uuid.uuid4().hex
    thumb_times: dict[int, float] = {}

    def _with_live_thumbnails(raw_candidates: list[dict], force: bool = False) -> list[dict]:
        prepared = []
        for raw in raw_candidates:
            item = dict(raw)
            scan_id = int(item.get("scan_id", len(prepared)))
            sample_time = float(item.get("sample_time", item.get("start", 0.0)))
            thumb_path = thumb_root / f"cta_{scan_token}_{scan_id}.jpg"
            last_time = thumb_times.get(scan_id)
            # Create one representative thumbnail when the interval first
            # appears; refresh the thumbnail once at finalization. This avoids
            # launching an FFmpeg frame-extraction process on every live update.
            if force or last_time is None:
                frame = core.read_frame(video_path, sample_time)
                if frame is not None and getattr(frame, "size", 0):
                    x, y = int(item.get("x", 0)), int(item.get("y", 0))
                    w, h = int(item.get("w", 0)), int(item.get("h", 0))
                    if w > 0 and h > 0:
                        cv2.rectangle(frame, (x, y), (x + w, y + h), (210, 235, 40), 3)
                    fh, fw = frame.shape[:2]
                    scale = min(720.0 / max(1, fw), 420.0 / max(1, fh), 1.0)
                    if scale < 1.0:
                        frame = cv2.resize(frame, (max(1, round(fw * scale)), max(1, round(fh * scale))), interpolation=cv2.INTER_AREA)
                    if cv2.imwrite(str(thumb_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 86]):
                        thumb_times[scan_id] = sample_time
            item["preview_path"] = str(thumb_path) if thumb_path.is_file() else ""
            prepared.append(item)
        return prepared

    def report(done: int, total: int) -> None:
        emit({"type": "cta_progress", "payload": {"done": int(done), "total": int(total)}})

    def report_candidates(raw_candidates: list[dict], done: int, total: int) -> None:
        if cancel.is_set():
            return
        prepared = _with_live_thumbnails(raw_candidates)
        emit({"type": "cta_update", "payload": {
            "done": int(done), "total": int(total),
            "candidates": prepared, "found": len(prepared),
        }})

    def report_phase(phase: str, done: int, total: int) -> None:
        labels = {
            "pass1": "Lượt 1/2 · rà nhanh toàn video",
            "pass2": "Lượt 2/2 · kiểm tra kỹ vùng nghi vấn",
            "done": "Hoàn tất hai lượt quét",
        }
        emit({"type": "cta_phase", "payload": {
            "phase": str(phase), "label": labels.get(str(phase), str(phase)),
            "done": int(done), "total": int(total),
        }})

    def on_paused() -> None:
        emit({"type": "cta_paused", "message": "Đã tạm dừng. Kết quả Subscribe đã phát hiện vẫn được giữ nguyên."})

    def scan() -> None:
        global CTA_SCAN_RUNNING
        try:
            result = core.detect_cta_image_candidates(
                video_path, sample_interval=interval, max_samples=1800,
                cancel_event=cancel, pause_event=pause,
                progress_callback=report, pause_callback=on_paused,
                candidate_callback=report_candidates, phase_callback=report_phase)
            candidates = _with_live_thumbnails(result.get("candidates", []), force=True)
            emit({"type": "cta_done", "payload": {
                "duration": float(result.get("duration", 0)),
                "samples": int(result.get("samples", 0)),
                "sample_interval": float(result.get("sample_interval", interval)),
                "candidates": candidates,
                "pass1_samples": int(result.get("pass1_samples", 0)),
                "pass2_samples": int(result.get("pass2_samples", 0)),
                "note": str(result.get("note", "")),
            }})
        except Exception as exc:
            if cancel.is_set() or isinstance(exc, getattr(core, "CTAScanCancelled", Exception)):
                emit({"type": "cta_cancelled", "message": str(exc) or "Đã dừng quét CTA. Các ứng viên đã phát hiện vẫn được giữ lại."})
            else:
                emit({"type": "cta_error", "message": str(exc)})
        finally:
            CTA_SCAN_RUNNING = False
            try:
                if app_instance is not None:
                    app_instance.cta_scan_running = False
            except Exception:
                pass

    CTA_SCAN_THREAD = threading.Thread(target=scan, name="QtCTAImageScan", daemon=True)
    CTA_SCAN_THREAD.start()
    return {"ok": True, "started": True, "interval": interval, "max_samples": 1800}


def _pause_cta_scan() -> dict:
    if CTA_SCAN_RUNNING and CTA_PAUSE_EVENT is not None:
        CTA_PAUSE_EVENT.set()
        return {"ok": True, "pause_requested": True}
    return {"ok": True, "pause_requested": False}


def _resume_cta_scan() -> dict:
    if CTA_SCAN_RUNNING and CTA_PAUSE_EVENT is not None:
        CTA_PAUSE_EVENT.clear()
        emit({"type": "cta_resumed", "message": "Đang tiếp tục quét từ vị trí đã tạm dừng…"})
        return {"ok": True, "resumed": True}
    return {"ok": True, "resumed": False}


def _cancel_cta_scan() -> dict:
    if CTA_CANCEL_EVENT is not None and CTA_SCAN_RUNNING:
        CTA_CANCEL_EVENT.set()
        if CTA_PAUSE_EVENT is not None:
            CTA_PAUSE_EVENT.clear()
        return {"ok": True, "cancelling": True}
    return {"ok": True, "cancelling": False}

def _prepare_cta_ranges(ranges: list[dict], duration: float) -> list[tuple[float, float]]:
    """Validate, clamp and merge user-approved CTA intervals without touching project state."""
    if duration <= 0:
        raise ValueError("Thời lượng video không hợp lệ.")
    proposed = []
    for raw in ranges or []:
        if not isinstance(raw, dict):
            raise ValueError("Dữ liệu khoảng Subscribe không hợp lệ.")
        try:
            start = float(raw.get("start", 0.0))
            end = float(raw.get("end", 0.0))
        except (TypeError, ValueError, OverflowError):
            raise ValueError("Mốc CTA phải là số hợp lệ.")
        if not (np.isfinite(start) and np.isfinite(end)):
            raise ValueError("Mốc CTA không được là NaN hoặc vô cực.")
        start = max(0.0, min(float(duration), start))
        end = max(0.0, min(float(duration), end))
        if end <= start or end - start < 0.05:
            raise ValueError("Một khoảng Subscribe không hợp lệ. Hãy kiểm tra mốc bắt đầu/kết thúc.")
        proposed.append((start, end))
    normalized = core.normalize_excluded_ranges(proposed, duration=duration)
    if not normalized:
        raise ValueError("Chưa có khoảng Subscribe hợp lệ được chọn.")
    return normalized


def _cut_cta_ranges(ranges: list[dict]) -> dict:
    app = app_instance
    if app is None or not app.video_path or not app.info:
        raise RuntimeError("Không có video nguồn để cắt CTA.")
    duration = float((app.info or {}).get("duration", 0.0) or 0.0)
    if duration <= 0:
        raise RuntimeError("Không đọc được thời lượng video nguồn.")
    proposed = _prepare_cta_ranges(ranges, duration)
    old_ranges = list(getattr(app, "excluded_ranges", []) or [])
    app.excluded_ranges = core.normalize_excluded_ranges(old_ranges + proposed, duration=duration)
    app._mark_project_dirty()
    app.export_full()
    if not bool(app.busy):
        app.excluded_ranges = old_ranges
        app._mark_project_dirty()
        raise RuntimeError("Không thể bắt đầu xuất video. Các khoảng bỏ cũ đã được khôi phục.")
    return {"ok": True, "started": True, "selected_ranges": len(proposed),
            "removed_seconds": round(sum(end-start for start,end in proposed), 3)}


def _run_command(payload: dict) -> Any:
    app = app_instance
    cmd = str(payload.get("cmd", ""))
    if cmd == "__stdin_closed__":
        return {"shutdown": True}
    if cmd == "state":
        return _snapshot()
    if cmd == "choose_video":
        _load_video(str(payload.get("path", "")))
    elif cmd == "open_project":
        _load_project(str(payload.get("path", "")))
    elif cmd == "save_project":
        _save_project(str(payload.get("path", "")) or None, bool(payload.get("save_as", False)))
    elif cmd == "choose_logo":
        _choose_logo(str(payload.get("path", "")))
    elif cmd == "choose_output":
        _choose_output(str(payload.get("path", "")))
    elif cmd == "set_frame_time":
        _set_frame_time(float(payload.get("seconds", 0.0)), bool(payload.get("preserve_mask", True)))
    elif cmd == "set_range":
        app.segment_start_var.set(str(payload.get("start", 0)))
        app.segment_end_var.set(str(payload.get("end", 0)))
        try:
            app.segment_from_minutes_var.set(str(float(payload.get("start", 0)) / 60.0))
            app.segment_to_minutes_var.set(str(float(payload.get("end", 0)) / 60.0))
        except Exception:
            pass
        app._timeline_redraw()
        app._mark_project_dirty()
    elif cmd == "set_selection":
        _set_selection(payload.get("points", []), str(payload.get("shape", "lasso")))
    elif cmd == "mask_stroke":
        _mask_stroke(payload.get("points", []), bool(payload.get("erase", False)))
    elif cmd == "set_mask_tool":
        app.set_mask_tool(str(payload.get("mode", "lasso")))
    elif cmd == "set_brush_size":
        app.mask_brush_size_var.set(max(4, min(100, int(payload.get("value", 24)))))
    elif cmd == "set_expansion":
        app.expansion_var.set(max(0, min(30, int(payload.get("value", 14)))))
        app._on_expansion_manual_changed()
        app._mark_project_dirty()
        _mark_preview_dirty()
    elif cmd == "set_auto_expansion":
        app.auto_mask_expansion_var.set(bool(payload.get("value", True)))
        app._on_mask_mode_changed(reset_override=False)
        app._mark_project_dirty()
        _mark_preview_dirty()
    elif cmd == "set_show_mask":
        app.show_mask.set(bool(payload.get("value", True)))
        _mark_preview_dirty()
    elif cmd == "use_selection_mask":
        app.use_selection_mask()
        _mark_preview_dirty()
    elif cmd == "auto_extract":
        app.auto_extract()
        _mark_preview_dirty()
    elif cmd == "clear_selection":
        app.clear_selection()
        _mark_preview_dirty()
    elif cmd == "undo":
        app.undo_mask()
        _mark_preview_dirty()
    elif cmd == "redo":
        app.redo_mask()
        _mark_preview_dirty()
    elif cmd == "select_scene":
        app._scene_card_select(int(payload.get("index", 0)))
        _mark_preview_dirty()
    elif cmd == "add_scene":
        app.segment_start_var.set(str(payload.get("start", app.segment_start_var.get())))
        app.segment_end_var.set(str(payload.get("end", app.segment_end_var.get())))
        app.add_scene()
    elif cmd == "update_scene":
        if payload.get("start") is not None:
            start = float(payload.get("start"))
            app.segment_start_var.set(str(start))
            app.segment_from_minutes_var.set(str(start / 60.0))
        if payload.get("end") is not None:
            end = float(payload.get("end"))
            app.segment_end_var.set(str(end))
            app.segment_to_minutes_var.set(str(end / 60.0))
        app.update_selected_scene()
    elif cmd == "split_scene":
        if payload.get("seconds") is not None:
            app.frame_time_var.set(str(payload["seconds"]))
        app.split_selected_scene()
    elif cmd == "delete_scene":
        app.delete_selected_scene()
    elif cmd == "branding_state":
        return _branding_state()
    elif cmd == "branding_preview":
        return _branding_preview(payload)
    elif cmd == "branding_apply":
        return _branding_apply(payload)
    elif cmd == "branding_preset_save":
        return _branding_preset_save(payload)
    elif cmd == "branding_preset_load":
        return _branding_preset_load(payload)
    elif cmd == "branding_preset_delete":
        return _branding_preset_delete(payload)
    elif cmd == "compare_frame":
        return _compare_frame()
    elif cmd == "overlay_scan_start":
        return _start_overlay_scan(str(payload.get("mode", "standard")))
    elif cmd == "overlay_scan_cancel":
        return _cancel_overlay_scan()
    elif cmd == "overlay_apply_candidate":
        return _apply_overlay_candidate(payload.get("candidate") or {})
    elif cmd == "open_branding":
        app.open_branding_studio()
    elif cmd == "open_detector":
        app.open_watermark_detection()
    elif cmd == "open_cta_detector":
        # Compatibility command for older shells; the current Qt shell embeds CTA in its workspace.
        app.open_cta_detection()
    elif cmd == "cta_scan_start":
        return _start_cta_scan(float(payload.get("interval", 1.0)))
    elif cmd == "cta_scan_pause":
        return _pause_cta_scan()
    elif cmd == "cta_scan_resume":
        return _resume_cta_scan()
    elif cmd == "cta_scan_cancel":
        return _cancel_cta_scan()
    elif cmd == "cta_cut_selected":
        return _cut_cta_ranges(payload.get("ranges", []))
    elif cmd == "open_compare":
        app.open_mask_comparison()
    elif cmd == "capture_preview":
        path = str(payload.get("path", ""))
        if path:
            _with_dialog_value("asksaveasfilename", path, app.capture_preview_frame)
        else:
            app.capture_preview_frame()
    elif cmd == "open_batch":
        app.open_batch_dialog()
    elif cmd == "open_qc":
        app.open_quality_check_dialog()
    elif cmd == "open_merge":
        app.open_merge_dialog()
    elif cmd == "export_preview":
        if payload.get("start") is not None:
            app.preview_start_var.set(str(max(0.0, float(payload.get("start", 0.0)))))
        app.export_preview()
    elif cmd == "export_segment":
        # Atomic In/Out update plus export; avoids two-message ordering races from Qt.
        if payload.get("start") is not None or payload.get("end") is not None:
            current_start = float(core.safe_float(app.segment_start_var.get(), "Mốc bắt đầu") or 0.0)
            current_end = float(core.safe_float(app.segment_end_var.get(), "Mốc kết thúc") or 0.0)
            start = float(payload.get("start", current_start))
            end = float(payload.get("end", current_end))
            if not (start >= 0.0 and end > start):
                raise ValueError("Khoảng xuất không hợp lệ: mốc kết thúc phải lớn hơn mốc bắt đầu.")
            duration = float((app.info or {}).get("duration", 0.0) or 0.0)
            if duration and end > duration + 0.05:
                raise ValueError(f"Mốc kết thúc vượt thời lượng video ({duration:.2f} giây).")
            app.segment_start_var.set(str(start))
            app.segment_end_var.set(str(end))
            app.segment_from_minutes_var.set(f"{start / 60.0:.4f}".rstrip("0").rstrip("."))
            app.segment_to_minutes_var.set(f"{end / 60.0:.4f}".rstrip("0").rstrip("."))
            app._timeline_redraw()
            app._mark_project_dirty()
        app.export_segment()
    elif cmd == "export_full":
        app.export_full()
    elif cmd == "stop_export":
        if getattr(app, "batch_active", False):
            app._batch_stop()
        else:
            app.stop_export()
    elif cmd == "gpu_check":
        app.check_gpu_status()
    elif cmd == "set_autosave":
        app.autosave_enabled_var.set(bool(payload.get("value", True)))
        app._on_autosave_setting_changed()
    elif cmd == "shutdown":
        return {"shutdown": True}
    else:
        raise ValueError(f"Lệnh chưa hỗ trợ: {cmd}")
    return {"ok": True}


def _poll_commands() -> None:
    global shutdown_requested
    try:
        while True:
            payload = COMMANDS.get_nowait()
            request_id = payload.get("id")
            try:
                result = _run_command(payload)
                emit({"type": "reply", "id": request_id, "result": result})
                if isinstance(result, dict) and result.get("shutdown"):
                    shutdown_requested = True
            except Exception as exc:
                emit({"type": "reply", "id": request_id,
                      "error": str(exc), "trace": traceback.format_exc(limit=5)})
    except queue.Empty:
        pass
    if shutdown_requested:
        if OVERLAY_CANCEL_EVENT is not None:
            OVERLAY_CANCEL_EVENT.set()
        try:
            if app_instance and app_instance.busy:
                app_instance.stop_export()
        except Exception:
            pass
        try:
            thumb_executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        try:
            root.destroy()
        except Exception:
            pass
        return
    root.after(35, _poll_commands)


def _publish_state() -> None:
    try:
        emit({"type": "state", "payload": _snapshot()})
    except Exception:
        emit({"type": "worker_warning", "message": traceback.format_exc(limit=3)})
    if not shutdown_requested:
        root.after(450, _publish_state)


def _set_background_priority() -> str:
    """Yield CPU scheduling to foreground apps (e.g. games) on Windows."""
    try:
        if os.name == "nt":
            import ctypes
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.GetCurrentProcess.restype = ctypes.c_void_p
            kernel32.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            kernel32.SetPriorityClass.restype = ctypes.c_int
            handle = kernel32.GetCurrentProcess()
            # BELOW_NORMAL_PRIORITY_CLASS: FFmpeg children inherit the worker priority.
            if kernel32.SetPriorityClass(handle, 0x00004000):
                return "BELOW_NORMAL"
            return f"UNCHANGED(winerror={ctypes.get_last_error()})"
        try:
            os.nice(5)
            return "NICE+5"
        except Exception:
            return "DEFAULT"
    except Exception:
        return "DEFAULT"


def main() -> int:
    global app_instance, root
    priority_mode = _set_background_priority()
    # Keep stdout reserved for JSON protocol; legacy logs go to stderr.
    sys.stdout = sys.stderr
    root = tk.Tk()
    root.withdraw()
    app_instance = core.VideoToolApp(root)
    root.withdraw()
    # Export completion reports are forwarded to the Qt shell instead of opening a second legacy report window.
    app_instance._show_quality_report = lambda report: emit({"type": "qc_report", "payload": report})
    threading.Thread(target=reader, name="QtBridgeReader", daemon=True).start()
    emit({"type": "engine_ready", "version": core.APP_VERSION, "priority_mode": priority_mode,
          "opencv_threads": 2})
    root.after(40, _poll_commands)
    root.after(300, _publish_state)
    root.mainloop()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc(file=sys.stderr)
        raise
