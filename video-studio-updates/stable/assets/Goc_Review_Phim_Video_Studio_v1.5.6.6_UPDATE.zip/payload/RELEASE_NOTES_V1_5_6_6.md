# Góc Review Phim Video Studio v1.5.6.6

## Embedded Overlay Detector

- Đưa **Phát hiện lớp phủ** vào workspace Mask & Before / After, không mở cửa sổ Tk riêng.
- Thêm mức quét, tiến độ, danh sách vùng phát hiện, thumbnail xem lại và mô tả độ tin cậy.
- Có thể đưa vùng đã chọn thẳng vào Mask, sau đó tiếp tục tinh chỉnh bằng Brush/Eraser.
- Giữ nguyên cơ chế quét heuristic, CTA Detector, dữ liệu dự án và toàn bộ pipeline xuất video.
