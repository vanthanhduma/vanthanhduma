"""Local Subscribe CTA detector.

Detects on-screen Subscribe calls-to-action only (English/Vietnamese text,
button/play-icon graphics, and short visual animations). It does not analyse
audio or speech. Results are review suggestions and must be manually approved
before cutting.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import shutil
import threading
import time
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np


class CTAScanCancelled(Exception):
    """Raised when the user stops a CTA scan."""


_TESSERACT = None
_TESSERACT_PATH = None
_TESSERACT_LANGS: set[str] | None = None
_TESSDATA_DIR: Path | None = None


def _find_tesseract_path() -> str | None:
    """Find the Tesseract executable on Windows and Unix-like systems."""
    configured = os.environ.get("TESSERACT_CMD", "").strip()
    candidates = [configured, shutil.which("tesseract")]
    if os.name == "nt":
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local_app = os.environ.get("LOCALAPPDATA", "")
        candidates.extend([
            str(Path(program_files) / "Tesseract-OCR" / "tesseract.exe"),
            str(Path(program_files_x86) / "Tesseract-OCR" / "tesseract.exe"),
            str(Path(local_app) / "Programs" / "Tesseract-OCR" / "tesseract.exe") if local_app else "",
        ])
    for value in candidates:
        if value and Path(value).is_file():
            return str(Path(value).resolve())
        if value and shutil.which(value):
            return shutil.which(value)
    return None


def _bundled_tessdata_dir() -> Path | None:
    """Return the app-local language-data folder after validating both models."""
    candidate = Path(__file__).resolve().parent / "assets" / "tessdata"
    required = (candidate / "eng.traineddata", candidate / "vie.traineddata")
    if all(item.is_file() and item.stat().st_size > 100_000 for item in required):
        return candidate.resolve()
    return None


def _user_tessdata_dir() -> Path:
    """Stable, user-writable fallback for model files on Windows."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return base / "GocReviewVideoStudio" / "ocr" / "tessdata"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _copy_tessdata_to_user_cache(source: Path) -> Path:
    """Copy bundled models to a writable local path if the app folder is unreadable."""
    target = _user_tessdata_dir()
    target.mkdir(parents=True, exist_ok=True)
    for language in ("eng", "vie"):
        src = source / f"{language}.traineddata"
        dst = target / src.name
        if not src.is_file() or src.stat().st_size <= 100_000:
            raise RuntimeError(f"Thiếu hoặc hỏng model OCR: {src}")
        if dst.is_file() and dst.stat().st_size == src.stat().st_size:
            try:
                if _sha256_file(dst) == _sha256_file(src):
                    continue
            except OSError:
                pass
        temp = dst.with_suffix(dst.suffix + ".tmp")
        shutil.copy2(src, temp)
        if temp.stat().st_size != src.stat().st_size or _sha256_file(temp) != _sha256_file(src):
            temp.unlink(missing_ok=True)
            raise RuntimeError(f"Không thể sao chép đầy đủ model OCR: {src.name}")
        os.replace(temp, dst)
    return target.resolve()


def _configure_tessdata_prefix(directory: Path | None = None) -> Path | None:
    """Set the process to the exact tessdata directory used by this app.

    We always pair this with an explicit --tessdata-dir argument. A stale
    system/user environment variable must never redirect model loading.
    """
    global _TESSDATA_DIR
    selected = directory or _TESSDATA_DIR or _bundled_tessdata_dir()
    if selected is not None:
        selected = selected.resolve()
        os.environ["TESSDATA_PREFIX"] = str(selected)
        _TESSDATA_DIR = selected
    return selected


def _tessdata_config(directory: Path | None = None) -> str:
    # Keep the model directory in TESSDATA_PREFIX and do not also pass a quoted
    # --tessdata-dir argument.  pytesseract uses shlex.split(..., posix=False)
    # on Windows, which preserves the quote characters in the argument token;
    # Tesseract then tries to open `"C:/.../tessdata"/eng.traineddata` and
    # reports that a perfectly valid bundled model is missing.  The environment
    # variable is inherited by the child process, handles spaces in the install
    # path correctly, and is already reset by _configure_tessdata_prefix().
    _configure_tessdata_prefix(directory)
    return ""


def _available_languages(ocr, directory: Path | None = None) -> set[str]:
    try:
        return {str(item).lower() for item in ocr.get_languages(config=_tessdata_config(directory))}
    except Exception as exc:
        prefix = os.environ.get("TESSDATA_PREFIX", "(chưa đặt)")
        raise RuntimeError(
            "Không đọc được danh sách model ngôn ngữ Tesseract. "
            f"TESSDATA_PREFIX={prefix}. Chi tiết: {exc}"
        ) from exc


def _probe_tesseract_models(ocr, directory: Path, languages: set[str]) -> None:
    """Actually initialize the OCR engine before starting a long video scan."""
    if not {"eng", "vie"}.issubset(languages):
        missing = sorted({"eng", "vie"} - languages)
        raise RuntimeError("Thiếu model Tesseract: " + ", ".join(missing))
    # A tiny blank image is enough to force Tesseract to open both traineddata
    # files. Listing languages alone does not prove the native engine can read.
    probe = np.full((64, 320), 255, dtype=np.uint8)
    ocr.image_to_data(
        probe,
        lang="eng+vie",
        config=f"{_tessdata_config(directory)} --oem 1 --psm 6",
        output_type=ocr.Output.DICT,
        timeout=12,
    )


def get_subscribe_ocr_status() -> dict:
    """Return OCR availability after verifying the actual English/Vietnamese engine."""
    global _TESSERACT, _TESSERACT_PATH, _TESSERACT_LANGS, _TESSDATA_DIR
    try:
        import pytesseract
    except Exception as exc:
        return {
            "ready": False,
            "message": "Thiếu thư viện pytesseract. Hãy chạy CAI_DAT_VA_CHAY.bat để cài thư viện.",
            "detail": str(exc),
        }
    path = _find_tesseract_path()
    if not path:
        return {
            "ready": False,
            "message": "Chưa tìm thấy Tesseract OCR. Chạy CAI_TESSERACT_OCR.bat trong thư mục Video Studio rồi mở lại ứng dụng.",
            "install_command": "winget install --id UB-Mannheim.TesseractOCR -e",
        }
    bundled = _bundled_tessdata_dir()
    if bundled is None:
        return {
            "ready": False,
            "message": "Thiếu dữ liệu OCR đi kèm Video Studio.",
            "detail": (
                "Cần có assets/tessdata/eng.traineddata và "
                "assets/tessdata/vie.traineddata trong thư mục ứng dụng. "
                "Hãy giải nén lại gói FULL đầy đủ; không cần tải riêng model OCR."
            ),
        }
    pytesseract.pytesseract.tesseract_cmd = path
    failures: list[str] = []
    candidates = [bundled]
    cache_dir = _user_tessdata_dir()
    if cache_dir.resolve() != bundled.resolve():
        candidates.append(cache_dir)
    version = ""
    try:
        version = str(pytesseract.get_tesseract_version())
    except Exception as exc:
        return {
            "ready": False,
            "message": "Không khởi chạy được Tesseract OCR.",
            "detail": f"Tesseract: {path}\nChi tiết: {exc}",
        }

    for index, candidate in enumerate(candidates):
        try:
            if index == 1:
                candidate = _copy_tessdata_to_user_cache(bundled)
            languages = _available_languages(pytesseract, candidate)
            _probe_tesseract_models(pytesseract, candidate, languages)
            _TESSERACT = pytesseract
            _TESSERACT_PATH = path
            _TESSERACT_LANGS = languages
            _TESSDATA_DIR = candidate.resolve()
            selected = [lang for lang in ("eng", "vie") if lang in languages]
            warning = "" if candidate.resolve() == bundled.resolve() else "Đã chuyển model OCR sang vùng dữ liệu người dùng để tránh lỗi quyền truy cập thư mục ứng dụng."
            return {
                "ready": True, "path": path, "version": version,
                "tessdata_dir": str(candidate), "languages": selected, "warning": warning,
            }
        except Exception as exc:
            failures.append(f"{candidate}: {type(exc).__name__}: {exc}")

    _TESSERACT = None
    _TESSERACT_PATH = None
    _TESSERACT_LANGS = None
    _TESSDATA_DIR = None
    return {
        "ready": False,
        "message": "Tesseract không nạp được model OCR tiếng Anh/Việt.",
        "detail": (
            f"Tesseract: {path}\nPhiên bản: {version}\n" +
            "\n\n".join(failures) +
            "\n\nỨng dụng đã thử dùng model đóng gói và bản sao trong vùng dữ liệu người dùng. "
            "Hãy gửi nội dung này để kiểm tra quyền truy cập hoặc bản cài Tesseract."
        ),
    }

def _get_tesseract():
    global _TESSERACT, _TESSERACT_PATH, _TESSERACT_LANGS
    # Keep the Python wrapper/path cached for every sampled frame. Running
    # `tesseract --version` and `--list-langs` per frame would erase the speed
    # benefit of the two-pass scanner.
    if _TESSERACT is not None and _TESSERACT_PATH and _TESSERACT_LANGS:
        return _TESSERACT
    status = get_subscribe_ocr_status()
    if not status.get("ready"):
        raise RuntimeError(status.get("message", "Tesseract OCR chưa sẵn sàng."))
    if _TESSERACT is None or _TESSERACT_PATH != status.get("path"):
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd = status["path"]
        _TESSERACT, _TESSERACT_PATH = pytesseract, status["path"]
        _TESSERACT_LANGS = set(status.get("languages", ["eng"]))
    return _TESSERACT


def _ocr_language(ocr) -> str:
    global _TESSERACT_LANGS
    if _TESSERACT_LANGS is None:
        _TESSERACT_LANGS = _available_languages(ocr)
    selected = [lang for lang in ("eng", "vie") if lang in _TESSERACT_LANGS]
    return "+".join(selected) if selected else "eng"


def _resize(frame: np.ndarray, max_width: int) -> tuple[np.ndarray, float]:
    height, width = frame.shape[:2]
    scale = min(1.0, max_width / max(1.0, float(width)))
    if scale < 1.0:
        frame = cv2.resize(frame, (max(1, int(round(width * scale))),
                                  max(1, int(round(height * scale)))),
                           interpolation=cv2.INTER_AREA)
    return frame, scale


def _normalise_ocr_text(value: str) -> str:
    """Fold Vietnamese accents and OCR punctuation into searchable text."""
    raw = str(value or "").replace("Đ", "D").replace("đ", "d")
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    text = re.sub(r"[^A-Z0-9]", "", raw.upper())
    # Common OCR confusions in stylised English CTA lettering.
    return text.replace("1", "I")


def _levenshtein_at_most_one(a: str, b: str) -> bool:
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) > len(b):
        a, b = b, a
    i = j = edits = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1
        else:
            edits += 1
            if edits > 1:
                return False
            if len(a) == len(b):
                i += 1; j += 1
            else:
                j += 1
    if j < len(b) or i < len(a):
        edits += 1
    return edits <= 1


def _classify_subscribe_text(value: str) -> dict | None:
    """Classify a visible English or Vietnamese Subscribe phrase."""
    compact = _normalise_ocr_text(value)
    if not compact:
        return None
    english_terms = ("SUBSCRIBE", "SUBSCRIBED", "SUBSCRIBENOW", "SUBSCRIBETO")
    if any(term in compact for term in english_terms):
        return {"kind": "text_en", "method": "OCR tiếng Anh", "label": "Subscribe", "text": str(value)}

    tokens = re.findall(r"[A-Z]+", unicodedata.normalize("NFKD", str(value).upper()).replace("Đ", "D"))
    folded_tokens = [_normalise_ocr_text(token) for token in tokens]
    if any(8 <= len(token) <= 11 and _levenshtein_at_most_one(token, "SUBSCRIBE") for token in folded_tokens):
        return {"kind": "text_en", "method": "OCR tiếng Anh (gần đúng)", "label": "Subscribe", "text": str(value)}

    # Vietnamese variants requested for the project. Requiring a CTA marker
    # avoids matching unrelated text such as "đăng ký tài khoản".
    has_dang_ky = "DANGKY" in compact
    vi_markers = (
        "KENH", "NHO", "HAY", "DUNGQUEN", "NGAY", "NHE", "MOIBAN",
        "NHAN", "UNGHO", "SUBSCRIBE", "CHANNEL",
    )
    if has_dang_ky and any(marker in compact for marker in vi_markers):
        return {"kind": "text_vi", "method": "OCR tiếng Việt", "label": "Đăng ký kênh", "text": str(value)}
    if compact in {"DANGKY", "DANGKYNGAY"} or compact.startswith("DANGKYNGAY"):
        return {"kind": "text_vi", "method": "OCR tiếng Việt", "label": "Đăng ký", "text": str(value)}
    return None


def _box_detection(x: int, y: int, w: int, h: int, confidence: float,
                   kind: str, method: str, label: str, text: str = "") -> dict:
    return {
        "x": int(x), "y": int(y), "w": int(w), "h": int(h),
        "confidence": round(max(0.0, min(100.0, float(confidence))), 1),
        "kind": kind, "method": method, "label": label, "text": text,
        "evidence": [kind], "animated": False, "motion_score": 0.0,
    }


def _find_graphic_subscribe_buttons(frame: np.ndarray) -> list[dict]:
    """Find likely red Subscribe/play-button graphics using local CV heuristics.

    This is deliberately conservative: a plain red rectangle is not enough.
    The region must also contain bright high-contrast artwork/text, and must
    have button-like geometry. Results remain manual-review suggestions.
    """
    if frame is None or frame.size == 0:
        return []
    height, width = frame.shape[:2]
    small, scale = _resize(frame, 960)
    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
    lower_red = cv2.inRange(hsv, np.array([0, 95, 75], np.uint8), np.array([12, 255, 255], np.uint8))
    upper_red = cv2.inRange(hsv, np.array([168, 95, 75], np.uint8), np.array([180, 255, 255], np.uint8))
    red = cv2.bitwise_or(lower_red, upper_red)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 3))
    red = cv2.morphologyEx(red, cv2.MORPH_CLOSE, kernel, iterations=2)
    contours, _ = cv2.findContours(red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    detections: list[dict] = []
    sh, sw = small.shape[:2]
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:60]:
        x, y, w, h = cv2.boundingRect(contour)
        area = float(w * h)
        area_ratio = area / max(1.0, float(sw * sh))
        aspect = w / max(1.0, float(h))
        if area_ratio < 0.00035 or area_ratio > 0.085 or w < 24 or h < 16:
            continue
        is_button = 1.55 <= aspect <= 7.5 and w >= 48
        is_icon = 0.68 <= aspect <= 1.38 and min(w, h) >= 24
        if not (is_button or is_icon):
            continue
        roi_red = red[y:y+h, x:x+w]
        roi = small[y:y+h, x:x+w]
        red_ratio = float(cv2.countNonZero(roi_red)) / max(1.0, area)
        if red_ratio < (0.19 if is_button else 0.30):
            continue
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        roi_hsv = hsv[y:y+h, x:x+w]
        bright_low_sat = ((gray >= 190) & (roi_hsv[:, :, 1] <= 95)).astype(np.uint8) * 255
        # A generic white word such as LIKE is not enough. For graphics-only
        # recognition require a compact play-triangle glyph inside the red
        # button; text-based Subscribe remains handled by OCR above.
        white_clean = cv2.morphologyEx(
            bright_low_sat, cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)), iterations=1,
        )
        glyph_contours, _ = cv2.findContours(white_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        has_play_glyph = False
        for glyph in glyph_contours:
            glyph_area = cv2.contourArea(glyph)
            if glyph_area < max(7.0, area * 0.006) or glyph_area > area * 0.16:
                continue
            gx, gy, gw, gh = cv2.boundingRect(glyph)
            if min(gw, gh) < 3 or max(gw / max(1.0, gh), gh / max(1.0, gw)) > 2.2:
                continue
            perimeter = cv2.arcLength(glyph, True)
            approx = cv2.approxPolyDP(glyph, 0.08 * perimeter, True)
            if 3 <= len(approx) <= 5 and cv2.isContourConvex(approx):
                extent = glyph_area / max(1.0, float(gw * gh))
                center_x = gx + gw * 0.5
                if extent >= 0.30 and w * 0.12 <= center_x <= w * 0.88:
                    has_play_glyph = True
                    break
        if not has_play_glyph:
            continue
        # Reject broad red footage overlays; require a compact button/icon.
        if is_button and h > int(sh * 0.16):
            continue
        confidence = min(78.0, 59.0 + red_ratio * 13.0)
        inv = 1.0 / max(0.001, scale)
        ox, oy = int(round(x * inv)), int(round(y * inv))
        ow, oh = int(round(w * inv)), int(round(h * inv))
        detections.append(_box_detection(
            ox, oy, ow, oh, confidence, "graphic_button", "Hình ảnh nút/biểu tượng",
            "Nút Subscribe dạng đồ họa", "Nút đỏ có nội dung/biểu tượng sáng",
        ))
    return detections


def _merge_detections(detections: list[dict]) -> list[dict]:
    detections = sorted(detections, key=lambda item: item.get("confidence", 0), reverse=True)
    kept: list[dict] = []
    for detection in detections:
        match = next((item for item in kept if _iou(item, detection) >= 0.42), None)
        if match is None:
            kept.append(dict(detection))
            continue
        match["evidence"] = sorted(set(match.get("evidence", [])) | set(detection.get("evidence", [])))
        if detection.get("kind") not in str(match.get("kind", "")):
            match["kind"] = "combined"
        if detection.get("confidence", 0) > match.get("confidence", 0):
            match["confidence"] = detection["confidence"]
        if detection.get("method") and detection["method"] not in str(match.get("method", "")):
            match["method"] = f"{match.get('method', '')} + {detection['method']}".strip(" +")
    return kept[:10]


def _location_for_box(x: int, y: int, w: int, h: int, frame_w: int, frame_h: int) -> str:
    cx, cy = x + w / 2, y + h / 2
    if cy >= frame_h * 0.72:
        return "dưới"
    if cy <= frame_h * 0.24:
        return "trên"
    if cx <= frame_w * 0.2:
        return "rìa trái"
    if cx >= frame_w * 0.8:
        return "rìa phải"
    return "giữa"


def find_subscribe_regions(frame: np.ndarray, max_width: int = 720) -> list[dict]:
    """Detect visible Subscribe text (English/Vietnamese) and graphic buttons."""
    if frame is None or frame.size == 0:
        return []
    ocr = _get_tesseract()
    small, source_scale = _resize(frame, max_width)
    original_h, original_w = frame.shape[:2]
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    upscale = min(2.0, 1040.0 / max(1.0, float(gray.shape[1])))
    if upscale > 1.0:
        gray = cv2.resize(gray, (int(round(gray.shape[1] * upscale)),
                                 int(round(gray.shape[0] * upscale))),
                          interpolation=cv2.INTER_CUBIC)
    gray = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    border = max(12, int(round(12 * upscale)))
    padded = cv2.copyMakeBorder(gray, border, border, border, border,
                                cv2.BORDER_CONSTANT, value=0)
    try:
        data = ocr.image_to_data(
            padded, lang=_ocr_language(ocr),
            config=(f"{_tessdata_config()} --oem 1 --psm 6 -c preserve_interword_spaces=1").strip(),
            output_type=ocr.Output.DICT, timeout=4,
        )
    except ocr.TesseractError as exc:
        raise RuntimeError(
            "Tesseract không mở được model OCR khi đọc khung hình. "
            f"Thư mục model: {_TESSDATA_DIR or os.environ.get('TESSDATA_PREFIX', '(chưa đặt)')}. "
            f"Chi tiết: {exc}"
        ) from exc
    except RuntimeError as exc:
        message = str(exc).lower()
        if "timeout" in message or "timed out" in message:
            raise RuntimeError(f"Tesseract OCR quá thời gian khi đọc khung hình: {exc}") from exc
        raise RuntimeError(f"Tesseract OCR gặp lỗi khi đọc khung hình: {exc}") from exc
    except Exception as exc:
        raise RuntimeError(f"Không đọc được nội dung CTA Subscribe bằng OCR: {exc}") from exc

    lines: dict[tuple[int, int, int], list[dict]] = {}
    for index, raw_text in enumerate(data.get("text", [])):
        text = str(raw_text or "").strip()
        if not text:
            continue
        try:
            confidence = float(data.get("conf", [])[index])
            x, y = int(data["left"][index]), int(data["top"][index])
            tw, th = int(data["width"][index]), int(data["height"][index])
            key = (int(data["block_num"][index]), int(data["par_num"][index]), int(data["line_num"][index]))
        except (ValueError, TypeError, IndexError, KeyError):
            continue
        if confidence < 12 or tw <= 0 or th <= 0:
            continue
        lines.setdefault(key, []).append({"text": text, "confidence": confidence,
                                           "x": x, "y": y, "w": tw, "h": th})

    detections: list[dict] = []
    inverse = 1.0 / max(0.001, source_scale * upscale)
    for tokens in lines.values():
        tokens.sort(key=lambda item: item["x"])
        raw_line = " ".join(token["text"] for token in tokens)
        match = _classify_subscribe_text(raw_line)
        if not match:
            continue
        x1 = min(item["x"] for item in tokens)
        y1 = min(item["y"] for item in tokens)
        x2 = max(item["x"] + item["w"] for item in tokens)
        y2 = max(item["y"] + item["h"] for item in tokens)
        x1 -= border; y1 -= border; x2 -= border; y2 -= border
        pad_x = max(6, int((x2 - x1) * 0.22))
        pad_y = max(5, int((y2 - y1) * 0.55))
        x1 = max(0, int(round((x1 - pad_x) * inverse)))
        y1 = max(0, int(round((y1 - pad_y) * inverse)))
        x2 = min(original_w, int(round((x2 + pad_x) * inverse)))
        y2 = min(original_h, int(round((y2 + pad_y) * inverse)))
        if x2 <= x1 or y2 <= y1:
            continue
        confidence = sum(item["confidence"] for item in tokens) / max(1, len(tokens))
        detections.append(_box_detection(
            x1, y1, x2 - x1, y2 - y1, confidence,
            match["kind"], match["method"], match["label"], match["text"],
        ))

    detections.extend(_find_graphic_subscribe_buttons(frame))
    detections = _merge_detections(detections)
    for item in detections:
        item["location"] = _location_for_box(item["x"], item["y"], item["w"], item["h"], original_w, original_h)
    detections.sort(key=lambda item: item["confidence"], reverse=True)
    return detections[:8]


# Backward compatibility for callers/tests from v1.5.2.0.
def find_cta_regions(frame: np.ndarray, max_width: int = 720) -> list[dict]:
    return find_subscribe_regions(frame, max_width=max_width)


def find_end_screen_panels(_frame: np.ndarray, max_width: int = 480) -> list[dict]:
    """Generic end screens are not Subscribe CTAs; text/graphics are scanned normally."""
    return []


def _iou(a: dict, b: dict) -> float:
    ax, ay, aw, ah = (float(a[k]) for k in ("x", "y", "w", "h"))
    bx, by, bw, bh = (float(b[k]) for k in ("x", "y", "w", "h"))
    ix = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    union = aw * ah + bw * bh - ix * iy
    return (ix * iy / union) if union > 0 else 0.0


def _tracks_to_candidates(tracks: list[dict], duration: float, interval: float) -> list[dict]:
    candidates: list[dict] = []
    for track in tracks:
        times = sorted(set(round(float(value), 3) for value in track["times"]))
        n = len(times)
        peak = max(track["scores"])
        if n < 2 and peak < 55.0:
            continue
        local_interval = min(track.get("intervals", [interval]) or [interval])
        pad = max(0.12, min(float(interval), float(local_interval)) * 0.58)
        start = max(0.0, float(times[0]) - pad)
        end = min(duration, float(times[-1]) + pad)
        if end - start < 0.25:
            end = min(duration, start + max(0.5, local_interval))
        box = track["box"]
        evidence = sorted(set(track.get("evidence", [])))
        methods = sorted(set(track.get("methods", [])))
        if track.get("animated"):
            methods.append("có biến đổi hình ảnh")
        method = " + ".join(methods) if methods else "Hình ảnh"
        texts = [text for text in track.get("texts", []) if text]
        label = "Đăng ký kênh" if "text_vi" in evidence else "Subscribe"
        candidates.append({
            "scan_id": int(track["scan_id"]),
            "start": round(start, 3), "end": round(end, 3),
            "duration": round(max(0.0, end - start), 3),
            "sample_time": float(times[len(times) // 2]),
            "x": int(box["x"]), "y": int(box["y"]),
            "w": int(box["w"]), "h": int(box["h"]),
            "confidence": round(float(sum(track["scores"]) / max(1, len(track["scores"]))), 1),
            "peak_confidence": round(float(peak), 1),
            "samples": n,
            "location": max(set(track["locations"]), key=track["locations"].count),
            "kind": "subscribe", "label": label, "text": texts[-1] if texts else label,
            "method": method, "evidence": evidence,
            "animated": bool(track.get("animated")),
            "motion_score": round(float(max(track.get("motion_scores", [0.0]) or [0.0])), 1),
        })
    candidates.sort(key=lambda item: (item["start"], -item["confidence"]))
    return candidates


def _motion_score(previous: np.ndarray | None, current: np.ndarray, detection: dict) -> float:
    if previous is None or previous.shape != current.shape:
        return 0.0
    x, y, w, h = (int(detection[k]) for k in ("x", "y", "w", "h"))
    height, width = current.shape[:2]
    x1, y1 = max(0, x), max(0, y)
    x2, y2 = min(width, x + w), min(height, y + h)
    if x2 - x1 < 8 or y2 - y1 < 8:
        return 0.0
    before = cv2.cvtColor(previous[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    after = cv2.cvtColor(current[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    before = cv2.resize(before, (64, 32), interpolation=cv2.INTER_AREA)
    after = cv2.resize(after, (64, 32), interpolation=cv2.INTER_AREA)
    return float(cv2.absdiff(before, after).mean())


def _merge_windows(windows: list[tuple[float, float]], duration: float) -> list[tuple[float, float]]:
    if not windows:
        return []
    ordered = sorted((max(0.0, a), min(duration, b)) for a, b in windows if b > a)
    merged: list[list[float]] = []
    for start, end in ordered:
        if not merged or start > merged[-1][1] + 0.35:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    return [(a, b) for a, b in merged]


def _sample_times(duration: float, interval: float, max_samples: int) -> tuple[list[float], float]:
    count = max(1, min(int(max_samples), int(math.ceil(duration / max(0.05, interval)))))
    actual_interval = duration / count
    times = [min(duration - 0.001, i * actual_interval + actual_interval * 0.5) for i in range(count)]
    return times, actual_interval


def _update_tracks(tracks: list[dict], detections: list[dict], seconds: float, interval: float,
                   motion_values: list[float] | None = None) -> None:
    for index, detection in enumerate(detections):
        chosen = None
        best_score = 0.0
        for track in tracks:
            delta = min(abs(seconds - float(track["first_time"])), abs(seconds - float(track["last_time"])))
            if delta > max(2.5, interval * 3.0):
                continue
            overlap = _iou(detection, track["box"])
            # Spatial overlap catches repeated button/overlay appearances;
            # near-position fallback tolerates size changes during animation.
            if overlap > best_score and overlap >= 0.06:
                best_score, chosen = overlap, track
        motion = float(motion_values[index]) if motion_values and index < len(motion_values) else 0.0
        if chosen is None:
            tracks.append({
                "scan_id": len(tracks), "box": dict(detection),
                "first_time": seconds, "last_time": seconds,
                "times": [seconds], "scores": [detection["confidence"]],
                "locations": [detection.get("location", "—")],
                "evidence": list(detection.get("evidence", [detection.get("kind", "visual")])),
                "methods": [detection.get("method", "Hình ảnh")],
                "texts": [detection.get("text", "")],
                "intervals": [interval], "animated": motion >= 11.0,
                "motion_scores": [motion],
            })
        else:
            if not any(abs(seconds - existing) < 0.015 for existing in chosen["times"]):
                chosen["times"].append(seconds)
                chosen["scores"].append(detection["confidence"])
                chosen["locations"].append(detection.get("location", "—"))
                chosen["intervals"].append(interval)
                chosen["motion_scores"].append(motion)
            chosen["first_time"] = min(float(chosen["first_time"]), seconds)
            chosen["last_time"] = max(float(chosen["last_time"]), seconds)
            chosen["evidence"] = sorted(set(chosen["evidence"]) | set(detection.get("evidence", [detection.get("kind", "visual")])))
            if detection.get("method") and detection["method"] not in chosen["methods"]:
                chosen["methods"].append(detection["method"])
            if detection.get("text") and detection["text"] not in chosen["texts"]:
                chosen["texts"].append(detection["text"])
            chosen["animated"] = bool(chosen["animated"] or motion >= 11.0)
            for key in ("x", "y", "w", "h"):
                chosen["box"][key] = int(round(0.65 * chosen["box"][key] + 0.35 * detection[key]))
            chosen["box"]["confidence"] = max(chosen["box"].get("confidence", 0), detection["confidence"])


def detect_cta_image_candidates(
    video_path: str,
    sample_interval: float = 1.0,
    max_samples: int = 1800,
    max_width: int = 720,
    cancel_event: Optional[threading.Event] = None,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    pause_event: Optional[threading.Event] = None,
    pause_callback: Optional[Callable[[], None]] = None,
    candidate_callback: Optional[Callable[[list[dict], int, int], None]] = None,
    phase_callback: Optional[Callable[[str, int, int], None]] = None,
) -> dict:
    """Two-pass visual Subscribe scan with pause, cancel and live results.

    Pass 1 scans the whole video at a coarse interval. Pass 2 rechecks only
    windows around likely text/button detections at a finer interval to refine
    short animations and start/end times. No audio is opened or analysed.
    """
    status = get_subscribe_ocr_status()
    if not status.get("ready"):
        raise RuntimeError(status.get("message", "Tesseract OCR chưa sẵn sàng."))

    cap = cv2.VideoCapture(str(video_path))
    try:
        if not cap.isOpened():
            raise RuntimeError("Không mở được video để quét CTA Subscribe.")
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        duration = frame_count / fps if fps > 0 and frame_count > 0 else 0.0
        if duration <= 0:
            raise RuntimeError("Không đọc được thời lượng video.")

        requested_interval = max(0.25, float(sample_interval))
        # Even the Fast preset samples the full video at least once per second;
        # Pass 2 handles dense verification around actual candidates.
        pass1_interval = max(0.75, requested_interval)
        pass1_times, actual_pass1_interval = _sample_times(duration, pass1_interval, max_samples)
        tracks: list[dict] = []
        valid = 0
        last_published_signature = None
        previous_frame = None
        total_valid_work = len(pass1_times)

        def check_pause() -> None:
            while pause_event is not None and pause_event.is_set():
                if cancel_event is not None and cancel_event.is_set():
                    raise CTAScanCancelled("Đã dừng quét CTA Subscribe theo yêu cầu.")
                if pause_callback:
                    pause_callback()
                time.sleep(0.10)
            if cancel_event is not None and cancel_event.is_set():
                raise CTAScanCancelled("Đã dừng quét CTA Subscribe theo yêu cầu.")

        def scan_times(times: list[float], stage: str, nominal_interval: float,
                       global_offset: int = 0, global_total: int | None = None) -> None:
            nonlocal valid, last_published_signature, previous_frame
            stage_total = max(1, len(times))
            if phase_callback:
                phase_callback(stage, 0, stage_total)
            for index, seconds in enumerate(times, 1):
                check_pause()
                cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, seconds) * 1000.0)
                ok, frame = cap.read()
                if ok and frame is not None:
                    valid += 1
                    detections = find_subscribe_regions(frame, max_width=max_width)
                    motion_values = [_motion_score(previous_frame, frame, detection) for detection in detections]
                    for detection, motion in zip(detections, motion_values):
                        if motion >= 11.0:
                            detection["animated"] = True
                            detection["motion_score"] = round(motion, 1)
                            if "motion" not in detection["evidence"]:
                                detection["evidence"].append("motion")
                    _update_tracks(tracks, detections, seconds, nominal_interval, motion_values)
                    previous_frame = frame

                if progress_callback:
                    progress_callback(index, stage_total)
                if phase_callback:
                    phase_callback(stage, index, stage_total)
                if candidate_callback:
                    current = _tracks_to_candidates(tracks, duration, nominal_interval)
                    signature = tuple((c["scan_id"], round(c["start"], 1), round(c["end"], 1),
                                       tuple(c.get("evidence", [])), c["samples"]) for c in current)
                    if signature != last_published_signature and (index % 3 == 0 or index == stage_total or last_published_signature is None):
                        candidate_callback(current, index, stage_total)
                        last_published_signature = signature

        scan_times(pass1_times, "pass1", actual_pass1_interval)
        rough = _tracks_to_candidates(tracks, duration, actual_pass1_interval)
        windows = _merge_windows([
            (float(item["start"]) - 1.2, float(item["end"]) + 1.2) for item in rough
        ], duration)

        pass2_times: list[float] = []
        actual_pass2_interval = min(0.35, max(0.20, requested_interval / 2.0))
        pass1_set = {round(value, 3) for value in pass1_times}
        for start, end in windows:
            t = start + actual_pass2_interval * 0.5
            while t < end - 0.001:
                rounded = round(min(duration - 0.001, t), 3)
                if rounded not in pass1_set:
                    pass2_times.append(rounded)
                t += actual_pass2_interval
        pass2_times = sorted(set(pass2_times))
        if len(pass2_times) > max_samples:
            indices = np.linspace(0, len(pass2_times) - 1, int(max_samples), dtype=int)
            pass2_times = [pass2_times[int(i)] for i in indices]
        if pass2_times:
            total_valid_work = len(pass1_times) + len(pass2_times)
            # Pass 2 starts at an earlier timestamp inside the first candidate
            # window, so discard the last Pass-1 frame for motion comparison.
            previous_frame = None
            scan_times(pass2_times, "pass2", actual_pass2_interval,
                       global_offset=len(pass1_times), global_total=total_valid_work)
        elif phase_callback:
            phase_callback("done", 1, 1)

        if valid < max(1, int(len(pass1_times) * 0.5)):
            raise RuntimeError("Không đọc đủ khung hình mẫu. Hãy kiểm tra codec hoặc thử MP4.")
        candidates = _tracks_to_candidates(tracks, duration, min(actual_pass1_interval, actual_pass2_interval))
        if candidate_callback:
            candidate_callback(candidates, total_valid_work, total_valid_work)
        return {
            "duration": duration, "samples": valid,
            "sample_interval": min(actual_pass1_interval, actual_pass2_interval) if pass2_times else actual_pass1_interval,
            "candidates": candidates, "pass1_samples": len(pass1_times),
            "pass2_samples": len(pass2_times),
            "note": (
                "Đã quét 2 lượt: lượt 1 tìm toàn video; lượt 2 kiểm tra dày quanh vùng nghi vấn. "
                "Nhận diện chữ tiếng Anh/Việt, nút/biểu tượng đồ họa và dấu hiệu chuyển động. "
                "Chỉ xử lý hình ảnh, không phân tích âm thanh. Hãy duyệt thủ công trước khi cắt."
            ),
        }
    finally:
        cap.release()
