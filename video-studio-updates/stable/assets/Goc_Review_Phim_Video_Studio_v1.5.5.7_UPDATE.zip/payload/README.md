# Góc Review Phim Video Studio v1.5.5.7

**Minimal Studio · Downloader · Subscribe CTA Detector · One-Click Stable Updater**

## Cập nhật từ v1.5.5.3

1. Đóng Video Studio.
2. Giải nén toàn bộ gói FULL vào đúng thư mục Video Studio đang sử dụng, chọn **Replace the files in the destination**.
3. Không xóa thư mục cũ, không xóa `.venv`, `user_settings.json`, `projects`, `autosave`, `downloads`, `renders`, `logs` hoặc `assets/user`.
4. Chạy `CAI_DAT_VA_CHAY.bat`. Bộ cài dùng lại `.venv`, kiểm tra/cập nhật dependency và tự tạo hoặc làm mới shortcut Desktop.
5. Mở phần mềm bằng shortcut **Goc Review Phim**. Launcher ưu tiên `pythonw.exe`, không mở cửa sổ Terminal đen.

Gói FULL không chứa `.venv` và không chứa dữ liệu cá nhân. Các file chương trình, launcher, updater và model OCR được thay bằng bản v1.5.5.7. Giữ thư mục cũ hoặc một bản sao lưu cho tới khi xác nhận chạy ổn định.

**Cài mới:** giải nén vào thư mục mới, chạy `CAI_DAT_VA_CHAY.bat`. Lần cài đầu cần Python 3.11+ và Internet.

## Cập nhật ngay trong ứng dụng

- Nút trên thanh đầu trang là **Kiểm tra & cập nhật**.
- Bấm một lần: ứng dụng kiểm tra kênh Stable; nếu có bản mới hơn thì tự tải và xác minh HTTPS GitHub cố định + SHA-256 (vẫn hỗ trợ manifest Ed25519 cũ), không yêu cầu bấm nút thứ hai hoặc xác nhận lần hai.
- Có thể hủy trong lúc tải. Việc áp dụng chỉ bắt đầu sau khi Engine, Batch, CTA Detector và các lệnh đang chạy hoàn tất.
- Trước khi thay file, updater sao lưu file chương trình; health-check thất bại sẽ rollback. Dữ liệu project, Auto Save, `user_settings.json`, `.venv`, Branding cá nhân, downloads và renders được giữ nguyên.
- Khi gói đã xác minh, Video Studio tự đóng, áp dụng cập nhật và mở lại bằng launcher ẩn.

**Ghi chú về phát hành:** tính năng một lần bấm đã được tích hợp trong mã nguồn. Release mới dùng manifest `https-sha256-v1`, asset URL cố định trong kho public và SHA-256 của ZIP/từng file; không cần token GitHub hay private signing key trên máy người dùng. Manifest Ed25519 cũ vẫn được hỗ trợ trong giai đoạn chuyển đổi.

## Sửa trong v1.5.5.4

- Sửa launcher và shortcut Desktop: ưu tiên `pythonw.exe`, chuyển stdout/stderr vào log, không để lại cửa sổ Terminal.
- `CHAY_TOOL.bat` cũng gọi launcher qua Windows Script Host ẩn.
- Bộ cài tự làm mới shortcut Desktop sau khi kiểm tra dependency.
- Nút **Kiểm tra & cập nhật** thực hiện kiểm tra, tải, xác minh và cài tự động trong cùng một thao tác; giữ nút hủy tải.
- Khi project mất file logo riêng, ứng dụng dùng logo mặc định và hiển thị ghi chú ở thanh trạng thái thay vì bật cảnh báo modal. Khi lưu project, đường dẫn logo mặc định được ghi lại.

## CTA Subscribe Detector

Giữ nhận diện CTA Subscribe hiển thị trong video bằng OCR tiếng Anh/Việt và dấu hiệu hình ảnh, quét hai lượt, Pause/Resume, gom ứng viên theo khoảng thời gian và yêu cầu duyệt thủ công trước khi cắt. Không xử lý âm thanh/lời nói.

Tesseract executable cần có trên Windows. Gói `eng.traineddata` và `vie.traineddata` đã đi kèm trong `assets/tessdata`; nếu chưa có executable, chạy `CAI_TESSERACT_OCR.bat`. v1.5.5.7 kiểm tra nạp OCR thực tế và tự tạo bản cache model trong `%LOCALAPPDATA%` nếu thư mục ứng dụng không đọc được.

## Nhật ký

- Khởi động ứng dụng: `%LOCALAPPDATA%\GocReviewVideoStudio\logs\launcher.log`
- Cập nhật: `%LOCALAPPDATA%\GocReviewVideoStudio\updater\apply-helper.log`

## Sửa trong v1.5.5.7

- Sửa tương thích Tesseract với đường dẫn cài đặt có khoảng trắng bằng cách dùng `TESSDATA_PREFIX` đã được kiểm soát.
- Updater xác nhận redirect asset, bản nền và version sau apply; lỗi xác minh/health-check sẽ rollback.

## Sửa trong v1.5.5.6

- Tesseract được kiểm tra khởi tạo OCR thực tế với cả model Anh/Việt trước khi quét.
- Nếu thư mục cài ứng dụng không đọc được model, ứng dụng tự tạo cache trong `%LOCALAPPDATA%` và thử lại.
- Báo riêng lỗi model với timeout OCR.
