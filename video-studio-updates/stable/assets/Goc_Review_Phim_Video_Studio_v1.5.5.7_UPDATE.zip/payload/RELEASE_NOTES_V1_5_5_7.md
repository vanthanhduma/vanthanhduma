# v1.5.5.7

- Sửa đường dẫn model Tesseract trên Windows khi thư mục cài đặt có khoảng trắng; CTA Detector nạp đúng `eng.traineddata` và `vie.traineddata`.
- Updater kiểm tra redirect HTTPS của asset, kiểm tra đúng bản nền trước khi tải và xác nhận `PHIEN_BAN.txt` sau khi cài.
- Nếu gói không khớp version hoặc health-check thất bại, transaction rollback về bản trước.
- Thêm công cụ tạo FULL ZIP sạch và giữ nguyên `.venv`, project, Auto Save, settings, branding, downloads, renders, video và output.
