# Góc Review Phim – Video Studio

**Stable hiện tại: v1.5.9.29** · Windows 10/11 · Python 3.11+

Góc Review Phim Video Studio là ứng dụng desktop hỗ trợ biên tập video review phim, quản lý dự án, xử lý watermark/branding, phát hiện CTA hiển thị và xuất video.

- **Stable update feed:** [latest.json](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json)
- **Repository nguồn:** `vanthanhduma/Goc-Review-Phim-Video-Studio` (private)
- **Release notes mới nhất:** [v1.5.9.29](RELEASE_NOTES_V1_5_9_29.md)

## Chức năng chính

- **Biên tập & phân cảnh:** xem video, quản lý dự án và các khoảng cần xử lý.
- **Làm sạch – Mask:** xử lý watermark/logo theo vùng và phân cảnh.
- **Studio Branding:** bố trí logo, nhãn và branding trên video.
- **CTA Detector:** quét CTA xuất hiện trong hình ảnh/video, xem bằng chứng và duyệt thủ công; không tự động cắt.
- **Batch CTA Processing:** đưa nhiều video vào hàng đợi, lưu project riêng và tiếp tục xử lý.
- **Tải video:** quản lý tác vụ tải, trạng thái và tiếp tục tải khi nguồn hỗ trợ.
- **Xuất & kiểm tra:** xem trước, nhập và duyệt khoảng cắt, xem timeline, xuất video và kiểm tra chất lượng đầu ra.
- **Dự án & sao lưu:** lưu/mở project, Auto Save, lịch sử sao lưu và đóng gói ZIP.
- **Stable Updater:** kiểm tra phiên bản, xác minh SHA-256 và cập nhật ứng dụng.

## Phiên bản Stable v1.5.9.29

### CTA Detection Coverage Upgrade
- Tăng mật độ quét mặc định lên 2 khung hình/giây (mỗi 0,5 giây) cho CTA Detector và Batch CTA Processing.
- Chạy OCR chế độ cân bằng với adaptive-threshold fallback để cải thiện nhận dạng chữ CTA khó đọc.
- Kích hoạt nhận diện hình ảnh nút Subscribe/biểu tượng phát độc lập với OCR, kể cả khi OCR bỏ sót hoặc timeout.
- Phân biệt kết quả chữ, đồ họa và kết hợp; lưu thêm nguồn nhận diện vào kết quả để dễ đối chiếu.
- Batch CTA sử dụng cùng detector, cùng mật độ lấy mẫu và vẫn xử lý tuần tự từng video.
- Giữ nguyên duyệt thủ công; không tự động phê duyệt hoặc cắt CTA.

## Nền tảng giao diện từ v1.5.9.28

### Unified Studio UI & Direct Source Player
- Bỏ bước render clip tạm; nút mở video sử dụng trực tiếp file gốc và trình phát mặc định của hệ điều hành.
- Đồng bộ ngôn ngữ giao diện navy/teal/cyan trên thanh tiêu đề, sidebar, workspace, card, nút, tab, bảng, biểu mẫu, menu và hộp thoại.
- Chuẩn hóa trạng thái hover/selected/disabled/focus, độ tương phản, viền, bo góc, khoảng đệm và thanh cuộn trên các workspace.
- Giữ nguyên bố cục thao tác, tính năng, pipeline xử lý/xuất video, dự án và dữ liệu người dùng.
- Duy trì các tinh chỉnh Studio Branding từ v1.5.9.26.
- Tinh chỉnh bảng Branding theo dạng Studio gọn, cân đối; bốn tab Logo/Nhãn/Thời gian/Preset giãn đều theo chiều rộng bảng điều khiển.
- Thu gọn inspector, cải thiện card, trường nhập, checkbox và slider; dành thêm không gian cho khung Preview.
- Giữ nguyên kéo logo trực tiếp, kích thước/độ trong suốt/xoay/vị trí, nội dung và màu nhãn, thời gian, phạm vi phân cảnh và Preset.
- Đổi thao tác xem video gốc sang ứng dụng phát video mặc định của hệ điều hành; không ép gọi ffplay. Video mở ở trình phát ngoài, có thể tua, thoát toàn màn hình và đóng bằng điều khiển sẵn có của trình phát.
- Giữ nguyên pipeline preview Engine, lệnh xuất, cấu hình video và dữ liệu dự án.

### Các bản trước
- **v1.5.9.25:** làm mới Xuất & kiểm tra, gom preview/phát lại, quản lý khoảng cắt, timeline, thư mục đầu ra và QC.

### Các bản gần đây
- **v1.5.9.24:** làm mới Studio Branding và tổ chức lại Xuất & kiểm tra; bỏ thao tác cắt trực tiếp khỏi CTA Detector.
- **v1.5.9.23:** cải thiện bố cục Downloader và trạng thái sidebar theo kích thước cửa sổ.
- **v1.5.9.22:** cải thiện tải video, kiểm tra luồng hình sau tải và nhãn Branding.

Các release notes và biên bản kiểm thử phiên bản cũ được lưu trong `docs/releases/` và `docs/testing/`. Tài liệu phát triển, workflow CI và bộ test được giữ trong repository nhưng không đưa vào gói cài đặt.

## Cài đặt trên Windows

1. Tải gói **FULL** từ [Stable update feed](https://github.com/vanthanhduma/vanthanhduma/blob/main/video-studio-updates/stable/latest.json) và giải nén toàn bộ vào một thư mục riêng, ví dụ `D:\GocReviewVideoStudio`.
2. Chạy `CAI_DAT_VA_CHAY.bat` để tạo môi trường `.venv` và cài thư viện cần thiết.
3. Khi cài xong, mở bằng shortcut Desktop hoặc `MO_GOC_REVIEW_PHIM.vbs`.
4. Cài Tesseract OCR bằng `CAI_TESSERACT_OCR.bat` khi cần OCR cho CTA Detector. Bộ dữ liệu ngôn ngữ English và Vietnamese được cung cấp trong `assets/tessdata`.

**Cập nhật phiên bản:** mở ứng dụng → **Kiểm tra, cập nhật**. Không giải nén gói UPDATE đè thủ công lên thư mục đang chạy.

## Dữ liệu người dùng

Updater và gói cài đặt được cấu hình để không ghi đè các vùng dữ liệu cá nhân như `.venv`, `projects`, `downloads`, `renders`, `logs`, `autosave`, `_backups`, `assets/user` và `user_settings.json`.

Không xóa các thư mục dự án, autosave, tải xuống hoặc sao lưu nếu chúng đang chứa dữ liệu cần giữ. Video Studio không kèm FFmpeg system; có thể cài/tải FFmpeg riêng khi cần.

## Cấu trúc repository

- `app.py`, `qt_app.py`, `engine_worker.py`: ứng dụng và engine.
- `updater/`: kiểm tra, xác minh và áp dụng bản cập nhật.
- `assets/`: logo, icon và dữ liệu OCR được đóng gói.
- `tests/`: kiểm thử hồi quy, UI smoke test và Batch CTA (chỉ có trong source).
- `tools/`: công cụ đóng gói FULL/UPDATE (chỉ có trong source).
- `docs/releases/`: lịch sử phát hành.
- `docs/testing/`: biên bản kiểm thử các phiên bản.
- `docs/`: đặc tả, tài liệu kỹ thuật và hướng dẫn hỗ trợ.
- `RELEASE_NOTES_V1_5_9_25.md`: ghi chú bản phát hành hiện tại; các bản cũ nằm trong `docs/releases/` và `docs/testing/`.

## Kiểm thử phát hành

Quy trình phát hành v1.5.9.29 kiểm tra compile, Branding workspace, luồng mở video bằng trình phát mặc định, các workspace chính, Qt UI/engine smoke test và bộ hồi quy hiện có. Gói FULL/UPDATE được kiểm tra cấu trúc ZIP và SHA-256 trước khi xuất bản Stable.
