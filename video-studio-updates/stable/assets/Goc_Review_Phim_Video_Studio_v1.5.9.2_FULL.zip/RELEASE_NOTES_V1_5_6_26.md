# Gốc Review Phim Video Studio v1.5.6.26

## Lưu kết quả CTA theo video

- Kết quả quét CTA Subscribe tự động được lưu vào bộ nhớ cục bộ theo từng video.
- Mở lại cùng video sẽ tự nạp các khoảng CTA đã phát hiện trước đó.
- Thumbnail xem lại được dựng lại từ video gốc sau khi mở lại, không phụ thuộc file tạm của lần chạy cũ.
- Nếu dừng giữa chừng, các ứng viên đã có vẫn được lưu để xem và chọn cắt ở lần sau.
- Mask, vùng loại trừ và các thiết lập dự án tiếp tục được lưu trong file `.grproj` như trước.

Lưu ý: bản này nạp lại kết quả đã quét; việc tiếp tục đúng từ mẫu hình ảnh cuối cùng của một lượt quét bị dừng sẽ được xử lý riêng nếu cần.

