# Góc Review Phim Video Studio v1.5.6.32

## Giảm bỏ sót CTA trên video dài
- Sửa giới hạn 1.800/7.200 mẫu khiến mật độ quét tự giãn trên video nhiều giờ. Mật độ đã chọn nay được giữ đến giới hạn an toàn rõ ràng 120.000 mẫu.
- Bổ sung **Rất dày · 0,25 giây/ảnh**; giữ các mức 0,5 / 1 / 2 giây và Quét kỹ.
- Tăng kích thước ảnh đầu vào OCR khi quét dày/kỹ.
- Hạ ngưỡng loại token OCR nhưng vẫn yêu cầu cụm từ Subscribe/Đăng ký khớp ngữ nghĩa; giữ ứng viên chữ rõ nghĩa chỉ xuất hiện trong một mẫu với điểm OCR thấp để người dùng xem lại.
- Thêm giới hạn lượt 2 riêng 60.000 mẫu; nếu chạm giới hạn, giao diện báo rõ.
- Hiển thị riêng mật độ thực tế lượt 1/lượt 2, không dùng lượt 2 để che việc lượt 1 đã thưa.

## Workflow
- Làm rõ **Quét bổ sung** chỉ tiếp tục phần video chưa quét theo key đã lưu; muốn chạy lại toàn bộ bằng mật độ mới thì dùng **Quét CTA Subscribe**.

## Giữ nguyên
- Chỉ nhận diện CTA hiển thị trong hình ảnh/video; không phân tích lời nói hoặc âm thanh.
- OCR Anh/Việt, Pause/Resume, Stop, cache, thumbnail, hai lượt quét, duyệt thủ công và Xóa tất cả.
- Không thay đổi Mask/Brush/Eraser, Overlay Detector, Branding, Auto Save, Batch, QC và xuất video.

## Nâng cấp
- UPDATE tương thích trực tiếp với v1.5.6.30 và v1.5.6.31.
- Không chứa video nguồn, dự án, .venv, downloads hoặc renders.
- Kiểm thử lập kế hoạch mẫu đúng thời lượng 227 phút, giới hạn an toàn và OCR một mẫu.
