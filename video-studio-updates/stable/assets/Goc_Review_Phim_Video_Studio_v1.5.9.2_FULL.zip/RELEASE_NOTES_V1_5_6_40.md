# Góc Review Phim Video Studio v1.5.6.40

## Làm sạch · Mask

- Bỏ chức năng quét tự động **Phát hiện lớp phủ** (tìm logo, chữ, watermark và banner) khỏi workspace Qt và giao diện legacy.
- Gỡ workspace quét lớp phủ, các nút Quét/Tạm dừng/Dừng, danh sách ứng viên, thumbnail xem lại và thao tác đưa vùng quét vào Mask.
- Giữ nguyên toàn bộ khu vực Mask thủ công: khoanh vùng, khung chữ nhật, Brush/Eraser, Undo/Redo, Smart Mask, chỉnh PX, tạo Mask và Before/After.
- Giữ nguyên CTA Detector và các chức năng biên tập/xuất video khác.

## Kiểm thử

- `py_compile`: `app.py`, `engine_worker.py`, `qt_app.py`, `cta_detector.py` — PASS.
- Kiểm tra tĩnh: không còn entry point/workspace/command cho overlay scan trong Qt shell hoặc engine worker — PASS.
- Chưa kiểm thử GUI trực tiếp trên Windows trong môi trường build; cần xác nhận giao diện sau khi cài bản cập nhật.

## Phạm vi phiên bản

- Bản này chỉ gỡ trình quét lớp phủ tự động. Việc lưu hồ sơ CTA riêng theo từng video là thay đổi kế tiếp, chưa nằm trong gói này.
