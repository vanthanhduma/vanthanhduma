# v1.5.5.4 — One-Click Update + Launcher Repair

- Nút **Kiểm tra & cập nhật** thực hiện một lần bấm: kiểm tra Stable, tự tải, xác minh chữ ký Ed25519/SHA-256 và chuyển sang cài đặt an toàn; không hỏi xác nhận lần hai.
- Giữ thao tác tải trong cửa sổ cập nhật, có thể hủy trước khi áp dụng; cài đặt chỉ bắt đầu sau khi Engine, CTA Detector và các tác vụ đang chạy hoàn tất.
- Ưu tiên `pythonw.exe` cho launcher/shortcut; sửa shortcut Desktop trỏ qua Windows Script Host, không mở cửa sổ Terminal đen. `CHAY_TOOL.bat` cũng gọi launcher ẩn thay vì giữ cửa sổ console.
- Bộ cài tự tạo/cập nhật shortcut Desktop sau khi cài dependency.
- Khi logo riêng của project không còn ở đường dẫn đã lưu, tự dùng logo mặc định, ghi chú ở thanh trạng thái và không bật cảnh báo modal gây gián đoạn. Khi lưu project, đường dẫn logo mặc định được ghi lại.
- Không thay đổi schema project, engine video, CTA workflow hoặc dữ liệu cá nhân.
