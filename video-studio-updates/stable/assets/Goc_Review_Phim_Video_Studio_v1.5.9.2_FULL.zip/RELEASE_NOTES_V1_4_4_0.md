# v1.4.4.0 — Downloader Module + Update Packaging

## Added
- Sidebar navigation **Tải Video** with a dedicated page; existing editor/inspector workspace remains intact.
- Facebook Reel/Watch and YouTube single-video link validation.
- Sequential download queue based on yt-dlp, local FFmpeg discovery, progress/speed/ETA, stop request, output folder and optional local browser cookies.
- Quality presets: highest automatically, up to 1080p, up to 720p; optional MP4 preference.
- Separate dependency updater for yt-dlp.

## Packaging
- FULL archive for clean install.
- UPDATE archive contains only changed files and a one-click PowerShell updater.
- Updater verifies base version, creates timestamped backup of replaced files, preserves user data and updates yt-dlp in the existing `.venv`.
- SHA-256 release manifest for reproducibility.

## Compatibility
- Built on v1.4.3.1. Existing project schema and editing/Detector/Mask/Branding/Export engine are not modified.

## Known constraints
- Platform extractors can change; a current yt-dlp is required.
- Download works only where the platform and the user's rights/access permit it.
- Actual Windows GUI and live Facebook/YouTube downloads must be confirmed on the user's Windows machine; this build container does not have PySide6 or yt-dlp installed.
