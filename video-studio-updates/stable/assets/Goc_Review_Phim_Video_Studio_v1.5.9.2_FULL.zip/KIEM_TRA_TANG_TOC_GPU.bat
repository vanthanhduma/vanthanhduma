@echo off
setlocal
chcp 65001 >nul
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "PY=%ROOT%\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Chua cai dat tool. Hay chay CAI_DAT_VA_CHAY.bat truoc.
  pause
  exit /b 1
)
"%PY%" "%ROOT%\gpu_check.py"
echo.
echo Gui anh ket qua nay neu can kiem tra them tang toc GPU.
pause
