# KIỂM THỬ v1.4.3.1 – Detector Start Button Visibility Hotfix

Ngày kiểm thử: 12/11/2026

## 1. Nguyên nhân
Trong `open_watermark_detection()`, hàng nút điều khiển được đóng gói (`pack`) sau bảng kết quả có `fill="both", expand=True`, phần gợi ý và trình quản lý khoảng bỏ. Tổng chiều cao nội dung vượt vùng client của cửa sổ 1160×790; hàng nút được tạo trong source nhưng bị đẩy xuống dưới mép nhìn thấy. Vì vậy người dùng không tìm thấy nút BẮT ĐẦU QUÉT.

## 2. Sửa lỗi
- Chuyển BẮT ĐẦU QUÉT, DỪNG QUÉT, DÙNG VÙNG ĐÃ CHỌN và ĐÓNG lên ngay dưới hàng Mức quét, trước phần nội dung có thể co giãn.
- Đặt Transient làm chế độ mặc định vì workflow đang ưu tiên tìm lớp phủ xuất hiện vài giây.
- Giữ nguyên Quick / Standard / Deep, thuật toán detector, thao tác candidate, project schema 4, cắt hình/tiếng và export.
- Giữ kích thước cửa sổ 1160×790 để không chiếm quá nhiều màn hình laptop.

## 3. Kết quả kiểm thử

| Ca kiểm thử | Kết quả |
|---|---|
| `py_compile` app.py, qt_app.py, engine_worker.py, gpu_check.py | PASS |
| Tk GUI dưới Xvfb 1600×900, cửa sổ 1160×790 | PASS |
| Nút BẮT ĐẦU QUÉT đã map và nằm trong client area | PASS – y=138…183 px, hoàn toàn hiển thị |
| Chế độ mặc định | PASS – Transient |
| Nhấn nút thật (invoke) và chạy quét synthetic clip | PASS – scan bắt đầu, tiến trình chạy, hoàn tất và trả 1 candidate Banner |
| Nút DỪNG QUÉT / DÙNG VÙNG ĐÃ CHỌN ban đầu | PASS – trạng thái disabled đúng trước khi chạy |
| Chọn occurrence, lấy mốc, thêm/sửa/xóa khoảng | PASS |
| Project schema 4 round-trip | PASS |
| Mở tương thích project schema 3 | PASS |
| Transient detect trên 2 clip mẫu | PASS – lần lượt 4 và 3 candidates; tùy nội dung nguồn |
| Synthetic banner chỉ xuất hiện 0,64 giây | PASS – được ghi nhận một mẫu và gắn cảnh báo cần duyệt kỹ |
| Xuất đoạn mẫu thật 1280×720 với khoảng bỏ | PASS – 5,5 giây, QC 10 đạt / 0 cảnh báo / 0 lỗi; lệch thời lượng stream A/V 0,02 giây |

## 4. Phạm vi và giới hạn
- GUI đã được chạy thực tế dưới Xvfb trên Linux; đây không thay thế nghiệm thu DPI/native-window behavior trên laptop Windows.
- Không benchmark video dài hàng chục phút/giờ trong hotfix này.
- Không thay đổi encoder hoặc đường GPU; NVENC vẫn cần xác nhận trên Windows/RTX 2070 Super.
- Detector heuristic có thể bỏ sót lớp phủ mờ/di chuyển hoặc gợi ý nhầm. Không candidate nào tự động bị cắt; người dùng phải duyệt khoảng bỏ.

## Kết luận
Lỗi chính của v1.4.3.0 đã được tái hiện từ bố cục source, sửa và kiểm tra bằng GUI: nút BẮT ĐẦU QUÉT hiển thị rõ, thao tác bấm thật chạy Detector thành công. Bản hotfix được đóng gói thành v1.4.3.1 FULL và UPDATE.
