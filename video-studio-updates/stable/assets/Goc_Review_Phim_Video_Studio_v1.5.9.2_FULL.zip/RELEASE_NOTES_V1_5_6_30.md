# Góc Review Phim Video Studio v1.5.6.30

## Sửa lag và đơ khi làm Mask / quét lớp phủ
- Brush/Eraser cache polygon clip-mask và chỉ áp dụng phép giao trên vùng ROI đã khoanh, không tạo lại mask toàn khung hình cho từng điểm rê chuột.
- Tự tách nét giới hạn ảnh làm việc của GrabCut ở mức tối đa 1280 px mỗi chiều lớn; kết quả vẫn được đưa về đúng độ phân giải video.
- Khi OpenCV không giải mã đủ ảnh mẫu, Overlay Detector dùng một tiến trình FFmpeg duy nhất thay vì mở tiến trình riêng cho từng mốc.
- Giảm tần suất thông báo tiến độ gửi lên giao diện.

## CTA Subscribe
- Thêm nút **Xóa tất cả** để xóa mọi ứng viên và cache CTA của video hiện tại sau khi xác nhận.
- Gom cập nhật live theo nhịp 450 ms và dựng lại bảng theo lô để hạn chế giật/đơ khi có nhiều ứng viên.

## Giữ nguyên
- CTA quét hai lượt, OCR Anh/Việt, Pause/Resume, Stop, quét bổ sung và duyệt thủ công trước khi cắt.
- Overlay Detector độc lập, duyệt vùng trước khi đưa vào Mask.
- Undo/Redo, Smart Mask, Mask theo phân cảnh, lưu/mở dự án, Auto Save, Branding, Downloader, Batch Processing, QC và xuất video.

## Nâng cấp
- Gói UPDATE dành cho v1.5.6.29.
- Payload không bao gồm dữ liệu dự án, cài đặt, .venv, video nguồn, downloads hoặc renders.
- Bổ sung kiểm thử hồi quy tĩnh cho thao tác xóa CTA, refresh theo lô, cache ROI của Mask và fallback FFmpeg một tiến trình.
