"""Persistent, sequential queue primitives for Batch CTA Processing.

This module deliberately does not run the detector or edit projects.  The GUI/engine
owns those operations; this module guarantees durable queue state and safe resume.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

QUEUE_SCHEMA_VERSION = 1
QUEUE_FILENAME = "queue.json"
VALID_STATUSES = {"queued", "scanning", "saving", "completed", "failed", "skipped"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_stem(value: str) -> str:
    stem = Path(value).stem.strip() or "Video"
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", stem)
    stem = re.sub(r"\s+", " ", stem).strip(" .")
    return (stem or "Video")[:100]


def _unique_project_dir(root: Path, video_path: Path) -> Path:
    base = _safe_stem(video_path.name)
    candidate = root / base
    index = 2
    while candidate.exists():
        candidate = root / f"{base}_{index}"
        index += 1
    return candidate


class BatchCTAQueue:
    """One sequential CTA batch, persisted atomically in <output>/Batch_Queue/queue.json."""

    def __init__(self, output_folder: str | Path, state: dict[str, Any] | None = None):
        self.output_folder = Path(output_folder).expanduser().resolve()
        self.queue_dir = self.output_folder / "Batch_Queue"
        self.state_path = self.queue_dir / QUEUE_FILENAME
        self.state: dict[str, Any] = state or {
            "schema_version": QUEUE_SCHEMA_VERSION,
            "created_at": _utc_now(),
            "updated_at": _utc_now(),
            "status": "idle",
            "current_index": 0,
            "jobs": [],
        }

    @classmethod
    def create(cls, video_paths: list[str | Path], output_folder: str | Path) -> "BatchCTAQueue":
        queue = cls(output_folder)
        queue.output_folder.mkdir(parents=True, exist_ok=True)
        seen: set[str] = set()
        jobs = []
        reserved_project_dirs: set[str] = set()
        for raw in video_paths:
            source = Path(raw).expanduser().resolve()
            if not source.is_file():
                raise FileNotFoundError(f"Không tìm thấy video: {source}")
            key = os.path.normcase(str(source))
            if key in seen:
                continue
            seen.add(key)
            project_dir = _unique_project_dir(queue.output_folder, source)
            base_dir = project_dir
            suffix = 2
            while os.path.normcase(str(project_dir)) in reserved_project_dirs:
                project_dir = base_dir.with_name(f"{base_dir.name}_{suffix}")
                suffix += 1
            reserved_project_dirs.add(os.path.normcase(str(project_dir)))
            jobs.append({
                "id": uuid.uuid4().hex,
                "source_path": str(source),
                "project_dir": str(project_dir),
                "project_path": str(project_dir / f"{_safe_stem(source.name)}.grproj"),
                "status": "queued",
                "progress": 0,
                "error": "",
                "created_at": _utc_now(),
                "updated_at": _utc_now(),
            })
        if not jobs:
            raise ValueError("Hàng đợi không có video hợp lệ.")
        queue.state["jobs"] = jobs
        queue.state["status"] = "queued"
        queue.save()
        return queue

    @classmethod
    def load(cls, queue_json: str | Path) -> "BatchCTAQueue":
        path = Path(queue_json).expanduser().resolve()
        data = json.loads(path.read_text(encoding="utf-8"))
        if int(data.get("schema_version", 0)) != QUEUE_SCHEMA_VERSION:
            raise ValueError("Phiên bản dữ liệu hàng đợi không được hỗ trợ.")
        queue = cls(path.parent.parent, data)
        # A process that vanished while scanning/saving did not finish that job.
        # Re-queue it; completed jobs are retained and never scanned again.
        for job in queue.jobs:
            if job.get("status") in {"scanning", "saving", "failed"}:
                previous_error = str(job.get("error", "") or "")
                job["status"] = "queued"
                job["progress"] = 0
                if previous_error:
                    job["error"] = "Sẽ thử lại video chưa hoàn thành. Lỗi trước: " + previous_error[:220]
                else:
                    job["error"] = "Tác vụ bị dừng khi ứng dụng đóng; sẽ tiếp tục từ đầu video này."
                job["updated_at"] = _utc_now()
        if queue.state.get("status") == "running" or any(
            job.get("status") == "queued" for job in queue.jobs
        ):
            queue.state["status"] = "stopped"
        queue.save()
        return queue

    @property
    def jobs(self) -> list[dict[str, Any]]:
        return self.state.setdefault("jobs", [])

    @property
    def current_job(self) -> dict[str, Any] | None:
        for job in self.jobs:
            if job.get("status") in {"scanning", "saving"}:
                return job
        return next((job for job in self.jobs if job.get("status") == "queued"), None)

    @property
    def completed_count(self) -> int:
        return sum(job.get("status") == "completed" for job in self.jobs)

    @property
    def failed_count(self) -> int:
        return sum(job.get("status") == "failed" for job in self.jobs)

    @property
    def finished(self) -> bool:
        return not any(job.get("status") in {"queued", "scanning", "saving"} for job in self.jobs)

    def save(self) -> None:
        self.queue_dir.mkdir(parents=True, exist_ok=True)
        self.state["updated_at"] = _utc_now()
        fd, temporary = tempfile.mkstemp(prefix="queue.", suffix=".tmp", dir=str(self.queue_dir))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(self.state, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.state_path)
        finally:
            try:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            except OSError:
                pass

    def set_status(self, job_id: str, status: str, *, progress: int | None = None,
                   error: str | None = None) -> dict[str, Any]:
        if status not in VALID_STATUSES:
            raise ValueError(f"Trạng thái không hợp lệ: {status}")
        job = next((item for item in self.jobs if item["id"] == job_id), None)
        if job is None:
            raise KeyError(job_id)
        job["status"] = status
        if progress is not None:
            job["progress"] = max(0, min(100, int(progress)))
        if status == "completed":
            job["progress"] = 100
            job["error"] = ""
        elif error is not None:
            job["error"] = str(error)
        job["updated_at"] = _utc_now()
        self.state["status"] = "completed" if self.finished else "running"
        self.save()
        return job

    def stop_safely(self) -> None:
        for job in self.jobs:
            if job.get("status") in {"scanning", "saving"}:
                job["status"] = "queued"
                job["progress"] = 0
                job["error"] = "Đã dừng an toàn khi đóng ứng dụng; video này sẽ được quét lại từ đầu."
                job["updated_at"] = _utc_now()
        self.state["status"] = "stopped"
        self.save()

    def next_job(self) -> dict[str, Any] | None:
        if any(job.get("status") in {"scanning", "saving"} for job in self.jobs):
            raise RuntimeError("Batch CTA chỉ cho phép xử lý một video tại một thời điểm.")
        return next((job for job in self.jobs if job.get("status") == "queued"), None)

    def summary(self) -> dict[str, int]:
        return {status: sum(job.get("status") == status for job in self.jobs)
                for status in sorted(VALID_STATUSES)}
