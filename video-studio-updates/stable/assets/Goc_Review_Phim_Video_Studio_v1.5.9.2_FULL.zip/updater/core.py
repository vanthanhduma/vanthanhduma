from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse
from typing import Callable

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

APP_ID = "goc-review-phim-video-studio"
# Public distribution endpoint. The application source repository remains private.
# This public repository is used only for signed Stable release assets.
UPDATE_REPO_OWNER = "vanthanhduma"
UPDATE_REPO_NAME = "vanthanhduma"
PUBLIC_FEED_ROOT = (
    "https://raw.githubusercontent.com/vanthanhduma/vanthanhduma/main/"
    "video-studio-updates/stable"
)
PUBLIC_ASSET_ROOT = PUBLIC_FEED_ROOT + "/assets/"
MANIFEST_URL = PUBLIC_FEED_ROOT + "/latest.json"
SIGNATURE_URL = PUBLIC_FEED_ROOT + "/latest.sig"
MAX_PACKAGE_BYTES = 2 * 1024 * 1024 * 1024
MAX_EXPANDED_BYTES = 3 * 1024 * 1024 * 1024
PRESERVE_PATHS = {
    ".venv", "projects", "downloads", "renders", "logs", "_backups",
    "user_settings.json", "assets/user", "autosave",
}


class UpdateError(RuntimeError):
    pass


def version_tuple(value: str) -> tuple[int, ...]:
    match = re.fullmatch(r"v?(\d+(?:\.\d+){2,3})", str(value).strip())
    if not match:
        raise UpdateError(f"Phiên bản không hợp lệ: {value!r}")
    return tuple(int(part) for part in match.group(1).split("."))


def is_newer(candidate: str, current: str) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def _safe_relative_path(value: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise UpdateError("Đường dẫn file trong manifest không hợp lệ.")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise UpdateError(f"Đường dẫn cập nhật không an toàn: {value}")
    if path.parts[0].startswith("~"):
        raise UpdateError(f"Đường dẫn cập nhật không hợp lệ: {value}")
    reserved = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    for part in path.parts:
        device = part.split(".", 1)[0].upper()
        if ":" in part or part.endswith((".", " ")) or device in reserved:
            raise UpdateError(f"Tên thành phần đường dẫn không an toàn trên Windows: {value}")
    lowered = value.lower()
    for preserved in PRESERVE_PATHS:
        p = preserved.lower().rstrip("/")
        if lowered == p or lowered.startswith(p + "/"):
            raise UpdateError(f"Manifest cố thay đổi dữ liệu cần giữ nguyên: {value}")
    return path.as_posix()


def validate_manifest(manifest: dict, current_version: str | None = None) -> dict:
    if not isinstance(manifest, dict):
        raise UpdateError("Manifest không phải JSON object.")
    if manifest.get("schema_version") != 1 or manifest.get("app_id") != APP_ID:
        raise UpdateError("Manifest không thuộc ứng dụng này hoặc sai schema.")
    version = str(manifest.get("version", ""))
    version_tuple(version)
    if current_version and not is_newer(version, current_version):
        raise UpdateError("Bản phát hành không mới hơn phiên bản đang dùng.")
    if manifest.get("channel", "stable") != "stable":
        raise UpdateError("Ứng dụng chỉ nhận kênh Stable.")
    trust_mode = str(manifest.get("trust_mode", "ed25519-v1"))
    if trust_mode not in {"ed25519-v1", "https-sha256-v1"}:
        raise UpdateError("Manifest khai báo phương thức xác thực không hỗ trợ.")
    if trust_mode == "https-sha256-v1" and not str(manifest.get("asset_url", "")).startswith(PUBLIC_ASSET_ROOT):
        raise UpdateError("Manifest HTTPS-SHA256 phải trỏ tới kho phát hành cố định.")
    size = int(manifest.get("asset_size", 0))
    if size <= 0 or size > MAX_PACKAGE_BYTES:
        raise UpdateError("Dung lượng gói cập nhật không hợp lệ hoặc vượt giới hạn.")
    digest = str(manifest.get("asset_sha256", "")).lower()
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise UpdateError("Manifest thiếu SHA-256 hợp lệ cho gói cập nhật.")
    asset_name = str(manifest.get("asset_name", ""))
    if not asset_name.lower().endswith(".zip") or "/" in asset_name or "\\" in asset_name:
        raise UpdateError("Tên gói cập nhật không hợp lệ.")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise UpdateError("Manifest không có danh sách file cập nhật.")
    seen = set()
    normalised = []
    for entry in files:
        if not isinstance(entry, dict):
            raise UpdateError("Một mục file trong manifest không hợp lệ.")
        relative = _safe_relative_path(entry.get("path"))
        if relative.casefold() in seen:
            raise UpdateError(f"Manifest có đường dẫn trùng (không phân biệt hoa thường): {relative}")
        seen.add(relative.casefold())
        if entry.get("action", "replace") != "replace":
            raise UpdateError("Phiên bản updater này chỉ cho phép thay thế file; không cho phép xóa.")
        file_hash = str(entry.get("sha256", "")).lower()
        file_size = int(entry.get("size", -1))
        if not re.fullmatch(r"[0-9a-f]{64}", file_hash) or file_size < 0:
            raise UpdateError(f"Thiếu hash hoặc size hợp lệ cho {relative}.")
        normalised.append({"path": relative, "sha256": file_hash, "size": file_size, "action": "replace"})
    result = dict(manifest)
    result["files"] = normalised
    return result


def sha256_file(path: Path, progress: Callable[[int], None] | None = None) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
            size += len(chunk)
            if progress:
                progress(size)
    return digest.hexdigest(), size


LEGACY_SIGNATURE_VERSION = "1.5.5.2"
# SHA-256 of the exact public Stable manifest already installed/trusted by v1.5.5.2.
# The legacy key is never accepted for any other manifest, even at the same version.
LEGACY_MANIFEST_SHA256 = "a99b77536088babaa9bf2ebcec3851b1952fb2e53486afcd836fa8b8fbb9d881"
LEGACY_PUBLIC_KEY_NAME = "update-public-key-legacy.pem"


def verify_manifest_signature(manifest_bytes: bytes, signature_bytes: bytes, public_key_path: Path) -> dict:
    """Verify with the rotated primary key, with a tightly limited legacy bridge.

    The previous private key is unavailable. To avoid bricking existing installs,
    accept the previously published v1.5.5.2 manifest with its old public key only.
    No manifest at a newer version can be authenticated by the legacy key.
    """
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        signature_text = signature_bytes.decode("ascii").strip()
        signature = base64.b64decode(signature_text, validate=True)
        public_key = serialization.load_pem_public_key(public_key_path.read_bytes())
        if not isinstance(public_key, Ed25519PublicKey):
            raise UpdateError("Public key không phải Ed25519.")
        try:
            public_key.verify(signature, manifest_bytes)
            return manifest
        except Exception as primary_error:
            # This is a one-version migration exception, not a general fallback.
            if (
                str(manifest.get("version", "")) != LEGACY_SIGNATURE_VERSION
                or hashlib.sha256(manifest_bytes).hexdigest() != LEGACY_MANIFEST_SHA256
            ):
                raise primary_error
            legacy_path = public_key_path.with_name(LEGACY_PUBLIC_KEY_NAME)
            if not legacy_path.is_file():
                raise primary_error
            legacy_key = serialization.load_pem_public_key(legacy_path.read_bytes())
            if not isinstance(legacy_key, Ed25519PublicKey):
                raise UpdateError("Legacy public key không phải Ed25519.")
            legacy_key.verify(signature, manifest_bytes)
            return manifest
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError("Chữ ký manifest không hợp lệ hoặc manifest bị sửa đổi.") from exc


class PublicUpdateClient:
    """Anonymous HTTPS client for the static public update feed.

    No GitHub login, PAT, OAuth, API rate-limit budget, or account connection is
    required on end-user machines. The signed manifest is the trust anchor.
    """
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "GocReviewVideoStudio-Updater/1.1",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        })

    @staticmethod
    def _cache_bust(url: str) -> str:
        return url + ("&" if "?" in url else "?") + f"_={int(time.time())}"

    def fetch_bytes(self, url: str, max_bytes: int = 2 * 1024 * 1024) -> bytes:
        if not isinstance(url, str) or not url.startswith(PUBLIC_FEED_ROOT + "/"):
            raise UpdateError("URL không thuộc máy chủ cập nhật công khai đã cấu hình.")
        with self.session.get(self._cache_bust(url), timeout=(10, 30), stream=True, allow_redirects=True) as response:
            # Do not follow a redirect to an arbitrary host. The public feed is pinned
            # to this exact GitHub raw-content repository and HTTPS certificate checks
            # remain enabled by requests.
            final = urlparse(response.url)
            expected = urlparse(PUBLIC_FEED_ROOT)
            if final.scheme != "https" or final.hostname != expected.hostname:
                raise UpdateError("Máy chủ cập nhật chuyển hướng khỏi GitHub HTTPS chính chủ.")
            if response.status_code == 404:
                raise UpdateError("Kênh cập nhật công khai chưa có bản Stable. Bạn không cần đăng nhập; hãy thử lại sau.")
            if response.status_code in (401, 403):
                raise UpdateError("Máy chủ cập nhật đang từ chối yêu cầu công khai. Hãy thử lại sau ít phút.")
            response.raise_for_status()
            chunks = []
            total = 0
            for chunk in response.iter_content(chunk_size=64 * 1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > max_bytes:
                    raise UpdateError("Dữ liệu từ máy chủ cập nhật vượt giới hạn an toàn.")
                chunks.append(chunk)
            return b"".join(chunks)

    def fetch_manifest(self, current_version: str, public_key_path: Path) -> tuple[dict, dict] | None:
        manifest_bytes = self.fetch_bytes(MANIFEST_URL, max_bytes=2 * 1024 * 1024)
        try:
            announced = json.loads(manifest_bytes.decode("utf-8"))
        except Exception as exc:
            raise UpdateError("Manifest Stable không phải JSON UTF-8 hợp lệ.") from exc

        signature_bytes = b""
        trust_mode = str(announced.get("trust_mode", "ed25519-v1"))
        if trust_mode == "https-sha256-v1":
            # New release channel: authenticated HTTPS to the pinned GitHub raw
            # repository + SHA-256 for the archive and every payload file.
            # No PAT, GitHub Actions secret, or offline signing key is required.
            manifest = announced
        elif trust_mode in {"ed25519-v1", ""}:
            signature_bytes = self.fetch_bytes(SIGNATURE_URL, max_bytes=4096)
            manifest = verify_manifest_signature(manifest_bytes, signature_bytes, public_key_path)
        else:
            raise UpdateError(f"Phương thức xác thực cập nhật không được hỗ trợ: {trust_mode}")

        manifest = validate_manifest(manifest)
        expected_asset_url = PUBLIC_ASSET_ROOT + manifest["asset_name"]
        if manifest.get("asset_url") != expected_asset_url:
            raise UpdateError("Địa chỉ gói cập nhật không đúng kho phát hành đã cấu hình.")
        if not is_newer(manifest["version"], current_version):
            return None
        supported_bases = manifest.get("supported_base_versions") or [manifest.get("base_version", "")]
        supported_bases = {str(value).lstrip("v") for value in supported_bases if value}
        if supported_bases and str(current_version).lstrip("v") not in supported_bases:
            raise UpdateError(
                f"Bản cập nhật v{manifest['version']} không hỗ trợ nâng cấp trực tiếp từ v{current_version}. "
                "Hãy cài bản FULL phù hợp trước."
            )
        manifest = validate_manifest(manifest, current_version)
        manifest["_asset_url"] = expected_asset_url
        manifest["_manifest_bytes_b64"] = base64.b64encode(manifest_bytes).decode("ascii")
        manifest["_signature_bytes_b64"] = base64.b64encode(signature_bytes).decode("ascii") if signature_bytes else ""
        release = {
            "body": manifest.get("release_notes", ""),
            "published_at": manifest.get("published_at", ""),
            "html_url": manifest.get("release_notes_url", "https://github.com/vanthanhduma/vanthanhduma/tree/main/video-studio-updates/stable"),
        }
        manifest["_release_url"] = release["html_url"]
        manifest["_release_date"] = release["published_at"]
        return manifest, release

    def download_asset(self, url: str, asset_size: int, destination: Path,
                       progress=None, cancel_event=None) -> None:
        if not isinstance(url, str) or not url.startswith(PUBLIC_ASSET_ROOT):
            raise UpdateError("URL gói tải không thuộc kho phát hành công khai đã cấu hình.")
        if asset_size <= 0 or asset_size > MAX_PACKAGE_BYTES:
            raise UpdateError("Dung lượng gói cập nhật không hợp lệ.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        downloaded = 0
        with self.session.get(self._cache_bust(url), stream=True, timeout=(15, 60), allow_redirects=True) as response:
            final = urlparse(response.url)
            expected = urlparse(PUBLIC_ASSET_ROOT)
            requested = urlparse(url)
            if (
                final.scheme != "https"
                or final.hostname != expected.hostname
                or final.path != requested.path
            ):
                raise UpdateError("Máy chủ tải gói chuyển hướng khỏi GitHub HTTPS chính chủ.")
            if response.status_code == 404:
                raise UpdateError("Không tìm thấy gói cập nhật trên máy chủ công khai.")
            response.raise_for_status()
            if "json" in response.headers.get("Content-Type", "").lower():
                raise UpdateError("Máy chủ trả metadata thay vì file ZIP. Hãy thử lại sau.")
            with destination.open("wb") as handle:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if cancel_event is not None and cancel_event.is_set():
                        raise UpdateError("Đã hủy tải cập nhật theo yêu cầu.")
                    if not chunk:
                        continue
                    handle.write(chunk)
                    downloaded += len(chunk)
                    if downloaded > asset_size or downloaded > MAX_PACKAGE_BYTES:
                        raise UpdateError("File tải về lớn hơn dung lượng khai báo.")
                    if progress:
                        progress(downloaded, asset_size)
        if downloaded != asset_size:
            raise UpdateError("File tải về bị thiếu dữ liệu.")


def check_for_update(current_version: str, public_key_path: Path) -> tuple[dict, dict] | None:
    return PublicUpdateClient().fetch_manifest(current_version, public_key_path)


def extract_and_verify_package(archive_path: Path, manifest: dict, stage_root: Path, cancel_event=None) -> Path:
    manifest = validate_manifest(manifest)
    expected = {entry["path"]: entry for entry in manifest["files"]}
    if stage_root.exists():
        shutil.rmtree(stage_root)
    payload_root = stage_root / "payload"
    payload_root.mkdir(parents=True, exist_ok=True)
    expanded = 0
    found = set()
    try:
        with zipfile.ZipFile(archive_path, "r") as archive:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                name = info.filename
                if name.startswith("/") or "\\" in name or ".." in PurePosixPath(name).parts:
                    raise UpdateError(f"ZIP có đường dẫn không an toàn: {name}")
                if not name.startswith("payload/"):
                    raise UpdateError(f"ZIP chứa file ngoài payload: {name}")
                relative = _safe_relative_path(name[len("payload/"):])
                if relative not in expected:
                    raise UpdateError(f"ZIP có file không được khai báo trong manifest: {relative}")
                if relative in found:
                    raise UpdateError(f"ZIP có đường dẫn file trùng: {relative}")
                # Unix symlinks in ZIP are rejected. No executable metadata is trusted.
                mode = (info.external_attr >> 16) & 0xFFFF
                if (mode & 0o170000) == 0o120000:
                    raise UpdateError(f"ZIP chứa symbolic link không an toàn: {relative}")
                expanded += info.file_size
                if expanded > MAX_EXPANDED_BYTES:
                    raise UpdateError("Gói cập nhật giải nén vượt giới hạn an toàn.")
                target = payload_root.joinpath(*PurePosixPath(relative).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                digest = hashlib.sha256()
                size = 0
                with archive.open(info, "r") as source, target.open("xb") as dest:
                    while True:
                        if cancel_event is not None and cancel_event.is_set():
                            raise UpdateError("Đã hủy tải cập nhật theo yêu cầu.")
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        dest.write(chunk)
                        digest.update(chunk)
                        size += len(chunk)
                if size != expected[relative]["size"] or digest.hexdigest() != expected[relative]["sha256"]:
                    raise UpdateError(f"Hash hoặc dung lượng file không đúng: {relative}")
                found.add(relative)
    except zipfile.BadZipFile as exc:
        raise UpdateError("Gói ZIP cập nhật bị hỏng.") from exc
    missing = set(expected) - found
    if missing:
        raise UpdateError("Gói cập nhật thiếu file: " + ", ".join(sorted(missing)[:8]))
    return stage_root


def download_update(manifest: dict, public_key_path: Path, stage_root: Path,
                    progress=None, cancel_event=None) -> Path:
    asset_url = manifest.get("_asset_url") or manifest.get("asset_url")
    if not isinstance(asset_url, str):
        raise UpdateError("Không có địa chỉ gói cập nhật đã xác thực.")
    client = PublicUpdateClient()
    stage_root.mkdir(parents=True, exist_ok=True)
    try:
        (stage_root / "update-manifest.json").write_bytes(base64.b64decode(manifest["_manifest_bytes_b64"]))
        signature_b64 = str(manifest.get("_signature_bytes_b64", ""))
        signature_path = stage_root / "update-manifest.sig"
        if signature_b64:
            signature_path.write_bytes(base64.b64decode(signature_b64))
        else:
            signature_path.unlink(missing_ok=True)
    except Exception as exc:
        raise UpdateError("Không lưu được manifest đã xác thực vào staging.") from exc
    archive_path = stage_root / str(manifest["asset_name"])
    client.download_asset(asset_url, int(manifest["asset_size"]), archive_path,
                          progress=progress, cancel_event=cancel_event)
    if cancel_event is not None and cancel_event.is_set():
        raise UpdateError("Đã hủy tải cập nhật theo yêu cầu.")
    digest, size = sha256_file(archive_path)
    if digest != manifest["asset_sha256"] or size != int(manifest["asset_size"]):
        archive_path.unlink(missing_ok=True)
        raise UpdateError("SHA-256 hoặc kích thước gói cập nhật không khớp manifest.")
    if cancel_event is not None and cancel_event.is_set():
        raise UpdateError("Đã hủy cập nhật theo yêu cầu.")
    extract_root = stage_root / "verified"
    extract_and_verify_package(archive_path, manifest, extract_root, cancel_event=cancel_event)
    return extract_root
