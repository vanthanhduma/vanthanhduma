"""Secure in-app updater for Góc Review Phim Video Studio."""

UPDATER_VERSION = "1.0.0"
