from __future__ import annotations

import argparse
import ctypes
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path, PurePosixPath

from updater.core import (
    PRESERVE_PATHS, UpdateError, sha256_file, validate_manifest,
    verify_manifest_signature,
)


def _wait_for_pid(pid: int, timeout: int = 120) -> None:
    """Wait until the GUI process is actually signaled as exited on Windows."""
    if os.name == "nt":
        SYNCHRONIZE = 0x00100000
        WAIT_OBJECT_0 = 0x00000000
        WAIT_TIMEOUT = 0x00000102
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        kernel32.WaitForSingleObject.restype = ctypes.c_uint32
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
        if not handle:
            error = ctypes.get_last_error()
            # ERROR_INVALID_PARAMETER means the PID has already exited.
            if error == 87:
                return
            raise UpdateError(f"Không thể theo dõi process ứng dụng (WinError {error}).")
        try:
            result = kernel32.WaitForSingleObject(handle, int(timeout * 1000))
            if result == WAIT_OBJECT_0:
                return
            if result == WAIT_TIMEOUT:
                raise UpdateError(f"Ứng dụng chưa thoát sau {timeout} giây; không thay file để tránh hỏng dữ liệu.")
            raise UpdateError(f"Không xác định được trạng thái process ứng dụng (0x{result:08x}).")
        finally:
            kernel32.CloseHandle(handle)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.25)
    raise UpdateError(f"Ứng dụng chưa thoát sau {timeout} giây; không thay file để tránh hỏng dữ liệu.")


def _pid_is_alive(pid: int) -> bool:
    if os.name == "nt":
        SYNCHRONIZE = 0x00100000
        WAIT_TIMEOUT = 0x00000102
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        kernel32.WaitForSingleObject.restype = ctypes.c_uint32
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
        if not handle:
            return ctypes.get_last_error() != 87
        try:
            return kernel32.WaitForSingleObject(handle, 0) == WAIT_TIMEOUT
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _is_preserved(relative: str) -> bool:
    low = relative.replace("\\", "/").lower()
    return any(low == p.lower().rstrip("/") or low.startswith(p.lower().rstrip("/") + "/") for p in PRESERVE_PATHS)


def _health_check(python_exe: Path, root: Path) -> None:
    script = (
        "import py_compile, pathlib, sys; "
        "r=pathlib.Path(sys.argv[1]); "
        "files=['app.py','qt_app.py','engine_worker.py','cta_detector.py','download_engine.py','timeline_seek.py','gpu_check.py','launcher.py']; "
        "[py_compile.compile(str(r/f), doraise=True) for f in files if (r/f).is_file()]; "
        "import PySide6, cv2, numpy, PIL, requests, cryptography; "
        "import updater.core, updater.apply_helper, updater.qt_ui, updater.state, qt_app"
    )
    result = subprocess.run([str(python_exe), "-c", script, str(root)], cwd=str(root),
                            capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "Health check thất bại.")[-5000:]
        raise UpdateError("Health check sau cập nhật thất bại: " + detail)


def _trim_backups(backup_base: Path, keep: int = 3) -> None:
    dirs = sorted((p for p in backup_base.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in dirs[keep:]:
        shutil.rmtree(old, ignore_errors=True)


def _backup_base() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "GocReviewVideoStudio" / "updater" / "backups"


def _log_path() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "GocReviewVideoStudio" / "updater"
    base.mkdir(parents=True, exist_ok=True)
    return base / "apply-helper.log"


def _write_journal(path: Path, journal: dict) -> None:
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(journal, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, path)


def _read_app_version(root: Path) -> str:
    version_file = root / "PHIEN_BAN.txt"
    if not version_file.is_file():
        raise UpdateError("Không xác định được phiên bản ứng dụng đang cài.")
    match = re.search(r"v?(\d+\.\d+\.\d+\.\d+)", version_file.read_text(encoding="utf-8", errors="replace"))
    if not match:
        raise UpdateError("Không đọc được phiên bản ứng dụng từ PHIEN_BAN.txt.")
    return match.group(1)


def _rollback_transaction(root: Path, backup: Path, journal: dict) -> None:
    for item in reversed(journal.get("files", [])):
        relative = item["path"]
        rel = PurePosixPath(relative)
        destination = root.joinpath(*rel.parts)
        temp = destination.with_name(destination.name + ".updater-tmp")
        temp.unlink(missing_ok=True)
        old = backup.joinpath(*rel.parts)
        if item.get("existed"):
            if not old.is_file():
                raise UpdateError(f"Thiếu file sao lưu khi rollback: {relative}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            rollback_temp = destination.with_name(destination.name + ".rollback-tmp")
            shutil.copy2(old, rollback_temp)
            os.replace(rollback_temp, destination)
        else:
            destination.unlink(missing_ok=True)


def recover_incomplete_transactions(root: Path) -> list[str]:
    """Roll back any interrupted apply transaction before the GUI opens."""
    root = root.resolve(strict=True)
    base = _backup_base()
    if not base.is_dir():
        return []
    recovered = []
    for backup in sorted((p for p in base.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime):
        journal_path = backup / "transaction.json"
        if not journal_path.is_file():
            continue
        try:
            journal = json.loads(journal_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if journal.get("status") != "applying" or Path(journal.get("root", "")).resolve() != root:
            continue
        _rollback_transaction(root, backup, journal)
        journal["status"] = "rolled_back_after_interruption"
        _write_journal(journal_path, journal)
        recovered.append(str(backup))
    return recovered


def apply_update(root: Path, stage_root: Path, pid: int, python_exe: Path) -> Path:
    root = root.resolve(strict=True)
    stage_root = stage_root.resolve(strict=True)
    payload = stage_root / "verified" / "payload"
    manifest_bytes = (stage_root / "update-manifest.json").read_bytes()
    signature_path = stage_root / "update-manifest.sig"
    public_key = root / "updater" / "keys" / "update-public-key.pem"
    if signature_path.is_file():
        signature_bytes = signature_path.read_bytes()
        manifest_data = verify_manifest_signature(manifest_bytes, signature_bytes, public_key)
    else:
        try:
            manifest_data = json.loads(manifest_bytes.decode("utf-8"))
        except Exception as exc:
            raise UpdateError("Manifest trong staging không phải JSON hợp lệ.") from exc
        if manifest_data.get("trust_mode") != "https-sha256-v1":
            raise UpdateError("Manifest không có chữ ký và không khai báo HTTPS-SHA256 hợp lệ.")
    manifest = validate_manifest(manifest_data)
    current_version = _read_app_version(root)
    allowed_bases = manifest.get("supported_base_versions") or [manifest.get("base_version", "")]
    if current_version not in [str(value).lstrip("v") for value in allowed_bases if value]:
        raise UpdateError(f"Gói này không hỗ trợ nâng cấp từ v{current_version}.")
    if not payload.is_dir():
        raise UpdateError("Không tìm thấy payload đã giải nén và xác minh.")
    _wait_for_pid(pid)

    backup_base = _backup_base()
    backup_base.mkdir(parents=True, exist_ok=True)
    backup = backup_base / f"{manifest['version']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    backup.mkdir(parents=True, exist_ok=False)
    plan = []
    for entry in manifest["files"]:
        relative = entry["path"]
        if _is_preserved(relative):
            raise UpdateError(f"Từ chối thay đổi dữ liệu người dùng: {relative}")
        rel = PurePosixPath(relative)
        destination = root.joinpath(*rel.parts)
        source = payload.joinpath(*rel.parts)
        if not source.is_file() or source.is_symlink():
            raise UpdateError(f"Thiếu file cập nhật hợp lệ: {relative}")
        if not destination.resolve().is_relative_to(root):
            raise UpdateError(f"Đường dẫn đích vượt khỏi thư mục ứng dụng: {relative}")
        digest, size = sha256_file(source)
        if digest != entry["sha256"] or size != entry["size"]:
            raise UpdateError(f"Payload bị thay đổi sau xác minh: {relative}")
        existed = destination.exists()
        if existed:
            if destination.is_symlink() or not destination.is_file():
                raise UpdateError(f"Từ chối ghi đè file/link bất thường: {relative}")
            old = backup.joinpath(*rel.parts)
            old.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(destination, old)
        plan.append({"path": relative, "existed": existed, "source": str(source)})

    journal_path = backup / "transaction.json"
    journal = {"version": manifest["version"], "root": str(root), "files": [
        {"path": item["path"], "existed": item["existed"]} for item in plan
    ], "status": "applying"}
    _write_journal(journal_path, journal)
    try:
        for item in plan:
            destination = root.joinpath(*PurePosixPath(item["path"]).parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            temp = destination.with_name(destination.name + ".updater-tmp")
            shutil.copy2(Path(item["source"]), temp)
            os.replace(temp, destination)
        if _read_app_version(root) != str(manifest["version"]).lstrip("v"):
            raise UpdateError("PHIEN_BAN.txt không khớp phiên bản trong manifest sau khi cập nhật.")
        _health_check(python_exe, root)
        journal["status"] = "complete"
        _write_journal(journal_path, journal)
        _trim_backups(backup_base, keep=3)
        return backup
    except Exception:
        _rollback_transaction(root, backup, journal)
        journal["status"] = "rolled_back"
        journal["rollback_error"] = traceback.format_exc()[-5000:]
        _write_journal(journal_path, journal)
        raise


def _launch_application(launcher: Path, root: Path, log_path: Path, python_exe: Path) -> None:
    if not launcher.is_file():
        raise UpdateError(f"Không tìm thấy launcher: {launcher}")
    flags = 0
    if os.name == "nt":
        flags = (getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
                 | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
                 | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
    with log_path.open("a", encoding="utf-8") as log:
        log.write(f"[{datetime.now().isoformat()}] Launching app via {launcher}\n")
        log.flush()
        wscript = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "wscript.exe"
        try:
            if not wscript.is_file():
                raise FileNotFoundError(f"Không tìm thấy Windows Script Host: {wscript}")
            subprocess.Popen([str(wscript), str(launcher)], cwd=str(root), stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, close_fds=True, creationflags=flags)
        except Exception as exc:
            log.write(f"[{datetime.now().isoformat()}] WScript launch failed: {exc}; using Python fallback.\n")
            fallback = root / "launcher.py"
            pythonw_exe = python_exe.with_name("pythonw.exe")
            gui_python = pythonw_exe if pythonw_exe.is_file() else python_exe
            if not fallback.is_file() or not gui_python.is_file():
                raise UpdateError(f"Không thể khởi chạy ứng dụng: {exc}") from exc
            subprocess.Popen([str(gui_python), str(fallback)], cwd=str(root), stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, close_fds=True, creationflags=flags)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--stage-root", required=True)
    parser.add_argument("--pid", required=True, type=int)
    parser.add_argument("--python", required=True)
    parser.add_argument("--launcher", required=True)
    args = parser.parse_args()
    log_path = _log_path()
    applied = False
    try:
        recover_incomplete_transactions(Path(args.root))
        backup = apply_update(Path(args.root), Path(args.stage_root), args.pid, Path(args.python))
        applied = True
        shutil.rmtree(Path(args.stage_root), ignore_errors=True)
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(f"[{datetime.now().isoformat()}] Updated successfully. Backup: {backup}\n")
        # Start only after transaction completion and staging cleanup.
        _launch_application(Path(args.launcher), Path(args.root), log_path, Path(args.python))
        return 0
    except Exception:
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(f"[{datetime.now().isoformat()}] FAILED\n{traceback.format_exc()}\n")
        if not applied:
            # If validation failed before the GUI exited, do not open a duplicate instance.
            try:
                _wait_for_pid(args.pid, timeout=20)
                _launch_application(Path(args.launcher), Path(args.root), log_path, Path(args.python))
            except Exception as restart_exc:
                with log_path.open("a", encoding="utf-8") as handle:
                    handle.write(f"[{datetime.now().isoformat()}] Restart after failed update skipped/failed: {restart_exc}\n")
        else:
            # The files are already committed and health-checked; this is a launch problem,
            # not an apply failure. Keep the new version and log the exact reason.
            with log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"[{datetime.now().isoformat()}] Update is installed but automatic relaunch failed.\n")
        try:
            if os.name == "nt":
                ctypes.windll.user32.MessageBoxW(0,
                    "Có lỗi trong bước cập nhật hoặc mở lại Video Studio. "
                    "Nếu quá trình thay file đã bắt đầu, bản cũ đã được rollback khi health-check thất bại. "
                    "Xem log trong LocalAppData\\GocReviewVideoStudio\\updater và logs.",
                    "Góc Review Phim Video Studio", 0x10)
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
