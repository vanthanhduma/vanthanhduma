from __future__ import annotations

import shutil
import tempfile
import threading
from pathlib import Path

from PySide6.QtCore import QObject, Signal, Qt
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar,
    QTextEdit,
)

from updater.core import check_for_update, download_update


class UpdateSignals(QObject):
    checked = Signal(object)
    progress = Signal(int, int)
    downloaded = Signal(object)


class UpdateDialog(QDialog):
    """One-click Stable updater with signed-package verification and safe handoff."""
    update_available = Signal(object)
    no_update = Signal()

    def __init__(self, current_version: str, public_key_path: Path, parent=None):
        super().__init__(parent)
        self.current_version = current_version
        self.public_key_path = Path(public_key_path)
        self.manifest = None
        self.stage_root: Path | None = None
        self.signals = UpdateSignals(self)
        self.signals.checked.connect(self._on_checked)
        self.signals.progress.connect(self._on_progress)
        self.signals.downloaded.connect(self._on_downloaded)
        self._check_thread: threading.Thread | None = None
        self._download_thread: threading.Thread | None = None
        self._cancel_event = threading.Event()
        self._auto_install_after_check = False
        self._build_ui()

    def _build_ui(self):
        self.setWindowTitle("Trung tâm cập nhật")
        self.setMinimumWidth(560)
        self.resize(650, 500)
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 22, 24, 20)
        root.setSpacing(12)

        title = QLabel("TRUNG TÂM CẬP NHẬT")
        title.setStyleSheet("font-size:13pt;font-weight:750;color:#eaf8fb;letter-spacing:0.5px;")
        root.addWidget(title)

        self.status = QLabel("Sẵn sàng kiểm tra bản Stable mới nhất.")
        self.status.setStyleSheet("color:#9ab2bf;font-weight:600;")
        self.status.setWordWrap(True)
        root.addWidget(self.status)

        version_row = QHBoxLayout()
        self.current_label = QLabel(f"ĐANG DÙNG\nv{self.current_version}")
        self.current_label.setStyleSheet(
            "background:#102b3a;border:1px solid #245064;border-radius:9px;padding:14px;font-weight:650;"
        )
        self.new_label = QLabel("PHIÊN BẢN MỚI\nChưa kiểm tra")
        self.new_label.setStyleSheet(
            "background:#102b3a;border:1px solid #245064;border-radius:9px;padding:14px;font-weight:650;"
        )
        version_row.addWidget(self.current_label, 1)
        version_row.addWidget(self.new_label, 1)
        root.addLayout(version_row)

        self.notes = QTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setPlaceholderText("Nội dung phát hành sẽ hiển thị tại đây.")
        self.notes.setMaximumHeight(210)
        root.addWidget(self.notes, 1)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setVisible(False)
        root.addWidget(self.progress)
        self.progress_label = QLabel("")
        self.progress_label.setStyleSheet("color:#9ab2bf;font-size:9pt;")
        root.addWidget(self.progress_label)

        actions = QHBoxLayout()
        self.check_btn = QPushButton("Kiểm tra & cập nhật")
        self.check_btn.setToolTip(
            "Bấm một lần để kiểm tra; nếu có bản Stable mới, ứng dụng tự tải, xác minh và cài đặt."
        )
        self.check_btn.clicked.connect(self._manual_check_and_update)
        actions.addWidget(self.check_btn)
        actions.addStretch(1)
        self.later_btn = QPushButton("Để sau")
        self.later_btn.clicked.connect(self.reject)
        actions.addWidget(self.later_btn)
        root.addLayout(actions)

        self.cancel_btn = QPushButton("Hủy tải cập nhật")
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self._cancel_download)
        root.addWidget(self.cancel_btn, alignment=Qt.AlignmentFlag.AlignRight)

    def _manual_check_and_update(self):
        if self._download_thread and self._download_thread.is_alive():
            return
        if self.manifest:
            self.start_update()
            return
        self.start_check(silent=False, auto_install=True)

    def start_check(self, silent: bool = False, auto_install: bool = False):
        # A manual click while the silent startup check is already running upgrades
        # that in-flight check into the one-click download/install flow.
        if auto_install and not silent:
            self._auto_install_after_check = True
        if self._check_thread and self._check_thread.is_alive():
            return
        if not silent:
            self.status.setText("Đang kiểm tra bản phát hành Stable công khai…")
            self.notes.setPlainText("Đang kết nối máy chủ cập nhật. Không cần tài khoản GitHub hoặc mã token.")
        self.check_btn.setEnabled(False)

        def worker():
            try:
                result = check_for_update(self.current_version, self.public_key_path)
                self.signals.checked.emit({"ok": True, "result": result})
            except Exception as exc:
                self.signals.checked.emit({"ok": False, "error": str(exc)})

        self._check_thread = threading.Thread(target=worker, name="UpdaterCheck", daemon=True)
        self._check_thread.start()

    def _on_checked(self, response):
        # The worker has emitted its only result; clear the handle before enabling retry.
        self._check_thread = None
        self.check_btn.setEnabled(True)
        if not response.get("ok"):
            self.manifest = None
            self._auto_install_after_check = False
            self.status.setText("Chưa thể kiểm tra cập nhật.")
            self.notes.setPlainText(response.get("error", "Lỗi không xác định."))
            self.check_btn.setText("Thử kiểm tra lại")
            return

        result = response.get("result")
        if result is None:
            self.manifest = None
            self._auto_install_after_check = False
            self.status.setText("Bạn đang sử dụng phiên bản Stable mới nhất.")
            self.new_label.setText("PHIÊN BẢN MỚI\nKhông có")
            self.notes.setPlainText("Chưa có bản cập nhật mới hơn trên kênh Stable.")
            self.check_btn.setText("Kiểm tra lại")
            self.no_update.emit()
            return

        manifest, release = result
        self.manifest = manifest
        self.update_available.emit(manifest)
        self.new_label.setText(f"PHIÊN BẢN MỚI\nv{manifest['version']}")
        notes = str(manifest.get("release_notes", release.get("body", ""))).strip()
        self.notes.setPlainText(notes or "Bản phát hành không có ghi chú.")
        size_mb = int(manifest["asset_size"]) / (1024 * 1024)
        self.status.setText(
            f"Có phiên bản mới · {size_mb:.1f} MB · {manifest.get('_release_date', '')[:10]}"
        )
        if self._auto_install_after_check:
            self._auto_install_after_check = False
            self.start_update()
        else:
            self.check_btn.setText("Tải & cài đặt bản mới")

    def start_update(self):
        if not self.manifest or (self._download_thread and self._download_thread.is_alive()):
            return
        self.check_btn.setEnabled(False)
        self.later_btn.setEnabled(False)
        self.cancel_btn.setVisible(True)
        self.cancel_btn.setEnabled(True)
        self.progress.setVisible(True)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress_label.setText("Đang kết nối máy chủ tải gói cập nhật…")
        self.status.setText(f"Đang tải và xác minh bản v{self.manifest['version']}…")

        stage = Path(tempfile.mkdtemp(prefix="gocreview-update-"))
        self._cancel_event.clear()

        def worker():
            try:
                result = download_update(
                    self.manifest,
                    self.public_key_path,
                    stage,
                    progress=lambda done, total: self.signals.progress.emit(done, total),
                    cancel_event=self._cancel_event,
                )
                self.signals.downloaded.emit({"ok": True, "stage": str(stage), "verified": str(result)})
            except Exception as exc:
                self.signals.downloaded.emit({
                    "ok": False,
                    "error": str(exc),
                    "stage": str(stage),
                    "cancelled": self._cancel_event.is_set(),
                })

        self._download_thread = threading.Thread(target=worker, name="UpdaterDownload", daemon=True)
        self._download_thread.start()

    def _on_progress(self, done: int, total: int):
        pct = int(done * 100 / total) if total else 0
        self.progress.setValue(max(0, min(100, pct)))
        self.progress_label.setText(f"{done / 1048576:.1f} / {total / 1048576:.1f} MB")

    def _on_downloaded(self, response):
        # The worker is done producing results; allow a clean retry after cancellation/error.
        self._download_thread = None
        self.cancel_btn.setVisible(False)
        self.cancel_btn.setEnabled(True)
        if not response.get("ok"):
            shutil.rmtree(response.get("stage", ""), ignore_errors=True)
            if response.get("cancelled"):
                self.status.setText("Đã hủy tải cập nhật. Ứng dụng chưa bị thay đổi.")
            else:
                self.status.setText("Tải hoặc xác minh thất bại. Chưa file ứng dụng nào bị thay đổi.")
                self.notes.append("\n\nLỗi: " + response.get("error", "Không rõ lỗi."))
                # A failed attempt may follow a release-feed hotfix. Drop the cached
                # manifest so the retry button fetches the current manifest and hash.
                self.manifest = None
            self.check_btn.setEnabled(True)
            self.check_btn.setText("Thử lại cập nhật")
            self.later_btn.setEnabled(True)
            return

        self.stage_root = Path(response["stage"])
        self.status.setText("Gói đã được xác minh an toàn. Đang chờ tác vụ hiện tại hoàn tất…")
        self.progress.setValue(100)
        self.progress_label.setText("SHA-256 và chữ ký hợp lệ · Chưa thay đổi file ứng dụng")
        self.notes.append(
            "\n\nGói đã xác minh. Video Studio sẽ tự áp dụng khi Engine, CTA Detector và các tác vụ khác rảnh."
        )
        self.accept()  # MainWindow takes ownership of the verified staging folder.

    def _cancel_download(self):
        self._cancel_event.set()
        self.cancel_btn.setEnabled(False)
        self.status.setText("Đang hủy tải… file ứng dụng hiện tại vẫn an toàn.")

    def closeEvent(self, event: QCloseEvent):
        if self._download_thread and self._download_thread.is_alive():
            event.ignore()
            self.status.setText("Đang tải cập nhật. Hãy chờ hoặc bấm Hủy tải trước khi đóng cửa sổ.")
            return
        event.accept()
