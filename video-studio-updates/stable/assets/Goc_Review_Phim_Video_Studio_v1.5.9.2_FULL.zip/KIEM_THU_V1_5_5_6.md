# Kiểm thử v1.5.5.6 — Auto Update Bootstrap + OCR Fix

## Kết quả tự động

- `python -m py_compile *.py updater/*.py tools/*.py tests/*.py`: PASS.
- `python -m pytest -q`: **82 passed, 21 subtests passed**.
- HTTPS-SHA256 manifest không cần private signing key: PASS.
- Manifest unsigned nhưng thiếu `trust_mode=https-sha256-v1`: bị từ chối: PASS.
- Apply helper với manifest HTTPS-SHA256 và transaction backup: PASS.
- Hỗ trợ ngược manifest Ed25519 cũ: PASS.
- ZIP payload: giữ kiểm tra file allowlist, đường dẫn an toàn, kích thước và SHA-256 từng file: PASS.

## Giới hạn kiểm thử

- Chưa nghiệm thu Qt GUI, Tesseract OCR và process handoff trực tiếp trên Windows 10/11 của người dùng trong môi trường build này.
- Bootstrap patch có kiểm tra đúng base version v1.5.5.4, hash payload, sao lưu file cũ và tự rollback nếu Python compile thất bại.
- Cần người dùng áp dụng bootstrap một lần trên máy Windows; sau đó các bản Stable mới dùng nút **Kiểm tra & cập nhật** trong ứng dụng.
