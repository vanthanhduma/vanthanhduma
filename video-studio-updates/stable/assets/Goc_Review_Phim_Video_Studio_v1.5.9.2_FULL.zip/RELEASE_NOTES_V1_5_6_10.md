# Góc Review Phim Video Studio v1.5.6.10

## Hiển thị thời gian linh hoạt

- Giá trị dưới 60 giây hiển thị bằng `giây`; giá trị từ 60 giây trở lên tự hiển thị bằng `phút`.
- Áp dụng cho vị trí timeline, phân cảnh, CTA, lớp phủ, Before/After và các khoảng xuất.
- Mật độ quét ảnh, chế độ lấy mẫu, thời lượng xem thử và tốc độ xử lý vẫn dùng `giây`/`MB/s` vì đó là thông số thao tác, không phải vị trí video.
- Engine vẫn giữ giây nội bộ để không ảnh hưởng độ chính xác xử lý.
