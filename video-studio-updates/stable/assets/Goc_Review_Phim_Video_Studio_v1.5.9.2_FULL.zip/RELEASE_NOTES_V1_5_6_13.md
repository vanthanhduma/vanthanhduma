# Góc Review Phim Video Studio v1.5.6.13

## CTA Subscribe

- Sửa cách chọn font để chữ tiếng Việt trong bảng kết quả, tiêu đề và thumbnail không bị lỗi khi máy không có Segoe UI hoặc Qt thay font.
- Giữ cỡ chữ và độ đậm riêng cho bảng CTA, tiêu đề cột và phần mô tả thumbnail để dễ đọc hơn.
- Xác minh lại nút `Cắt đã chọn`: giữ đúng các khoảng đã đánh dấu và tạo video mới với thời lượng bị trừ chính xác.

