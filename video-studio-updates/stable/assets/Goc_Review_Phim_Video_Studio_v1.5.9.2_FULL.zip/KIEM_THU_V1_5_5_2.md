# Kiểm thử lưu trữ v1.5.5.2 FULL — Public One-Click Updater + Reliable Restart

## Kết quả kiểm thử trong môi trường dựng

- `python -m py_compile *.py updater/*.py tools/*.py tests/*.py`: PASS.
- `python -m pytest -q`: **66 passed, 21 subtests passed**.
- ZIP integrity (`ZipFile.testzip()`): PASS.
- Internal FULL manifest: số lượng file, kích thước và SHA-256 từng file: PASS.
- Public Stable manifest/signature: xác minh Ed25519 bằng public key nhúng: PASS.
- Public incremental ZIP v1.5.5.2: SHA-256, dung lượng và ZIP integrity: PASS.
- ZIP FULL có file ứng dụng trực tiếp ở cấp gốc, không lồng thêm thư mục ứng dụng: PASS.
- PID handoff tests trong môi trường dựng (process đã thoát và process timeout): PASS.
- Launcher Python compile, cơ chế ghi log vào LocalAppData và kiểm tra process khởi động sớm: PASS (static/compile; chưa chạy Windows native).

## Cải thiện restart

- Trên Windows, helper dùng `OpenProcess(SYNCHRONIZE)` + `WaitForSingleObject` để chờ đúng process GUI, thay cho kiểm tra PID bằng `os.kill(pid, 0)`.
- Helper chỉ khởi chạy lại sau khi transaction hoàn tất và staging được dọn.
- `launcher.py` ghi log khởi động, chạy GUI qua Python không tạo console và phát hiện process thoát ngay lúc khởi động.
- `MO_GOC_REVIEW_PHIM.vbs` gọi launcher và chỉ ra vị trí log nếu launcher trả lỗi.
- Nhật ký lưu tại `%LOCALAPPDATA%\GocReviewVideoStudio\updater\apply-helper.log` và `%LOCALAPPDATA%\GocReviewVideoStudio\logs\launcher.log`.

## Giới hạn nghiệm thu

- Môi trường dựng không có Windows native runtime/PySide6 GUI, vì vậy chưa tuyên bố đã chạy thử process handoff hoặc giao diện Qt thật trên Windows.
- Cần cài FULL vào thư mục mới và xác nhận mở app trên Windows 10/11 trước khi xóa bản cũ.
- Tesseract OCR là dependency hệ thống riêng; chạy `CAI_TESSERACT_OCR.bat` nếu máy chưa cài.
