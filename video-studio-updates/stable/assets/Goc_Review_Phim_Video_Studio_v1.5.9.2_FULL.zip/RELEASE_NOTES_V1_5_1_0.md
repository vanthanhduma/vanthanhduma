# Release Notes — v1.5.1.0 Workspace Refinement

## Tổ chức workflow
- Tách trang **Biên tập & Phân cảnh** khỏi trang **Mask & Before/After**; hai mục điều hướng không còn trỏ vào cùng một panel công cụ.
- Bỏ mục CTA Detector riêng trên sidebar. CTA Detector trở thành tab **CTA · Duyệt khoảng** ngay cạnh tab **Phân cảnh** trong vùng timeline của workspace Biên tập.
- CTA vẫn là bộ phát hiện độc lập: chỉ quét hình ảnh/animation, hiển thị ứng viên, thumbnail, thời gian và độ tin cậy; người dùng chọn thủ công khoảng cần cắt. Không tự động cắt ứng viên.

## So sánh Before/After
- Bỏ hai thumbnail nhỏ trong panel Mask.
- Kết quả so sánh mở trong vùng preview trung tâm, với hai ảnh gốc/kết quả Inpaint song song và tự co giãn theo kích thước vùng xem.
- Ảnh so sánh tạm cũ được dọn khi tạo lần so sánh mới hoặc đóng ứng dụng.

## Sidebar
- Xóa hoàn toàn khu vực **Mẹo nhanh**, không thay bằng nút trợ giúp hay hướng dẫn.
- Dành góc trái dưới cho trạng thái hệ thống: Engine, Auto Save và mức ưu tiên tác vụ nền.

## Tương thích và bảo toàn
- Giữ nguyên engine xử lý, detector CTA, downloader, project schema, quy trình lưu/mở dự án, batch, branding, xuất video và QC.
- Không thay đổi thư viện, `.venv`, assets, dự án, autosave, video nguồn hay output khi áp dụng UPDATE.
- UPDATE hỗ trợ nâng trực tiếp từ v1.5.0.0 và tự tạo backup source cũ trước khi thay thế.
