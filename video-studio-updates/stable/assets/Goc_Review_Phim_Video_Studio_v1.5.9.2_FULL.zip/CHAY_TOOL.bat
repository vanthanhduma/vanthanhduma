@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "WSCRIPT=%SystemRoot%\System32\wscript.exe"
if not exist "%ROOT%\MO_GOC_REVIEW_PHIM.vbs" (
  echo Khong tim thay MO_GOC_REVIEW_PHIM.vbs trong: "%ROOT%"
  exit /b 2
)
if not exist "%WSCRIPT%" (
  echo Khong tim thay Windows Script Host: "%WSCRIPT%"
  exit /b 3
)
start "" "%WSCRIPT%" //B //NoLogo "%ROOT%\MO_GOC_REVIEW_PHIM.vbs"
exit /b 0
