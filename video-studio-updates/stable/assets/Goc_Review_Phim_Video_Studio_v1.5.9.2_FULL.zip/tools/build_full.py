from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path


PRESERVED_ROOTS = {
    ".venv", "projects", "downloads", "renders", "logs", "_backups", "autosave",
}
SKIP_ROOTS = {".git", ".pytest_cache", "dist", "__pycache__", "outputs"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def iter_release_files(root: Path, output: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root)
        if path.resolve() == output.resolve():
            continue
        if relative.name == "MANIFEST.json":
            continue
        if any(part in SKIP_ROOTS for part in relative.parts):
            continue
        if relative.parts and relative.parts[0].lower() in PRESERVED_ROOTS:
            continue
        if path.suffix.lower() in {".pyc", ".pyo"}:
            continue
        yield relative.as_posix(), path


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a clean FULL package without user data.")
    parser.add_argument("--root", required=True, help="Application source root")
    parser.add_argument("--version", required=True)
    parser.add_argument("--base-version", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    root = Path(args.root).resolve(strict=True)
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    version_file = root / "PHIEN_BAN.txt"
    match = re.search(r"v?(\d+\.\d+\.\d+\.\d+)", version_file.read_text(encoding="utf-8", errors="replace"))
    if not match or match.group(1) != str(args.version).lstrip("v"):
        raise SystemExit("PHIEN_BAN.txt version must exactly match --version")

    files = list(iter_release_files(root, output))
    entries = []
    sizes = {}
    hashes = {}
    for relative, path in files:
        size = path.stat().st_size
        digest = sha256_file(path)
        entries.append(relative)
        sizes[relative] = size
        hashes[relative] = digest

    manifest = {
        "product": "Goc Review Phim Video Studio",
        "version": str(args.version).lstrip("v"),
        "base_version": str(args.base_version).lstrip("v"),
        "package_type": "FULL",
        "release_name": "Verified FULL installer",
        "created_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "files": entries,
        "sizes": sizes,
        "sha256": hashes,
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    archive_path = output / f"Goc_Review_Phim_Video_Studio_v{args.version}_FULL.zip"
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for relative, path in files:
            archive.write(path, relative)
        archive.writestr("MANIFEST.json", manifest_bytes)

    package_sha256 = sha256_file(archive_path)
    manifest["archive_size"] = archive_path.stat().st_size
    manifest["archive_sha256"] = package_sha256
    manifest_path = output / f"Goc_Review_Phim_Video_Studio_v{args.version}_FULL_MANIFEST.json"
    manifest_path.write_bytes((json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(f"Package: {archive_path}")
    print(f"Manifest: {manifest_path}")
    print(f"SHA-256: {package_sha256}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
