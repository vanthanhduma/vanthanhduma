# Phát hành Stable — In-App Auto Update

## Cách hoạt động

- Client chỉ đọc `video-studio-updates/stable/latest.json` từ raw.githubusercontent.com qua HTTPS.
- Manifest dùng `trust_mode: https-sha256-v1`, khai báo SHA-256 và dung lượng của ZIP, cùng SHA-256/dung lượng của từng file.
- Client giới hạn manifest/asset vào đúng repository và đường dẫn Stable đã cấu hình; không cần tài khoản GitHub, PAT hoặc Secret trên máy người dùng.
- Khi người dùng bấm **Kiểm tra & cập nhật**, app tự kiểm tra, tải, xác minh, chờ tác vụ rảnh, sao lưu, áp dụng, health-check và khởi động lại.

## Build gói UPDATE

```powershell
python tools/build_update.py `
  --root . `
  --version 1.5.6.0 `
  --base-version 1.5.5.6 `
  --notes RELEASE_NOTES_V1_5_6_0.md `
  --output dist\v1.5.6.0 `
  --files qt_app.py app.py PHIEN_BAN.txt launcher.py MO_GOC_REVIEW_PHIM.vbs TAO_LOI_TAT_DESKTOP.vbs CHAY_TOOL.bat updater/core.py updater/qt_ui.py updater/apply_helper.py
```

Không đưa `.venv`, projects, autosave, settings, Branding pessoal, downloads, renders, video hoặc output vào payload.

## Build gói FULL

Tạo một gói cài sạch, tự sinh `MANIFEST.json`, và loại trừ dữ liệu người dùng:

```powershell
python tools/build_full.py `
  --root . `
  --version 1.5.5.7 `
  --base-version 1.5.5.6 `
  --output dist\v1.5.5.7
```

Script bắt buộc `PHIEN_BAN.txt` phải khớp version và không đưa `.venv`, `projects`, `downloads`, `renders`, `logs`, `autosave`, `_backups` hoặc file tạm vào ZIP.

## Publish

Đưa ZIP vào `video-studio-updates/stable/assets/` và commit cập nhật `latest.json` cùng commit. Manifest tối thiểu cần có: `schema_version`, `app_id`, `channel`, `trust_mode`, `package_type`, `version`, `base_version`, `asset_name`, `asset_url`, `asset_size`, `asset_sha256`, `release_notes`, và `files[]` chứa path/size/sha256. Asset URL phải đúng `PUBLIC_ASSET_ROOT + asset_name`. Kênh `https-sha256-v1` dùng HTTPS cố định + SHA-256; kênh Ed25519 cũ chỉ giữ để tương thích manifest v1.5.5.2.

## An toàn

- HTTPS/TLS bắt buộc; redirect phải ở `raw.githubusercontent.com`.
- ZIP hash + size và từng file hash + size đều được xác minh.
- Chỉ cho phép file path tương đối trong manifest; chặn path traversal, file trùng, symlink và dữ liệu người dùng.
- Helper sao lưu, ghi transaction journal, health-check và rollback nếu lỗi.
- Không thay `.venv`, projects, autosave, settings, Branding cá nhân, downloads, renders, video nguồn hoặc output.
