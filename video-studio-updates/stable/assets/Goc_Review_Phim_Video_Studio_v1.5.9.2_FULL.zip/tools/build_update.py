from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import zipfile
from pathlib import Path

from cryptography.hazmat.primitives import serialization


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Build signed GitHub Release update assets.")
    parser.add_argument("--root", required=True, help="Application source root")
    parser.add_argument("--version", required=True)
    parser.add_argument("--base-version", required=True)
    parser.add_argument("--supported-base-versions", nargs="+", default=None, help="Exact installed versions allowed to use this incremental package")
    parser.add_argument("--notes", required=True, help="UTF-8 markdown release notes")
    parser.add_argument("--private-key", help="Optional Ed25519 private PEM for legacy signed feeds")
    parser.add_argument("--trust-mode", choices=("https-sha256-v1", "ed25519-v1"), default="https-sha256-v1")
    parser.add_argument("--output", required=True)
    parser.add_argument("--files", nargs="+", required=True, help="Changed app-relative file paths")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if not any(str(raw).replace("\\", "/").casefold() == "phien_ban.txt" for raw in args.files):
        raise SystemExit("PHIEN_BAN.txt must be included so the installed version can be verified after restart")
    version_text = (root / "PHIEN_BAN.txt").read_text(encoding="utf-8", errors="replace")
    match = re.search(r"v?(\d+\.\d+\.\d+\.\d+)", version_text)
    if not match or match.group(1) != str(args.version).lstrip("v"):
        raise SystemExit("PHIEN_BAN.txt version must exactly match --version")
    package_name = f"Goc_Review_Phim_Video_Studio_v{args.version}_UPDATE.zip"
    archive_path = out / package_name
    entries = []
    seen = set()
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for raw in args.files:
            rel = Path(raw)
            if rel.is_absolute() or ".." in rel.parts or "\\" in raw:
                raise SystemExit(f"Unsafe relative path: {raw}")
            src = root / rel
            if not src.is_file() or src.is_symlink():
                raise SystemExit(f"Missing/unsafe source file: {src}")
            rel_posix = rel.as_posix()
            if rel_posix.casefold() in seen:
                raise SystemExit(f"Duplicate file path: {rel_posix}")
            seen.add(rel_posix.casefold())
            protected = {"user_settings.json", "autosave"}
            if rel_posix.casefold() in protected or rel_posix.startswith((".venv/", "projects/", "downloads/", "renders/", "logs/", "autosave/", "assets/user/", "_backups/")):
                raise SystemExit(f"Refusing to package preserved user data: {rel_posix}")
            zf.write(src, f"payload/{rel_posix}")
            entries.append({"path": rel_posix, "size": src.stat().st_size, "sha256": sha256(src), "action": "replace"})

    manifest = {
        "schema_version": 1,
        "app_id": "goc-review-phim-video-studio",
        "channel": "stable",
        "trust_mode": args.trust_mode,
        "package_type": "UPDATE",
        "version": args.version,
        "base_version": args.base_version,
        "minimum_supported_version": args.base_version,
        "supported_base_versions": args.supported_base_versions or [args.base_version],
        "asset_name": package_name,
        "asset_url": "https://raw.githubusercontent.com/vanthanhduma/vanthanhduma/main/video-studio-updates/stable/assets/" + package_name,
        "asset_size": archive_path.stat().st_size,
        "asset_sha256": sha256(archive_path),
        "release_notes": Path(args.notes).read_text(encoding="utf-8"),
        "files": entries,
    }
    manifest_bytes = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    (out / "update-manifest.json").write_bytes(manifest_bytes)
    signature_path = out / "update-manifest.sig"
    if args.trust_mode == "ed25519-v1":
        if not args.private_key:
            raise SystemExit("--private-key is required for ed25519-v1")
        private = serialization.load_pem_private_key(Path(args.private_key).read_bytes(), password=None)
        signature = private.sign(manifest_bytes)
        signature_path.write_text(base64.b64encode(signature).decode("ascii") + "\n", encoding="ascii")
        print(f"Signature: {signature_path}")
    else:
        signature_path.unlink(missing_ok=True)
        print("Trust mode: HTTPS + SHA-256 (no private key required)")
    print(f"Package: {archive_path}")
    print(f"Manifest: {out / 'update-manifest.json'}")
    print(f"SHA-256: {manifest['asset_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
