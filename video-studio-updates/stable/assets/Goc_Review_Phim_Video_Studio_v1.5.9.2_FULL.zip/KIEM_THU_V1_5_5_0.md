# Kiểm thử — Góc Review Phim Video Studio v1.5.5.0

## Source checks

- Full suite: **63 passed, 21 subtests passed**.
- `python -m py_compile *.py updater/*.py tools/*.py tests/*.py`: PASS.
- Gói nguồn gốc v1.5.4.0: ZIP CRC PASS; SHA-256 khớp checksum đã lưu.

## Updater logic tests

- Semantic version comparison.
- Manifest schema/app-id/version validation.
- Rejection of traversal, absolute paths and all protected user-data paths.
- Duplicate file path rejection.
- Ed25519 valid signature accepted; tampered bytes rejected.
- ZIP valid payload accepted; path traversal, unlisted files and hash mismatch rejected.

## Integration scope

- UI adds one update action in the main header and a single in-app update dialog.
- Private repository authentication uses a Fine-grained GitHub token with read-only repository contents permission, stored through keyring/Windows Credential Manager.
- Download, signature/hash verification, stage extraction, idle-job gate, helper process, backup and rollback are implemented.
- Incremental package builder and one-time bootstrap installer are included.

## Limitations / required acceptance

- Build container has no PySide6; Qt GUI, native Windows process handoff, Credential Manager backend, Windows DPI and actual release-asset download were **not** run here.
- No GitHub Release assets have been published by this build. The app's updater needs a published Stable release with the three documented assets.
- Initial v1.5.4.0 installation cannot self-update because that version has no updater; apply the Bootstrap Update once, then later versions update from inside the app.
- Real Windows 10/11 acceptance is required before considering the updater production-ready.
