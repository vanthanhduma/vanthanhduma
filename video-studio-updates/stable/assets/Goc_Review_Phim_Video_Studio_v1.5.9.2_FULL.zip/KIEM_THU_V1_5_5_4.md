# Kiểm thử v1.5.5.4 — One-Click Update + Launcher + Project Logo Fallback

## Các sửa đổi

- Nút **Kiểm tra & cập nhật** tự động bắt đầu download sau khi xác nhận có Stable mới; không có nút bấm thứ hai hay hộp thoại xác nhận lần hai.
- Gói chỉ được áp dụng sau khi kiểm tra chữ ký/hash, staging, chờ tác vụ ứng dụng rảnh, sao lưu và health-check; giữ nguyên rollback khi health-check thất bại.
- Launcher ưu tiên `pythonw.exe`; shortcut Desktop gọi `wscript.exe` ở chế độ ẩn. `CHAY_TOOL.bat` không giữ console mở.
- Bộ cài làm mới shortcut Desktop sau khi cài dependency.
- Project thiếu logo riêng dùng logo mặc định; ghi chú được chuyển vào thanh trạng thái, không bật warning modal riêng cho logo.

## Kiểm thử nguồn

- `python -m pytest -q`: **75 passed, 21 subtests passed**.
- `python -m py_compile *.py updater/*.py tools/*.py tests/*.py`: **PASS**.
- Launcher regression: ưu tiên `pythonw.exe`, fallback `python.exe` khi cần: **PASS**.
- Shortcut/launcher static regression: gọi `wscript.exe` ẩn, không để batch giữ Terminal: **PASS**.
- One-click updater regression: manual check chuyển thẳng sang tải/cài; không còn hộp xác nhận lần hai: **PASS**.
- Update idle gate: chuyển từ `QThread.is_alive()` không hợp lệ sang `QThread.isRunning()`: **PASS**.
- Project logo fallback: không còn modal warning riêng, trạng thái được ghi trên status bar: **PASS**.
- FULL ZIP: CRC PASS; manifest gồm 71 file, mọi kích thước và SHA-256 khớp nội dung ZIP: PASS; loại trừ `.venv`, project, Auto Save và dữ liệu người dùng: PASS.

## Giới hạn nghiệm thu

- Môi trường build không có PySide6 và Windows Script Host, vì vậy chưa thể mở Qt GUI native, tạo `.lnk` thật hoặc chạy cập nhật/restart trên Windows tại đây. Cần nghiệm thu GUI/DPI và shortcut trên Windows 10/11 sau khi cài gói.
- Máy chủ Stable hiện vẫn công bố v1.5.5.2; chưa có bản UPDATE mới hơn để chạy end-to-end qua mạng. Private signing key không nằm trong FULL ZIP, vì vậy không thể tự ký hoặc publish gói Stable mới từ file này. Xác minh chữ ký hiện có được giữ nguyên, không hạ thấp bảo mật.
