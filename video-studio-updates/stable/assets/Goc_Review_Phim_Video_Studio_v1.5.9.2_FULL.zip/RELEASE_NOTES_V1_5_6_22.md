# Góc Review Phim Video Studio v1.5.6.22

## Cắt video và xem nguồn

- Thêm nút **Phát video gốc Từ–Đến** ngay trong vùng Xuất & kiểm tra.
- Cho phép nhập mốc bắt đầu/kết thúc, xem trực tiếp đoạn nguồn rồi xuất đúng khoảng đã chọn.
- Không cần tạo phân cảnh trung gian; dữ liệu phân cảnh cũ vẫn được giữ để mở dự án cũ an toàn.

## CTA Subscribe

- Xem đoạn CTA đã chọn bằng bộ đọc video liên tục, tránh mở lại tiến trình xử lý cho từng khung hình.
- Giữ cập nhật thumbnail và trạng thái phát trong lúc xem; dừng/xem lại không làm treo giao diện.

## Giao diện

- Ẩn các nút Thêm cảnh, Tách cảnh và Xóa cảnh khỏi workspace vì không còn cần cho quy trình cắt Từ–Đến.
- Giữ nguyên các chức năng dự án, xuất video, xử lý hàng loạt, Mask/Before–After và updater.
