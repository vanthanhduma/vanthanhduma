Option Explicit
Dim fso, sh, root, pythonw, script, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
pythonw = root & "\.venv\Scripts\pythonw.exe"
script = root & "\app.py"
If Not fso.FileExists(pythonw) Or Not fso.FileExists(script) Then
    MsgBox "Khong tim thay Python environment hoac app.py. Hay chay CAI_DAT_VA_CHAY.bat.", vbCritical, "Goc Review Phim"
    WScript.Quit 1
End If
sh.CurrentDirectory = root
cmd = Chr(34) & pythonw & Chr(34) & " " & Chr(34) & script & Chr(34)
sh.Run cmd, 0, False
