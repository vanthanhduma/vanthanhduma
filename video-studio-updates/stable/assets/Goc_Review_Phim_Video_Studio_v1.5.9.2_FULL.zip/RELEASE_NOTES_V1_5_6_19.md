# Góc Review Phim Video Studio v1.5.6.19

## CTA Subscribe

- Sửa vùng thumbnail để không bị caption đè lên trên màn hình DPI cao.
- Thu gọn mô tả trong panel còn 3 dòng; nội dung đầy đủ vẫn xem được bằng tooltip.
- Cố định cột mô tả theo phần còn lại của bảng để các cột Khoảng, Dài, Tin cậy và Vị trí không bị cắt.
- Điều chỉnh cỡ chữ CTA về mức dễ đọc, giữ nguyên font tiếng Việt và các chức năng quét/xem/cắt.

