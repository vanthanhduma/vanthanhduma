# Góc Review Phim Video Studio v1.5.6.9

## Hiển thị thời gian thống nhất

- Đồng bộ mốc thời gian trên timeline, phân cảnh, CTA, lớp phủ, Before/After và xuất đoạn về đơn vị `phút`.
- Các trường CTA `Bắt đầu` và `Kết thúc` giờ nhập phút; engine vẫn đổi nội bộ sang giây để giữ độ chính xác xử lý.
- Đổi các nhãn thời lượng, xác nhận cắt CTA, xem thử và cảnh báo liên quan sang phút, không còn trộn `s` với `phút` trong giao diện.
- Giữ nguyên tốc độ mạng `MB/s` vì đây là đơn vị tốc độ, không phải mốc thời gian video.

## Tương thích

- Không thay đổi định dạng dự án, dữ liệu người dùng, virtualenv hoặc pipeline xuất.
- Feed hỗ trợ nâng cấp từ các bản 1.5.5.7 trở lên và vẫn xác minh SHA-256 trước khi cài.
