# Kiểm thử v1.5.5.5 — Tesseract OCR Model Loading Fix

## Phạm vi
- Preflight khởi tạo thật hai model `eng` + `vie` trước khi quét CTA.
- Fallback copy model sang user-local cache khi app-local path không nạp được.
- SHA-256 kiểm tra file cache sau sao chép.
- Đường dẫn tessdata dùng forward slash trong cấu hình của pytesseract để tương thích Windows.
- Phân loại TesseractError riêng với timeout thật.
- Bảo toàn luồng CTA: quét 2 lượt, Pause/Resume, gom khoảng và duyệt thủ công.

## Kết quả trong môi trường build
- `python -m py_compile` trên toàn bộ file Python: PASS.
- `python -m pytest -q`: 79 passed, 21 subtests passed.
- Tesseract 5.5.0 thực tế khởi tạo cả `eng` và `vie` từ model đóng gói: PASS.
- OCR synthetic tiếng Việt/Anh: PASS.
- Mô phỏng app-folder access failure và copy model sang cache, kiểm tra SHA-256: PASS.
- Kiểm tra ZIP CRC, danh sách file, kích thước và SHA-256 sau đóng gói: PASS.

## Giới hạn nghiệm thu
Môi trường build là Linux, không có máy Windows của người dùng hoặc ổ E: của người dùng. Bản vá đã kiểm thử engine Tesseract thật và mô phỏng fallback; cần xác nhận cuối cùng trên Windows sau khi chạy gói PATCH.
