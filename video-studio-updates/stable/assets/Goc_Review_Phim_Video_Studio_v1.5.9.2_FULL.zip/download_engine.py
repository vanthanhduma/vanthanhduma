from __future__ import annotations

"""Local Facebook/YouTube downloader adapter built on yt-dlp.

The module deliberately supports only well-known Facebook and YouTube URL
families in the UI. It does not unlock private/member-only content or bypass
site access controls. Cookies, when selected, are read from the chosen local
browser profile and are never uploaded by this application.
"""

import json
import os
import shutil
import threading
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from typing import Callable


class DownloadCancelled(Exception):
    """Raised when the user stops the current download."""


_ALLOWED_HOSTS = {
    "facebook.com", "www.facebook.com", "m.facebook.com", "fb.watch",
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com",
}


def validate_video_url(url: str) -> str:
    value = (url or "").strip()
    if not value:
        raise ValueError("Bạn chưa dán liên kết video.")
    if len(value) > 4096:
        raise ValueError("Liên kết quá dài.")
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Link phải bắt đầu bằng http:// hoặc https://.")
    host = parsed.hostname.lower().rstrip(".")
    if host not in _ALLOWED_HOSTS:
        raise ValueError("Hiện chỉ hỗ trợ link Facebook và YouTube.")
    if host in {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com"}:
        is_watch = parsed.path.rstrip("/") == "/watch" and bool(parse_qs(parsed.query).get("v"))
        is_id_path = parsed.path.startswith(("/shorts/", "/live/", "/embed/")) and len(parsed.path.strip("/").split("/")) >= 2
        if not (is_watch or is_id_path):
            raise ValueError("Hãy dùng link video YouTube cụ thể (watch, Shorts hoặc Live), không dùng link kênh/danh sách phát.")
    elif host == "youtu.be":
        path_parts = [part for part in parsed.path.strip("/").split("/") if part]
        if len(path_parts) != 1:
            raise ValueError("Link youtu.be chưa hợp lệ.")
    if host in {"facebook.com", "www.facebook.com", "m.facebook.com"}:
        if not any(x in parsed.path for x in ("/reel/", "/watch", "/videos/", "/share/")):
            raise ValueError("Link Facebook chưa giống một liên kết video/Reels hợp lệ.")
    if host == "fb.watch" and not parsed.path.strip("/"):
        raise ValueError("Link fb.watch chưa có mã video.")
    return value


def detect_platform(url: str) -> str:
    host = (urlparse(url).hostname or "").lower()
    return "YouTube" if (host == "youtu.be" or host.endswith("youtube.com") or host.endswith("youtube-nocookie.com")) else "Facebook"


def _format_selector(max_height: int | None, prefer_mp4: bool, has_ffmpeg: bool) -> str:
    limit = f"[height<={max_height}]" if max_height else ""
    if prefer_mp4 and not has_ffmpeg:
        return f"best[ext=mp4]{limit}/best{limit}"
    if prefer_mp4:
        # Prefer MP4/H.264 + M4A when offered, then fall back to the best
        # compatible streams instead of silently reducing the requested height.
        return (
            f"bestvideo[ext=mp4]{limit}+bestaudio[ext=m4a]/"
            f"best[ext=mp4]{limit}/bestvideo*{limit}+bestaudio/best{limit}"
        )
    if not has_ffmpeg:
        return f"best{limit}"
    if max_height:
        return f"bestvideo*{limit}+bestaudio/best{limit}"
    return "bestvideo*+bestaudio/best"


def _resolve_ffmpeg() -> str | None:
    # Respect the FFmpeg path already selected in Video Studio settings.
    settings_path = Path(__file__).resolve().parent / "user_settings.json"
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        configured = str(settings.get("ffmpeg_path", "")).strip() if isinstance(settings, dict) else ""
        if configured and Path(configured).is_file():
            return configured
    except Exception:
        pass
    system_path = shutil.which("ffmpeg")
    if system_path:
        return system_path
    try:
        import imageio_ffmpeg
        bundled = imageio_ffmpeg.get_ffmpeg_exe()
        return bundled if bundled and Path(bundled).is_file() else None
    except Exception:
        return None


def download_video(
    url: str,
    output_dir: str | Path,
    *,
    browser: str | None = None,
    max_height: int | None = None,
    prefer_mp4: bool = False,
    cancel_event: threading.Event | None = None,
    progress_callback: Callable[[dict], None] | None = None,
) -> dict:
    """Download one authorized/publicly accessible video and return its metadata."""
    url = validate_video_url(url)
    if max_height not in {None, 720, 1080}:
        raise ValueError("Mức phân giải không được hỗ trợ.")
    if browser not in {None, "chrome", "edge", "firefox"}:
        raise ValueError("Trình duyệt cookie không được hỗ trợ.")

    try:
        import yt_dlp
    except ImportError as exc:
        raise RuntimeError("Thiếu yt-dlp. Hãy chạy CAP_NHAT_THU_VIEN.bat để cài engine tải.") from exc

    destination = Path(output_dir).expanduser().resolve()
    destination.mkdir(parents=True, exist_ok=True)
    ffmpeg = _resolve_ffmpeg()
    has_ffmpeg = bool(ffmpeg)

    options: dict = {
        "format": _format_selector(max_height, prefer_mp4, has_ffmpeg),
        "outtmpl": str(destination / "%(title).160B [%(id)s].%(ext)s"),
        "noplaylist": True,
        "windowsfilenames": True,
        "continuedl": True,
        "overwrites": False,
        "retries": 5,
        "fragment_retries": 5,
        "file_access_retries": 3,
        "concurrent_fragment_downloads": 4,
        "socket_timeout": 30,
        "quiet": True,
        "no_warnings": True,
        "progress_hooks": [],
    }
    if browser:
        options["cookiesfrombrowser"] = (browser, None, None, None)
    if ffmpeg:
        options["ffmpeg_location"] = str(ffmpeg)

    def hook(data: dict):
        if cancel_event is not None and cancel_event.is_set():
            raise DownloadCancelled("Người dùng đã yêu cầu dừng tải.")
        status = str(data.get("status", "downloading"))
        if progress_callback:
            if status == "downloading":
                total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
                downloaded = data.get("downloaded_bytes") or 0
                percent = int(downloaded * 100 / total) if total else 0
                progress_callback({"status": status, "percent": percent, "speed": data.get("speed"), "eta": data.get("eta")})
            elif status == "finished":
                progress_callback({"status": status, "percent": 100, "speed": 0, "eta": 0})

    options["progress_hooks"] = [hook]
    if cancel_event is not None and cancel_event.is_set():
        raise DownloadCancelled("Người dùng đã yêu cầu dừng tải.")

    with yt_dlp.YoutubeDL(options) as ydl:
        info = ydl.extract_info(url, download=True)
    if cancel_event is not None and cancel_event.is_set():
        raise DownloadCancelled("Người dùng đã yêu cầu dừng tải.")
    if not isinstance(info, dict):
        raise RuntimeError("Nguồn không trả về thông tin video hợp lệ.")
    return {
        "id": str(info.get("id") or ""),
        "title": str(info.get("title") or "Video"),
        "duration": info.get("duration"),
        "height": info.get("height"),
        "ext": str(info.get("ext") or ""),
        "platform": detect_platform(url),
        "output_dir": str(destination),
    }
