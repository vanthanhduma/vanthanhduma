# v1.5.6.37 – CTA OCR Recall Improvement

## Cải thiện nhận diện CTA
- Bật OCR dự phòng PSM 11 ngay trong lượt quét thông thường khi PSM 6 không tìm thấy từ khóa.
- OCR dự phòng đọc lại ảnh tăng tương phản và ảnh nhị phân Otsu; chế độ thorough bổ sung ngưỡng thích nghi.
- Ghép các mảnh chữ liền kề do OCR tách như `SUB SCRIBE`, `SH ARE`, `L IKE`; xử lý thêm một số nhầm lẫn ký tự thường gặp.
- Tăng độ phân giải xử lý OCR để giữ chi tiết của CTA nhỏ.

## Mật độ quét
- Giữ mặc định 2 giây/ảnh.
- Thêm lựa chọn 0,5 giây/ảnh để tăng mật độ lấy mẫu gấp 4 lần, phù hợp CTA xuất hiện ngắn; thời gian quét sẽ lâu hơn.

## Giữ nguyên nguyên tắc an toàn
- Chỉ dò từ khóa CTA LIKE, SHARE, SUBSCRIBE và cụm tương đương tiếng Việt.
- Không phân loại cảnh phim, không phân tích âm thanh/lời nói.
- Kết quả vẫn cần người dùng xem ảnh bằng chứng và tự chọn khoảng cần cắt; không tự động xóa.
