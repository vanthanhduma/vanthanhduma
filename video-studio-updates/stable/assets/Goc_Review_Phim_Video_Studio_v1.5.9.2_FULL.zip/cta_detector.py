"""Local Subscribe CTA detector.

Detects on-screen Subscribe calls-to-action only (English/Vietnamese text,
button/play-icon graphics, and short visual animations). It does not analyse
audio or speech. Results are review suggestions and must be manually approved
before cutting.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import shutil
import threading
import time
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np


class CTAScanCancelled(Exception):
    """Raised when the user stops a CTA scan."""


_TESSERACT = None
_TESSERACT_PATH = None
_TESSERACT_LANGS: set[str] | None = None
_TESSDATA_DIR: Path | None = None


def _find_tesseract_path() -> str | None:
    """Find the Tesseract executable on Windows and Unix-like systems."""
    configured = os.environ.get("TESSERACT_CMD", "").strip()
    candidates = [configured, shutil.which("tesseract")]
    if os.name == "nt":
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local_app = os.environ.get("LOCALAPPDATA", "")
        candidates.extend([
            str(Path(program_files) / "Tesseract-OCR" / "tesseract.exe"),
            str(Path(program_files_x86) / "Tesseract-OCR" / "tesseract.exe"),
            str(Path(local_app) / "Programs" / "Tesseract-OCR" / "tesseract.exe") if local_app else "",
        ])
    for value in candidates:
        if value and Path(value).is_file():
            return str(Path(value).resolve())
        if value and shutil.which(value):
            return shutil.which(value)
    return None


def _bundled_tessdata_dir() -> Path | None:
    """Return the app-local language-data folder after validating both models."""
    candidate = Path(__file__).resolve().parent / "assets" / "tessdata"
    required = (candidate / "eng.traineddata", candidate / "vie.traineddata")
    if all(item.is_file() and item.stat().st_size > 100_000 for item in required):
        return candidate.resolve()
    return None


def _user_tessdata_dir() -> Path:
    """Stable, user-writable fallback for model files on Windows."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return base / "GocReviewVideoStudio" / "ocr" / "tessdata"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _copy_tessdata_to_user_cache(source: Path) -> Path:
    """Copy bundled models to a writable local path if the app folder is unreadable."""
    target = _user_tessdata_dir()
    target.mkdir(parents=True, exist_ok=True)
    for language in ("eng", "vie"):
        src = source / f"{language}.traineddata"
        dst = target / src.name
        if not src.is_file() or src.stat().st_size <= 100_000:
            raise RuntimeError(f"Thiếu hoặc hỏng model OCR: {src}")
        if dst.is_file() and dst.stat().st_size == src.stat().st_size:
            try:
                if _sha256_file(dst) == _sha256_file(src):
                    continue
            except OSError:
                pass
        temp = dst.with_suffix(dst.suffix + ".tmp")
        shutil.copy2(src, temp)
        if temp.stat().st_size != src.stat().st_size or _sha256_file(temp) != _sha256_file(src):
            temp.unlink(missing_ok=True)
            raise RuntimeError(f"Không thể sao chép đầy đủ model OCR: {src.name}")
        os.replace(temp, dst)
    return target.resolve()


def _configure_tessdata_prefix(directory: Path | None = None) -> Path | None:
    """Set the process to the exact tessdata directory used by this app.

    We always pair this with an explicit --tessdata-dir argument. A stale
    system/user environment variable must never redirect model loading.
    """
    global _TESSDATA_DIR
    selected = directory or _TESSDATA_DIR or _bundled_tessdata_dir()
    if selected is not None:
        selected = selected.resolve()
        os.environ["TESSDATA_PREFIX"] = str(selected)
        _TESSDATA_DIR = selected
    return selected


def _tessdata_config(directory: Path | None = None) -> str:
    # Keep the model directory in TESSDATA_PREFIX and do not also pass a quoted
    # --tessdata-dir argument.  pytesseract uses shlex.split(..., posix=False)
    # on Windows, which preserves the quote characters in the argument token;
    # Tesseract then tries to open `"C:/.../tessdata"/eng.traineddata` and
    # reports that a perfectly valid bundled model is missing.  The environment
    # variable is inherited by the child process, handles spaces in the install
    # path correctly, and is already reset by _configure_tessdata_prefix().
    _configure_tessdata_prefix(directory)
    return ""


def _available_languages(ocr, directory: Path | None = None) -> set[str]:
    try:
        return {str(item).lower() for item in ocr.get_languages(config=_tessdata_config(directory))}
    except Exception as exc:
        prefix = os.environ.get("TESSDATA_PREFIX", "(chưa đặt)")
        raise RuntimeError(
            "Không đọc được danh sách model ngôn ngữ Tesseract. "
            f"TESSDATA_PREFIX={prefix}. Chi tiết: {exc}"
        ) from exc


def _probe_tesseract_models(ocr, directory: Path, languages: set[str]) -> None:
    """Actually initialize the OCR engine before starting a long video scan."""
    if not {"eng", "vie"}.issubset(languages):
        missing = sorted({"eng", "vie"} - languages)
        raise RuntimeError("Thiếu model Tesseract: " + ", ".join(missing))
    # A tiny blank image is enough to force Tesseract to open both traineddata
    # files. Listing languages alone does not prove the native engine can read.
    probe = np.full((64, 320), 255, dtype=np.uint8)
    ocr.image_to_data(
        probe,
        lang="eng+vie",
        config=f"{_tessdata_config(directory)} --oem 1 --psm 6",
        output_type=ocr.Output.DICT,
        timeout=12,
    )


def get_subscribe_ocr_status() -> dict:
    """Return OCR availability after verifying the actual English/Vietnamese engine."""
    global _TESSERACT, _TESSERACT_PATH, _TESSERACT_LANGS, _TESSDATA_DIR
    try:
        import pytesseract
    except Exception as exc:
        return {
            "ready": False,
            "message": "Thiếu thư viện pytesseract. Hãy chạy CAI_DAT_VA_CHAY.bat để cài thư viện.",
            "detail": str(exc),
        }
    path = _find_tesseract_path()
    if not path:
        return {
            "ready": False,
            "message": "Chưa tìm thấy Tesseract OCR. Chạy CAI_TESSERACT_OCR.bat trong thư mục Video Studio rồi mở lại ứng dụng.",
            "install_command": "winget install --id UB-Mannheim.TesseractOCR -e",
        }
    bundled = _bundled_tessdata_dir()
    if bundled is None:
        return {
            "ready": False,
            "message": "Thiếu dữ liệu OCR đi kèm Video Studio.",
            "detail": (
                "Cần có assets/tessdata/eng.traineddata và "
                "assets/tessdata/vie.traineddata trong thư mục ứng dụng. "
                "Hãy giải nén lại gói FULL đầy đủ; không cần tải riêng model OCR."
            ),
        }
    pytesseract.pytesseract.tesseract_cmd = path
    failures: list[str] = []
    candidates = [bundled]
    cache_dir = _user_tessdata_dir()
    if cache_dir.resolve() != bundled.resolve():
        candidates.append(cache_dir)
    version = ""
    try:
        version = str(pytesseract.get_tesseract_version())
    except Exception as exc:
        return {
            "ready": False,
            "message": "Không khởi chạy được Tesseract OCR.",
            "detail": f"Tesseract: {path}\nChi tiết: {exc}",
        }

    for index, candidate in enumerate(candidates):
        try:
            if index == 1:
                candidate = _copy_tessdata_to_user_cache(bundled)
            languages = _available_languages(pytesseract, candidate)
            _probe_tesseract_models(pytesseract, candidate, languages)
            _TESSERACT = pytesseract
            _TESSERACT_PATH = path
            _TESSERACT_LANGS = languages
            _TESSDATA_DIR = candidate.resolve()
            selected = [lang for lang in ("eng", "vie") if lang in languages]
            warning = "" if candidate.resolve() == bundled.resolve() else "Đã chuyển model OCR sang vùng dữ liệu người dùng để tránh lỗi quyền truy cập thư mục ứng dụng."
            return {
                "ready": True, "path": path, "version": version,
                "tessdata_dir": str(candidate), "languages": selected, "warning": warning,
            }
        except Exception as exc:
            failures.append(f"{candidate}: {type(exc).__name__}: {exc}")

    _TESSERACT = None
    _TESSERACT_PATH = None
    _TESSERACT_LANGS = None
    _TESSDATA_DIR = None
    return {
        "ready": False,
        "message": "Tesseract không nạp được model OCR tiếng Anh/Việt.",
        "detail": (
            f"Tesseract: {path}\nPhiên bản: {version}\n" +
            "\n\n".join(failures) +
            "\n\nỨng dụng đã thử dùng model đóng gói và bản sao trong vùng dữ liệu người dùng. "
            "Hãy gửi nội dung này để kiểm tra quyền truy cập hoặc bản cài Tesseract."
        ),
    }

def _get_tesseract():
    global _TESSERACT, _TESSERACT_PATH, _TESSERACT_LANGS
    # Keep the Python wrapper/path cached for every sampled frame. Running
    # `tesseract --version` and `--list-langs` per frame would erase the speed
    # benefit of the sparse single-pass scanner.
    if _TESSERACT is not None and _TESSERACT_PATH and _TESSERACT_LANGS:
        return _TESSERACT
    status = get_subscribe_ocr_status()
    if not status.get("ready"):
        raise RuntimeError(status.get("message", "Tesseract OCR chưa sẵn sàng."))
    if _TESSERACT is None or _TESSERACT_PATH != status.get("path"):
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd = status["path"]
        _TESSERACT, _TESSERACT_PATH = pytesseract, status["path"]
        _TESSERACT_LANGS = set(status.get("languages", ["eng"]))
    return _TESSERACT


def _ocr_language(ocr) -> str:
    global _TESSERACT_LANGS
    if _TESSERACT_LANGS is None:
        _TESSERACT_LANGS = _available_languages(ocr)
    selected = [lang for lang in ("eng", "vie") if lang in _TESSERACT_LANGS]
    return "+".join(selected) if selected else "eng"


def _resize(frame: np.ndarray, max_width: int) -> tuple[np.ndarray, float]:
    height, width = frame.shape[:2]
    scale = min(1.0, max_width / max(1.0, float(width)))
    if scale < 1.0:
        frame = cv2.resize(frame, (max(1, int(round(width * scale))),
                                  max(1, int(round(height * scale)))),
                           interpolation=cv2.INTER_AREA)
    return frame, scale


def _normalise_ocr_text(value: str) -> str:
    """Fold Vietnamese accents and OCR punctuation into searchable text."""
    raw = str(value or "").replace("Đ", "D").replace("đ", "d")
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    text = re.sub(r"[^A-Z0-9]", "", raw.upper())
    # Common OCR confusions in stylised English CTA lettering.
    return text.replace("1", "I")


def _levenshtein_at_most_one(a: str, b: str) -> bool:
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) > len(b):
        a, b = b, a
    i = j = edits = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1
        else:
            edits += 1
            if edits > 1:
                return False
            if len(a) == len(b):
                i += 1; j += 1
            else:
                j += 1
    if j < len(b) or i < len(a):
        edits += 1
    return edits <= 1


def _classify_subscribe_text(value: str) -> dict | None:
    """Match explicit CTA words, including common OCR word-splitting errors.

    We only join adjacent OCR tokens or runs of single-character tokens. We
    never search for CTA strings inside longer words, which avoids treating
    words such as LIKELY, SHAREHOLDER or SUBMARINE as calls to action.
    """
    raw = str(value or "").strip()
    if not raw:
        return None
    folded = raw.upper().replace("Đ", "D")
    folded = unicodedata.normalize("NFKD", folded)
    folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
    tokens = re.findall(r"[A-Z0-9]+", folded)
    if not tokens:
        return None

    # Use the existing OCR normalizer for 1/I, then handle common stylised
    # lettering confusions only when the whole token can become a CTA word.
    confusion_map = str.maketrans({"5": "S", "4": "A", "0": "O"})
    normalized = [_normalise_ocr_text(token).translate(confusion_map) for token in tokens]
    candidates = set(normalized)

    # Tesseract frequently separates a single visual word into two boxes:
    # "SUB SCRIBE", "SH ARE", "L IKE". Consider adjacent pairs as a word.
    candidates.update(
        normalized[index] + normalized[index + 1]
        for index in range(len(normalized) - 1)
    )

    # Some fonts are read one character at a time (e.g. "S U B S C R I B E").
    # Join only short consecutive tokens, and keep the original token list for
    # Vietnamese phrase-context checks below.
    short_run: list[str] = []

    def flush_short_run() -> None:
        if len(short_run) >= 2:
            candidates.add("".join(short_run))
        short_run.clear()

    for token in normalized:
        if len(token) <= 2:
            short_run.append(token)
        else:
            flush_short_run()
    flush_short_run()

    matched: set[str] = set()
    if candidates & {"LIKE", "LIKES", "LIKED"}:
        matched.add("LIKE")
    if candidates & {"SHARE", "SHARES", "SHARED"}:
        matched.add("SHARE")
    if candidates & {"SUB", "SUBS", "SUBSCRIBE", "SUBSCRIBED", "SUBSCRIBING"}:
        matched.add("SUBSCRIBE")

    # Vietnamese CTA labels. "Đăng ký tài khoản" is deliberately excluded;
    # the bare two-word button "Đăng ký" and explicit channel prompts are kept.
    if "THICH" in candidates and len(tokens) <= 3:
        matched.add("LIKE")
    if "CHIASE" in candidates:
        matched.add("SHARE")
    dang_ky = "DANGKY" in candidates
    if dang_ky:
        cta_context = (
            len(tokens) == 2
            or any(token in {"KENH", "NGAY", "NHO", "HAY", "DUNG", "QUEN", "NHE", "MOI"} for token in tokens)
        )
        if cta_context:
            matched.add("SUBSCRIBE")

    if not matched:
        return None
    order = ("LIKE", "SHARE", "SUBSCRIBE")
    terms = [term for term in order if term in matched]
    return {
        "kind": "text_cta",
        "method": "OCR từ khóa CTA",
        "label": " · ".join(terms),
        "text": raw,
        "terms": terms,
    }

def _box_detection(x: int, y: int, w: int, h: int, confidence: float,
                   kind: str, method: str, label: str, text: str = "") -> dict:
    return {
        "x": int(x), "y": int(y), "w": int(w), "h": int(h),
        "confidence": round(max(0.0, min(100.0, float(confidence))), 1),
        "kind": kind, "method": method, "label": label, "text": text,
        "evidence": [kind], "animated": False, "motion_score": 0.0,
    }


def _find_graphic_subscribe_buttons(frame: np.ndarray) -> list[dict]:
    """Find likely red Subscribe/play-button graphics using local CV heuristics.

    This is deliberately conservative: a plain red rectangle is not enough.
    The region must also contain bright high-contrast artwork/text, and must
    have button-like geometry. Results remain manual-review suggestions.
    """
    if frame is None or frame.size == 0:
        return []
    height, width = frame.shape[:2]
    small, scale = _resize(frame, 960)
    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
    lower_red = cv2.inRange(hsv, np.array([0, 95, 75], np.uint8), np.array([12, 255, 255], np.uint8))
    upper_red = cv2.inRange(hsv, np.array([168, 95, 75], np.uint8), np.array([180, 255, 255], np.uint8))
    red = cv2.bitwise_or(lower_red, upper_red)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 3))
    red = cv2.morphologyEx(red, cv2.MORPH_CLOSE, kernel, iterations=2)
    contours, _ = cv2.findContours(red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    detections: list[dict] = []
    sh, sw = small.shape[:2]
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:60]:
        x, y, w, h = cv2.boundingRect(contour)
        area = float(w * h)
        area_ratio = area / max(1.0, float(sw * sh))
        aspect = w / max(1.0, float(h))
        if area_ratio < 0.00035 or area_ratio > 0.085 or w < 24 or h < 16:
            continue
        is_button = 1.55 <= aspect <= 7.5 and w >= 48
        is_icon = 0.68 <= aspect <= 1.38 and min(w, h) >= 24
        if not (is_button or is_icon):
            continue
        roi_red = red[y:y+h, x:x+w]
        roi = small[y:y+h, x:x+w]
        red_ratio = float(cv2.countNonZero(roi_red)) / max(1.0, area)
        if red_ratio < (0.19 if is_button else 0.30):
            continue
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        roi_hsv = hsv[y:y+h, x:x+w]
        bright_low_sat = ((gray >= 190) & (roi_hsv[:, :, 1] <= 95)).astype(np.uint8) * 255
        # A generic white word such as LIKE is not enough. For graphics-only
        # recognition require a compact play-triangle glyph inside the red
        # button; text-based Subscribe remains handled by OCR above.
        white_clean = cv2.morphologyEx(
            bright_low_sat, cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)), iterations=1,
        )
        glyph_contours, _ = cv2.findContours(white_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        has_play_glyph = False
        for glyph in glyph_contours:
            glyph_area = cv2.contourArea(glyph)
            if glyph_area < max(7.0, area * 0.006) or glyph_area > area * 0.16:
                continue
            gx, gy, gw, gh = cv2.boundingRect(glyph)
            if min(gw, gh) < 3 or max(gw / max(1.0, gh), gh / max(1.0, gw)) > 2.2:
                continue
            perimeter = cv2.arcLength(glyph, True)
            approx = cv2.approxPolyDP(glyph, 0.08 * perimeter, True)
            if 3 <= len(approx) <= 5 and cv2.isContourConvex(approx):
                extent = glyph_area / max(1.0, float(gw * gh))
                center_x = gx + gw * 0.5
                if extent >= 0.30 and w * 0.12 <= center_x <= w * 0.88:
                    has_play_glyph = True
                    break
        if not has_play_glyph:
            continue
        # Reject broad red footage overlays; require a compact button/icon.
        if is_button and h > int(sh * 0.16):
            continue
        confidence = min(78.0, 59.0 + red_ratio * 13.0)
        inv = 1.0 / max(0.001, scale)
        ox, oy = int(round(x * inv)), int(round(y * inv))
        ow, oh = int(round(w * inv)), int(round(h * inv))
        detections.append(_box_detection(
            ox, oy, ow, oh, confidence, "graphic_button", "Hình ảnh nút/biểu tượng",
            "Nút Subscribe dạng đồ họa", "Nút đỏ có nội dung/biểu tượng sáng",
        ))
    return detections


def _merge_detections(detections: list[dict]) -> list[dict]:
    detections = sorted(detections, key=lambda item: item.get("confidence", 0), reverse=True)
    kept: list[dict] = []
    for detection in detections:
        match = next((item for item in kept if _iou(item, detection) >= 0.42), None)
        if match is None:
            kept.append(dict(detection))
            continue
        match["evidence"] = sorted(set(match.get("evidence", [])) | set(detection.get("evidence", [])))
        if detection.get("kind") not in str(match.get("kind", "")):
            match["kind"] = "combined"
        if detection.get("confidence", 0) > match.get("confidence", 0):
            match["confidence"] = detection["confidence"]
        if detection.get("method") and detection["method"] not in str(match.get("method", "")):
            match["method"] = f"{match.get('method', '')} + {detection['method']}".strip(" +")
    return kept[:10]


def _location_for_box(x: int, y: int, w: int, h: int, frame_w: int, frame_h: int) -> str:
    cx, cy = x + w / 2, y + h / 2
    if cy >= frame_h * 0.72:
        return "dưới"
    if cy <= frame_h * 0.24:
        return "trên"
    if cx <= frame_w * 0.2:
        return "rìa trái"
    if cx >= frame_w * 0.8:
        return "rìa phải"
    return "giữa"


def find_subscribe_regions(frame: np.ndarray, max_width: int = 1280, thorough: bool = False) -> list[dict]:
    """Read explicit CTA words with sparse-text OCR; never classify scenes or motion."""
    if frame is None or frame.size == 0:
        return []
    ocr = _get_tesseract()
    small, source_scale = _resize(frame, max_width)
    original_h, original_w = frame.shape[:2]
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    # Preserve small on-screen labels while bounding per-frame OCR cost.
    upscale = min(1.5, 1600.0 / max(1.0, float(gray.shape[1])))
    if upscale > 1.0:
        gray = cv2.resize(
            gray,
            (int(round(gray.shape[1] * upscale)), int(round(gray.shape[0] * upscale))),
            interpolation=cv2.INTER_CUBIC,
        )
    gray = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    border = max(12, int(round(12 * upscale)))
    padded = cv2.copyMakeBorder(gray, border, border, border, border,
                                cv2.BORDER_CONSTANT, value=0)

    def run_ocr(image: np.ndarray, psm: int = 11) -> dict:
        try:
            return ocr.image_to_data(
                image,
                lang=_ocr_language(ocr),
                config=(f"{_tessdata_config()} --oem 1 --psm {int(psm)} -c preserve_interword_spaces=1").strip(),
                output_type=ocr.Output.DICT,
                timeout=4,
            )
        except ocr.TesseractError as exc:
            raise RuntimeError(
                "Tesseract không mở được model OCR khi đọc khung hình. "
                f"Thư mục model: {_TESSDATA_DIR or os.environ.get('TESSDATA_PREFIX', '(chưa đặt)')}. "
                f"Chi tiết: {exc}"
            ) from exc
        except RuntimeError as exc:
            message = str(exc).lower()
            if "timeout" in message or "timed out" in message:
                raise RuntimeError(f"Tesseract OCR quá thời gian khi đọc khung hình: {exc}") from exc
            raise RuntimeError(f"Tesseract OCR gặp lỗi khi đọc khung hình: {exc}") from exc
        except Exception as exc:
            raise RuntimeError(f"Không đọc được từ khóa CTA bằng OCR: {exc}") from exc

    inverse = 1.0 / max(0.001, source_scale * upscale)

    def parse_ocr(data: dict) -> list[dict]:
        tokens: list[dict] = []
        line_groups: dict[tuple[int, int, int], list[dict]] = {}
        for index, raw_text in enumerate(data.get("text", [])):
            text = str(raw_text or "").strip()
            if not text:
                continue
            try:
                confidence = float(data.get("conf", [])[index])
                x, y = int(data["left"][index]), int(data["top"][index])
                tw, th = int(data["width"][index]), int(data["height"][index])
                key = (
                    int(data["block_num"][index]),
                    int(data["par_num"][index]),
                    int(data["line_num"][index]),
                )
            except (ValueError, TypeError, IndexError, KeyError):
                continue
            if confidence < 0 or tw <= 0 or th <= 0:
                continue
            token = {
                "text": text, "confidence": confidence,
                "x": x, "y": y, "w": tw, "h": th,
            }
            tokens.append(token)
            line_groups.setdefault(key, []).append(token)

        def match_groups(groups) -> list[dict]:
            matched = []
            seen = set()
            for group in groups:
                line_tokens = sorted(group, key=lambda item: item["x"])
                if not line_tokens:
                    continue
                raw_line = " ".join(token["text"] for token in line_tokens)
                match = _classify_subscribe_text(raw_line)
                if not match:
                    continue
                x1 = min(item["x"] for item in line_tokens) - border
                y1 = min(item["y"] for item in line_tokens) - border
                x2 = max(item["x"] + item["w"] for item in line_tokens) - border
                y2 = max(item["y"] + item["h"] for item in line_tokens) - border
                pad_x = max(6, int((x2 - x1) * 0.22))
                pad_y = max(5, int((y2 - y1) * 0.55))
                box = (
                    max(0, int(round((x1 - pad_x) * inverse))),
                    max(0, int(round((y1 - pad_y) * inverse))),
                    min(original_w, int(round((x2 + pad_x) * inverse))),
                    min(original_h, int(round((y2 + pad_y) * inverse))),
                )
                if box[2] <= box[0] or box[3] <= box[1]:
                    continue
                identity = (box, raw_line.upper())
                if identity in seen:
                    continue
                seen.add(identity)
                matched.append({
                    "x1": box[0], "y1": box[1], "x2": box[2], "y2": box[3],
                    "confidence": sum(item["confidence"] for item in line_tokens) / len(line_tokens),
                    "text": raw_line,
                    "terms": list(match.get("terms", [])),
                })
            return matched

        # First use Tesseract's own line segmentation.
        matched_lines = match_groups(line_groups.values())

        # Sparse-text PSM 11 may assign adjacent pieces to different blocks or
        # line IDs. When that happens, rebuild rows by their actual geometry
        # and join only nearby boxes on the same baseline. This recovers
        # SUB + SCRIBE / SH + ARE / L + IKE without merging distant captions.
        if len(tokens) >= 2:
            rows: list[dict] = []
            for token in sorted(tokens, key=lambda item: (item["y"] + item["h"] / 2, item["x"])):
                center_y = token["y"] + token["h"] / 2
                candidates = []
                for row_index, row in enumerate(rows):
                    row_center = sum(
                        item["y"] + item["h"] / 2 for item in row["tokens"]
                    ) / len(row["tokens"])
                    row_height = max(item["h"] for item in row["tokens"])
                    tolerance = max(4.0, 0.45 * max(token["h"], row_height))
                    distance = abs(center_y - row_center)
                    if distance <= tolerance:
                        candidates.append((distance, row_index))
                if candidates:
                    rows[min(candidates)[1]]["tokens"].append(token)
                else:
                    rows.append({"tokens": [token]})

            spatial_groups = []
            for row in rows:
                row_tokens = sorted(row["tokens"], key=lambda item: item["x"])
                segment = []
                for token in row_tokens:
                    if segment:
                        previous = segment[-1]
                        gap = token["x"] - (previous["x"] + previous["w"])
                        max_gap = max(16.0, 1.5 * max(token["h"], previous["h"]))
                        if gap > max_gap:
                            spatial_groups.append(segment)
                            segment = []
                    segment.append(token)
                if segment:
                    spatial_groups.append(segment)
            matched_lines.extend(match_groups(spatial_groups))

        if not matched_lines:
            return []
        # One OCR hit per frame keeps separate CTA labels in a single time range.
        x1 = min(item["x1"] for item in matched_lines)
        y1 = min(item["y1"] for item in matched_lines)
        x2 = max(item["x2"] for item in matched_lines)
        y2 = max(item["y2"] for item in matched_lines)
        order = ("LIKE", "SHARE", "SUBSCRIBE")
        terms_found = {term for item in matched_lines for term in item["terms"]}
        terms = [term for term in order if term in terms_found]
        texts = list(dict.fromkeys(item["text"] for item in matched_lines))
        confidence = sum(item["confidence"] for item in matched_lines) / len(matched_lines)
        detection = _box_detection(
            x1, y1, x2 - x1, y2 - y1, confidence,
            "text_cta", "OCR từ khóa CTA", " · ".join(terms), " | ".join(texts),
        )
        detection["terms"] = terms
        return [detection]

    # CTA text is usually sparse and can be placed anywhere on the video.
    # PSM 11 is therefore the primary pass. PSM 6 remains as a layout fallback,
    # followed by Otsu only when both miss; this keeps the sample interval intact.
    detections = parse_ocr(run_ocr(padded, psm=11))
    if not detections:
        detections = parse_ocr(run_ocr(padded, psm=6))
    if not detections:
        otsu = cv2.threshold(padded, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        detections = parse_ocr(run_ocr(otsu, psm=11))
    if not detections and thorough:
        adaptive = cv2.adaptiveThreshold(
            padded, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 31, 9,
        )
        detections = parse_ocr(run_ocr(adaptive, psm=11))

    for item in detections:
        item["location"] = _location_for_box(
            item["x"], item["y"], item["w"], item["h"], original_w, original_h
        )
    return detections[:1]


# Backward compatibility for callers/tests from v1.5.2.0.
def find_cta_regions(frame: np.ndarray, max_width: int = 1280) -> list[dict]:
    return find_subscribe_regions(frame, max_width=max_width)


def find_end_screen_panels(_frame: np.ndarray, max_width: int = 480) -> list[dict]:
    """Generic end screens are not Subscribe CTAs; text/graphics are scanned normally."""
    return []


def _iou(a: dict, b: dict) -> float:
    ax, ay, aw, ah = (float(a[k]) for k in ("x", "y", "w", "h"))
    bx, by, bw, bh = (float(b[k]) for k in ("x", "y", "w", "h"))
    ix = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    union = aw * ah + bw * bh - ix * iy
    return (ix * iy / union) if union > 0 else 0.0


def _tracks_to_candidates(tracks: list[dict], duration: float, interval: float) -> list[dict]:
    candidates: list[dict] = []
    for track in tracks:
        times = sorted(set(round(float(value), 3) for value in track["times"]))
        n = len(times)
        peak = max(track["scores"])
        evidence_set = set(track.get("evidence", []))
        has_explicit_cta_text = bool(evidence_set & {
            "text_cta", "text_en", "text_vi", "text_like", "text_share", "text_subscribe"
        })
        # Exact OCR keyword matches are reviewable even when a CTA appears in
        # only one sampled image; no visual/motion-only track is accepted.
        minimum_single_frame_score = 20.0 if has_explicit_cta_text else 55.0
        if n < 2 and peak < minimum_single_frame_score:
            continue
        local_interval = min(track.get("intervals", [interval]) or [interval])
        pad = max(0.12, min(float(interval), float(local_interval)) * 0.58)
        start = max(0.0, float(times[0]) - pad)
        end = min(duration, float(times[-1]) + pad)
        if end - start < 0.25:
            end = min(duration, start + max(0.5, local_interval))
        box = track["box"]
        evidence = sorted(set(track.get("evidence", [])))
        texts = [text for text in track.get("texts", []) if text]
        terms_found = set(str(value).upper() for value in track.get("terms", []) if str(value).strip())
        order = ("LIKE", "SHARE", "SUBSCRIBE")
        terms = [term for term in order if term in terms_found]
        labels = [str(value) for value in track.get("labels", []) if str(value).strip()]
        label = " · ".join(terms or list(dict.fromkeys(labels)) or ["CTA"])
        candidate = {
            "scan_id": int(track["scan_id"]),
            "start": round(start, 3), "end": round(end, 3),
            "duration": round(max(0.0, end - start), 3),
            "sample_time": (float(track["_preview_sample_time"]) if track.get("_preview_sample_time") is not None else float(times[len(times) // 2])),
            "x": int(box["x"]), "y": int(box["y"]),
            "w": int(box["w"]), "h": int(box["h"]),
            "confidence": round(float(sum(track["scores"]) / max(1, len(track["scores"]))), 1),
            "peak_confidence": round(float(peak), 1),
            "samples": n,
            "location": max(set(track["locations"]), key=track["locations"].count),
            "kind": "text_cta", "label": label, "terms": terms,
            "text": texts[-1] if texts else label,
            "method": "OCR từ khóa CTA", "evidence": evidence or ["text_cta"],
            "animated": False, "motion_score": 0.0,
        }
        preview_jpeg = track.get("_preview_jpeg")
        if isinstance(preview_jpeg, bytes) and preview_jpeg:
            # Private in-process evidence; engine_worker writes it to disk and
            # removes this key before the candidate crosses the JSON IPC.
            candidate["_preview_jpeg"] = preview_jpeg
            candidate["_preview_confidence"] = float(track.get("_preview_confidence", 0) or 0)
        candidates.append(candidate)
    candidates.sort(key=lambda item: (item["start"], -item["confidence"]))
    return candidates


def _motion_score(previous: np.ndarray | None, current: np.ndarray, detection: dict) -> float:
    if previous is None or previous.shape != current.shape:
        return 0.0
    x, y, w, h = (int(detection[k]) for k in ("x", "y", "w", "h"))
    height, width = current.shape[:2]
    x1, y1 = max(0, x), max(0, y)
    x2, y2 = min(width, x + w), min(height, y + h)
    if x2 - x1 < 8 or y2 - y1 < 8:
        return 0.0
    before = cv2.cvtColor(previous[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    after = cv2.cvtColor(current[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    before = cv2.resize(before, (64, 32), interpolation=cv2.INTER_AREA)
    after = cv2.resize(after, (64, 32), interpolation=cv2.INTER_AREA)
    return float(cv2.absdiff(before, after).mean())


def _merge_windows(windows: list[tuple[float, float]], duration: float) -> list[tuple[float, float]]:
    if not windows:
        return []
    ordered = sorted((max(0.0, a), min(duration, b)) for a, b in windows if b > a)
    merged: list[list[float]] = []
    for start, end in ordered:
        if not merged or start > merged[-1][1] + 0.35:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    return [(a, b) for a, b in merged]


MAX_PASS1_SAMPLES = 120_000
MAX_PASS2_SAMPLES = 60_000


def _effective_pass1_sample_limit(duration: float, interval: float,
                                  configured_limit: int) -> tuple[int, bool]:
    """Honor the requested sampling interval up to an explicit safety ceiling."""
    safe_interval = max(0.05, float(interval))
    requested_count = max(1, int(math.ceil(max(0.0, float(duration)) / safe_interval)))
    capped = requested_count > MAX_PASS1_SAMPLES
    effective_limit = max(1, int(configured_limit), min(requested_count, MAX_PASS1_SAMPLES))
    return min(MAX_PASS1_SAMPLES, effective_limit), capped


def _sample_times(duration: float, interval: float, max_samples: int) -> tuple[list[float], float]:
    count = max(1, min(int(max_samples), int(math.ceil(duration / max(0.05, interval)))))
    actual_interval = duration / count
    times = [min(duration - 0.001, i * actual_interval + actual_interval * 0.5) for i in range(count)]
    return times, actual_interval


class _SequentialFrameSampler:
    """Read sparse samples sequentially and seek only across distant gaps."""

    def __init__(self, capture, fps: float, frame_count: int, seek_gap_seconds: float = 2.5):
        self.capture = capture
        self.fps = max(0.1, float(fps))
        self.frame_count = max(0, int(frame_count))
        self.seek_gap_frames = max(1, int(round(self.fps * max(0.5, seek_gap_seconds))))
        self.next_frame_index: int | None = None
        self.seek_count = 0
        self.grabbed_frames = 0

    def read_at(self, seconds: float) -> tuple[bool, np.ndarray | None]:
        if self.frame_count <= 0:
            return False, None
        target = int(round(max(0.0, float(seconds)) * self.fps))
        target = min(self.frame_count - 1, max(0, target))
        needs_seek = (
            self.next_frame_index is None
            or target < self.next_frame_index
            or target - self.next_frame_index > self.seek_gap_frames
        )
        if needs_seek:
            positioned = self.capture.set(cv2.CAP_PROP_POS_FRAMES, float(target))
            if not positioned:
                self.capture.set(cv2.CAP_PROP_POS_MSEC, max(0.0, float(seconds)) * 1000.0)
            self.seek_count += 1
            ok, frame = self.capture.read()
            self.next_frame_index = target + 1 if ok else None
            return ok, frame

        while self.next_frame_index < target:
            if not self.capture.grab():
                self.next_frame_index = None
                return False, None
            self.next_frame_index += 1
            self.grabbed_frames += 1
        ok, frame = self.capture.read()
        self.next_frame_index = target + 1 if ok else None
        return ok, frame


def _encode_cta_preview(frame: np.ndarray, detection: dict,
                       max_width: int = 720, max_height: int = 420) -> bytes | None:
    """Encode the sampled OCR evidence frame without launching another decoder."""
    if frame is None or frame.size == 0:
        return None
    preview = frame.copy()
    height, width = preview.shape[:2]
    x1 = max(0, min(width - 1, int(detection.get("x", 0) or 0)))
    y1 = max(0, min(height - 1, int(detection.get("y", 0) or 0)))
    x2 = max(x1 + 1, min(width - 1, x1 + max(1, int(detection.get("w", 1) or 1))))
    y2 = max(y1 + 1, min(height - 1, y1 + max(1, int(detection.get("h", 1) or 1))))
    cv2.rectangle(preview, (x1, y1), (x2, y2), (40, 235, 220), 3)
    frame_h, frame_w = preview.shape[:2]
    scale = min(
        float(max_width) / max(1, frame_w),
        float(max_height) / max(1, frame_h),
        1.0,
    )
    if scale < 1.0:
        preview = cv2.resize(
            preview,
            (max(1, int(round(frame_w * scale))), max(1, int(round(frame_h * scale)))),
            interpolation=cv2.INTER_AREA,
        )
    ok, encoded = cv2.imencode(
        ".jpg", preview, [cv2.IMWRITE_JPEG_QUALITY, 88]
    )
    return encoded.tobytes() if ok else None


def _update_tracks(tracks: list[dict], detections: list[dict], seconds: float, interval: float,
                   motion_values: list[float] | None = None,
                   scan_id_offset: int = 0,
                   preview_jpeg: bytes | None = None) -> None:
    for detection in detections:
        chosen = None
        best_score = 0.0
        for track in tracks:
            delta = min(abs(seconds - float(track["first_time"])), abs(seconds - float(track["last_time"])))
            if delta > max(2.5, interval * 1.3):
                continue
            overlap = _iou(detection, track["box"])
            if overlap > best_score and overlap >= 0.06:
                best_score, chosen = overlap, track
        if chosen is None:
            tracks.append({
                "scan_id": int(scan_id_offset) + len(tracks), "box": dict(detection),
                "first_time": seconds, "last_time": seconds,
                "times": [seconds], "scores": [detection["confidence"]],
                "locations": [detection.get("location", "—")],
                "evidence": list(detection.get("evidence", [detection.get("kind", "text_cta")])),
                "methods": [detection.get("method", "OCR từ khóa CTA")],
                "texts": [detection.get("text", "")],
                "labels": [detection.get("label", "")],
                "terms": list(detection.get("terms", [])),
                "intervals": [interval], "animated": False, "motion_scores": [0.0],
                "_preview_jpeg": preview_jpeg,
                "_preview_confidence": float(detection.get("confidence", 0) or 0) if preview_jpeg else -1.0,
                "_preview_sample_time": float(seconds) if preview_jpeg else None,
            })
        else:
            if not any(abs(seconds - existing) < 0.015 for existing in chosen["times"]):
                chosen["times"].append(seconds)
                chosen["scores"].append(detection["confidence"])
                chosen["locations"].append(detection.get("location", "—"))
                chosen["intervals"].append(interval)
                chosen["motion_scores"].append(0.0)
            chosen["first_time"] = min(float(chosen["first_time"]), seconds)
            chosen["last_time"] = max(float(chosen["last_time"]), seconds)
            chosen["evidence"] = sorted(set(chosen["evidence"]) | set(detection.get("evidence", ["text_cta"])))
            if detection.get("method") and detection["method"] not in chosen["methods"]:
                chosen["methods"].append(detection["method"])
            if detection.get("text") and detection["text"] not in chosen["texts"]:
                chosen["texts"].append(detection["text"])
            if detection.get("label") and detection["label"] not in chosen["labels"]:
                chosen["labels"].append(detection["label"])
            chosen["terms"] = sorted(
                set(chosen.get("terms", [])) | set(detection.get("terms", [])),
                key=lambda value: ("LIKE", "SHARE", "SUBSCRIBE").index(value)
                if value in ("LIKE", "SHARE", "SUBSCRIBE") else 99,
            )
            for key in ("x", "y", "w", "h"):
                chosen["box"][key] = int(round(0.65 * chosen["box"][key] + 0.35 * detection[key]))
            chosen["box"]["confidence"] = max(chosen["box"].get("confidence", 0), detection["confidence"])
            detection_confidence = float(detection.get("confidence", 0) or 0)
            if preview_jpeg and detection_confidence > float(chosen.get("_preview_confidence", -1.0)):
                chosen["_preview_jpeg"] = preview_jpeg
                chosen["_preview_confidence"] = detection_confidence
                chosen["_preview_sample_time"] = float(seconds)


def detect_cta_image_candidates(
    video_path: str,
    sample_interval: float = 2.0,
    max_samples: int = 1800,
    scan_mode: str = "fast",
    start_at: float = 0.0,
    max_width: int = 1280,
    cancel_event: Optional[threading.Event] = None,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    pause_event: Optional[threading.Event] = None,
    pause_callback: Optional[Callable[[], None]] = None,
    candidate_callback: Optional[Callable[[list[dict], int, int], None]] = None,
    phase_callback: Optional[Callable[[str, int, int], None]] = None,
    checkpoint_callback: Optional[Callable[[float], None]] = None,
) -> dict:
    """Scan the whole video once at the requested interval using OCR CTA keywords only."""
    status = get_subscribe_ocr_status()
    if not status.get("ready"):
        raise RuntimeError(status.get("message", "Tesseract OCR chưa sẵn sàng."))

    cap = cv2.VideoCapture(str(video_path))
    try:
        if not cap.isOpened():
            raise RuntimeError("Không mở được video để quét từ khóa CTA.")
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        duration = frame_count / fps if fps > 0 and frame_count > 0 else 0.0
        if duration <= 0:
            raise RuntimeError("Không đọc được thời lượng video.")

        requested_interval = max(0.5, float(sample_interval))
        effective_max_samples, sample_cap_reached = _effective_pass1_sample_limit(
            duration, requested_interval, max_samples
        )
        sample_times, actual_interval = _sample_times(
            duration, requested_interval, effective_max_samples
        )
        try:
            resume_at = max(0.0, min(duration - 0.001, float(start_at or 0.0)))
        except (TypeError, ValueError):
            resume_at = 0.0
        if resume_at > 0.0:
            sample_times = [seconds for seconds in sample_times if seconds >= resume_at]
            if not sample_times:
                raise RuntimeError("Đã đến cuối video, không còn khung hình mới để quét.")

        tracks: list[dict] = []
        # Use a time-derived ID namespace for resumed scans so their results
        # cannot collide with existing cached candidate IDs from earlier scans.
        scan_id_offset = int(round(resume_at * 1000.0))
        valid = 0
        ocr_timeouts = 0
        last_signature = None
        last_candidate_at = 0.0
        sampler = _SequentialFrameSampler(cap, fps, frame_count)
        total = max(1, len(sample_times))

        def check_pause() -> None:
            notified = False
            while pause_event is not None and pause_event.is_set():
                if cancel_event is not None and cancel_event.is_set():
                    raise CTAScanCancelled("Đã dừng quét CTA theo yêu cầu.")
                if pause_callback and not notified:
                    pause_callback()
                    notified = True
                time.sleep(0.10)
            if cancel_event is not None and cancel_event.is_set():
                raise CTAScanCancelled("Đã dừng quét CTA theo yêu cầu.")

        if phase_callback:
            phase_callback("pass1", 0, total)
        for index, seconds in enumerate(sample_times, 1):
            check_pause()
            ok, frame = sampler.read_at(seconds)
            if ok and frame is not None:
                valid += 1
                try:
                    detections = find_subscribe_regions(frame, max_width=max_width, thorough=False)
                except RuntimeError as exc:
                    message = str(exc).lower()
                    if "timeout" not in message and "timed out" not in message and "quá thời gian" not in message:
                        raise
                    # A single slow Tesseract frame must not terminate the whole
                    # video scan. Record the timeout and continue with the next
                    # sample so Pause/Resume and the remaining timeline survive.
                    ocr_timeouts += 1
                    detections = []
                preview_jpeg = _encode_cta_preview(frame, detections[0]) if detections else None
                _update_tracks(
                    tracks, detections, seconds, actual_interval,
                    scan_id_offset=scan_id_offset,
                    preview_jpeg=preview_jpeg,
                )
            next_resume_at = sample_times[index] if index < len(sample_times) else duration
            if checkpoint_callback:
                checkpoint_callback(float(next_resume_at))
            if progress_callback:
                progress_callback(index, total)
            if phase_callback:
                phase_callback("pass1", index, total)
            if candidate_callback:
                now = time.monotonic()
                should_publish = index == total or last_candidate_at <= 0.0 or now - last_candidate_at >= 2.0
                if should_publish:
                    current = _tracks_to_candidates(tracks, duration, actual_interval)
                    signature = tuple((
                        item["scan_id"], round(item["start"], 1), round(item["end"], 1),
                        tuple(item.get("terms", [])), item["samples"],
                    ) for item in current)
                    if signature != last_signature:
                        candidate_callback(current, index, total)
                        last_signature = signature
                    last_candidate_at = now

        if valid < max(1, int(len(sample_times) * 0.5)):
            raise RuntimeError("Không đọc đủ khung hình mẫu. Hãy kiểm tra codec hoặc thử MP4.")
        candidates = _tracks_to_candidates(tracks, duration, actual_interval)
        if candidate_callback:
            candidate_callback(candidates, total, total)
        if phase_callback:
            phase_callback("done", 1, 1)
        return {
            "duration": duration, "samples": valid,
            "ocr_timeouts": int(ocr_timeouts),
            "sample_interval": actual_interval,
            "requested_sample_interval": requested_interval,
            "pass1_interval": actual_interval,
            "pass2_interval": 0.0,
            "pass2_requested_interval": 0.0,
            "sample_cap_reached": bool(sample_cap_reached),
            "pass2_sample_cap_reached": False,
            "pass1_sample_limit": int(effective_max_samples),
            "candidates": candidates,
            "pass1_samples": len(sample_times),
            "pass2_samples": 0,
            "note": (
                f"Đã rà toàn video một lượt, khoảng {actual_interval:.2f} giây/ảnh. "
                "Chỉ OCR từ khóa LIKE, SHARE, SUB/SUBSCRIBE và cụm tiếng Việt THÍCH, CHIA SẺ, ĐĂNG KÝ. "
                f"Bỏ qua {ocr_timeouts} khung hình OCR Timeout và tiếp tục quét. "
                "Không phân loại cảnh, không nhận diện chuyển động và không xử lý âm thanh. "
                "Hãy xem ảnh mẫu rồi chỉ chọn các khoảng cần cắt."
            ),
        }
    finally:
        cap.release()
