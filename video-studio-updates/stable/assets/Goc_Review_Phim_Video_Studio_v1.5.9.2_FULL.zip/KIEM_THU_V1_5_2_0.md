# Kiểm thử v1.5.2.0 — CTA Live Scan

Ngày build: 2026-11-13

## Đã chạy
- `python -m py_compile app.py qt_app.py engine_worker.py cta_detector.py`: PASS.
- `python -m pytest -q -p no:cacheprovider tests`: **26 passed, 14 subtests passed**.
- CTA synthetic video: phát hiện nút CTA đỏ và gom khoảng thời gian: PASS.
- Callback kết quả trực tiếp: ứng viên xuất hiện trước khi quét hết video và giữ `scan_id` ổn định qua các lần cập nhật: PASS.
- Pause/resume: tiến độ đứng yên khi pause, tiếp tục từ mẫu kế tiếp sau resume, không khởi động lại: PASS.
- Cancel khi đang pause: giải phóng worker và kết thúc bằng `CTAScanCancelled`: PASS.
- Regression hủy quét, end-screen, cắt khoảng CTA, đồng bộ hình/tiếng và xuất MP4: PASS.
- Regression downloader và giao diện workspace v1.5.1: PASS.

## Chưa thể xác nhận trong môi trường build
- Không có PySide6 trong runtime dựng và không có kết nối mạng để cài; do đó chưa chạy được cửa sổ Qt thật, chưa kiểm tra DPI, click Pause/Resume trên Windows hoặc thumbnail cập nhật trong QTableWidget bằng tương tác thực tế.
- Cần nghiệm thu trên Windows: bắt đầu quét; quan sát các dòng CTA xuất hiện; tạm dừng; xác nhận progress không tăng; tiếp tục; thử Dừng & giữ kết quả; sau đó chọn và cắt các đoạn đã duyệt.

## Bảo toàn
- Không đổi project schema, project/autosave data, engine xử lý khác, thuật toán cắt CTA, downloader, Mask, Branding hay pipeline xuất video.
- CTA detection là heuristic thị giác, không phải OCR/AI ngữ nghĩa; cần duyệt người dùng.
