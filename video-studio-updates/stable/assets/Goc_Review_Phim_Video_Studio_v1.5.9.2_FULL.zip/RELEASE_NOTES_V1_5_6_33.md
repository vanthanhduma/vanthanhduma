# Góc Review Phim Video Studio v1.5.6.33

## Ba chế độ CTA cho video dài
1. **Nhanh · 1 giây/ảnh:** rà toàn video; lượt 2 kiểm tra vùng nghi vấn khoảng 0,35 giây.
2. **Khuyến nghị · 0,5 giây/ảnh:** mặc định cho video 2–3 tiếng; lượt 2 kiểm tra vùng nghi vấn khoảng 0,25 giây.
3. **Quét kỹ · 0,5 giây/ảnh + OCR sâu:** giữ mật độ lượt 1 như Khuyến nghị, tăng độ phân giải/tiền xử lý OCR, mở rộng vùng nghi vấn và kiểm tra lượt 2 khoảng 0,125 giây.

## Giảm nghẽn khi quét video dài
- Đọc tuần tự giữa các ảnh mẫu bằng grab/read; chỉ seek khi bắt đầu hoặc chuyển sang vùng nghi vấn cách xa.
- Giới hạn gửi tiến độ khoảng 2 lần/giây; live candidate/thumbnail khoảng 1 lần/giây.
- Giới hạn tính lại snapshot ứng viên khoảng 1 lần/giây thay vì mỗi ba ảnh mẫu.
- Giữ giới hạn an toàn, Pause/Resume, Stop, cache và duyệt thủ công.

## Quy mô video 2–3 tiếng
- Nhanh: khoảng 7.200–10.800 mẫu lượt 1.
- Khuyến nghị/Quét kỹ: khoảng 14.400–21.600 mẫu lượt 1.
- Video 227 phút: 13.620 mẫu ở Nhanh; 27.240 mẫu ở Khuyến nghị/Quét kỹ.
- Quét kỹ dành thời gian thêm cho OCR sâu và lượt 2, không tăng mật độ lượt 1.

## Giữ nguyên
- CTA hiển thị trong video, OCR Anh/Việt, nhận diện đồ họa/chuyển động; không phân tích âm thanh.
- Duyệt thủ công trước khi cắt, Xóa tất cả và các cải tiến Mask v1.5.6.30–32.

## Nâng cấp
- UPDATE tương thích với v1.5.6.30, v1.5.6.31 và v1.5.6.32.
- Không chứa video nguồn, dự án, .venv, downloads hoặc renders.
- Bổ sung kiểm thử nguồn 2–3 tiếng, đọc tuần tự và seek khi chuyển vùng.
