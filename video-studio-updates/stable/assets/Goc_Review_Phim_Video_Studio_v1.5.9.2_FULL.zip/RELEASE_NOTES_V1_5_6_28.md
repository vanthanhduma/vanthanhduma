# Gốc Review Phim Video Studio v1.5.6.28

## Tiếp tục CTA từ key cuối

- Cache CTA lưu thêm key thời gian cuối đã quét.
- Nút **Quét bổ sung** tiếp tục từ key đó và chỉ quét phần còn lại của video.
- Key được hiển thị theo dạng giờ/phút/giây, phù hợp với video dài hàng tiếng.
- Các ứng viên CTA cũ vẫn giữ nguyên và được gộp với kết quả mới.
- Không còn xóa trắng bảng CTA khi bắt đầu quét bổ sung.

