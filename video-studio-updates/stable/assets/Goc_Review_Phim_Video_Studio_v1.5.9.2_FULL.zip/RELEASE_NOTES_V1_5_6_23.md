# Góc Review Phim Video Studio v1.5.6.23

## Tối ưu xem video gốc

- Giảm giật/lag khi xem đoạn Từ–Đến dài.
- Preview chỉ giữ một cửa sổ đệm tối đa 8 khung hình, không tích lũy hàng nghìn file JPEG trong thời gian phát.
- Giảm kích thước khung preview và chỉ giải mã đầy đủ những frame thực sự cần hiển thị.
- Dừng preview sẽ giải phóng bộ giải mã và file tạm ngay.
