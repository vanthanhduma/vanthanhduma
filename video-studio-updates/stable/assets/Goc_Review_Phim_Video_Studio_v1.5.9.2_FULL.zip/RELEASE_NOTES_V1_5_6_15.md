# Góc Review Phim Video Studio v1.5.6.15

## CTA Subscribe

- Cho phép xem ngay ứng viên đầu tiên khi Detector vừa phát hiện, không cần đợi quét toàn video hoàn tất.
- Tự chọn dòng đầu tiên trong kết quả live để nút `Xem đoạn đã chọn` hoạt động sớm.
- Giữ `Cắt đã chọn` khóa đến khi quét xong để không cắt thiếu ứng viên.

