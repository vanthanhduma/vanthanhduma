# Kiểm thử v1.5.3.0 — Subscribe Only + Precise Timeline Seek

## Kiểm thử source

- Python compile: PASS (`app.py`, `qt_app.py`, `engine_worker.py`, `cta_detector.py`, `timeline_seek.py`).
- Pytest: 37 passed, 14 subtests passed.
- Detector Subscribe OCR synthetic frame: PASS (Tesseract 5.5.0 trong môi trường build; phát hiện chữ Subscribe với confidence khoảng 96 trong fixture tổng hợp).
- Negative OCR fixtures (LIKE và hình chữ nhật đỏ không có chữ Subscribe): PASS.
- Timecode parse/format, kiểm tra giá trị âm/NaN/inf và phút/giây không hợp lệ: PASS.
- Static UI contract: click-to-seek, timecode entry, millisecond range, xem trước mốc trong lúc kéo và drag guard: PASS.
- Regression CTA pause/resume/live updates/manual selection/cut-export, Downloader và các workspace test: PASS.

## Giới hạn nghiệm thu

- Môi trường build không cài PySide6 nên không thể mở Qt GUI thật hoặc kiểm tra thao tác chuột trên Windows trong phiên build.
- Tesseract OCR là executable bên ngoài; gói FULL bao gồm script `CAI_TESSERACT_OCR.bat` để cài bằng winget nếu máy chưa có. Cần xác nhận Tesseract đã cài trên máy Windows trước khi quét Subscribe.
- OCR chỉ tìm từ SUBSCRIBE hiển thị trong khung hình; không phân tích lời nói/âm thanh và không nhận dạng CTA khác.

**Kết quả tự động: PASS. Runtime GUI/Windows: chờ nghiệm thu trên máy người dùng.**
