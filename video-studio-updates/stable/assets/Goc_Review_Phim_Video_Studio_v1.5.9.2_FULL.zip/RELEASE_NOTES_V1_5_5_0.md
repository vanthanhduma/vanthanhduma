# Release Notes — v1.5.5.0

## In-App Auto Updater
- Thêm nút **Kiểm tra cập nhật** ngay trên thanh tiêu đề Workspace.
- Kiểm tra Stable Release ở chế độ nền, tối đa một lần trong 24 giờ khi đã kết nối GitHub.
- Thêm Trung tâm cập nhật trong ứng dụng: xem phiên bản, ghi chú phát hành, dung lượng và trạng thái tải.
- Cập nhật một lần bấm: tải gói, xác minh manifest Ed25519, SHA-256, danh sách file và đường dẫn trước khi áp dụng.
- Repository riêng tư: kết nối Fine-grained GitHub token chỉ quyền đọc; lưu token bằng Windows Credential Manager qua keyring.
- Trình helper độc lập chờ ứng dụng đóng, sao lưu file ứng dụng, áp dụng theo allowlist và chạy health check; tự rollback nếu thất bại.
- Chờ CTA scan, Mask/Export/Batch, Downloader và lệnh Engine đang xử lý kết thúc; không cắt ngang tác vụ.
- Không thay đổi project schema và không cập nhật `.venv`, project, autosave, user settings, preset, branding cá nhân, downloads, renders, video hoặc output.

## Preserved
- CTA Subscribe Detector với OCR Việt/Anh, quét hai lượt, Pause/Resume và duyệt thủ công.
- Mask, Before/After, Branding, Downloader, project save/open, Batch, timeline seek, Export và QC.

## Ghi chú triển khai
- v1.5.4.0 không có updater; cần cài bootstrap update v1.5.5.0 một lần. Từ v1.5.5.0 trở đi mới dùng cập nhật trực tiếp trong ứng dụng.
- GitHub repository phát hành đang private; cần cấp fine-grained token quyền Contents: Read-only trong lần kết nối đầu tiên.
- GUI Qt/Windows native cần nghiệm thu trên laptop Windows; build container hiện không có PySide6.
