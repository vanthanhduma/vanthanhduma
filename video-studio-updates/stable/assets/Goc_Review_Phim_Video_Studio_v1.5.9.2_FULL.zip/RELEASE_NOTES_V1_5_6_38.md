# v1.5.6.38 – CTA OCR đọc chữ tốt hơn, không quét dày hơn

## Tập trung chất lượng đọc chữ
- Giữ cố định lấy mẫu 1 ảnh mỗi 2 giây; bỏ lựa chọn 0,5 giây/ảnh vì tăng thời gian nhưng không cải thiện khả năng đọc của OCR trên từng ảnh.
- Ưu tiên Tesseract PSM 11 phù hợp chữ CTA rải rác ở nhiều vị trí trên khung hình; PSM 6 và Otsu là các lượt dự phòng khi chưa đọc được từ khóa.
- Khi OCR tách một từ thành nhiều mảnh nằm ở các block/dòng khác nhau, ghép theo vị trí hình học và đường cơ sở chữ; chỉ nối các mảnh nằm gần nhau để hạn chế ghép nhầm caption xa nhau.
- Giữ giới hạn từ khóa LIKE, SHARE, SUBSCRIBE và các biến thể tiếng Việt; không phân loại cảnh phim, không phân tích lời nói/âm thanh.

## Workflow
- Ảnh bằng chứng và timestamp tiếp tục gắn với lần OCR thực sự tạo ra kết quả.
- Kết quả vẫn là gợi ý để người dùng kiểm tra và duyệt thủ công; không tự động cắt.
- Giữ Pause/Resume, Dừng, Quét tiếp và cache.
