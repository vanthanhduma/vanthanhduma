# Kiểm thử — Góc Review Phim Video Studio v1.5.4.0

## Kết quả tự động

- Full suite: **43 passed, 21 subtests passed**.
- Thời gian full suite trong môi trường dựng: 25.51 giây.
- `python -m py_compile *.py tests/*.py`: PASS.
- ZIP integrity (`ZipFile.testzip()`): kiểm tra sau khi đóng gói.

## Phạm vi đã kiểm tra

- OCR tiếng Anh và tiếng Việt trên khung hình video tổng hợp.
- Nhận diện các cụm Subscribe/Subscribed/Subscribe Now và các câu tiếng Việt như Đăng ký kênh, Nhớ đăng ký nhé, Hãy đăng ký, Đừng quên đăng ký, Đăng ký ngay.
- Từ chối một số nội dung không thuộc CTA, ví dụ “Đăng ký tài khoản”, nút đỏ trơn và chữ LIKE.
- Nhận diện heuristic nút Subscribe dạng đồ họa: nút đỏ có biểu tượng tam giác phát màu sáng.
- Ghi nhận biến đổi hình ảnh trong vùng CTA như một dấu hiệu animation để người dùng kiểm tra.
- Quét hai lượt, tinh chỉnh vùng nghi vấn, hiển thị kết quả trực tiếp, Pause/Resume, Cancel khi đang Pause.
- Chọn khoảng CTA và cắt/xuất video; giữ nguyên các kiểm thử Downloader, timeline seek, workspace, project controls.

## Giới hạn kiểm thử

- Đây là kiểm thử source và xử lý video tổng hợp, không phải benchmark độ chính xác trên toàn bộ thư viện video thực tế.
- Nhận diện đồ họa không dùng mô hình AI thị giác chuyên dụng. Heuristic hiện tại tập trung vào nút đỏ có glyph tam giác; kết quả luôn là ứng viên cần người dùng duyệt.
- Dấu hiệu animation dựa trên biến đổi hình ảnh tại vùng đã phát hiện, không phải phân loại chuyển động bằng mô hình học sâu.
- Không phân tích âm thanh hoặc lời nói.
- Môi trường dựng không có PySide6, vì vậy **chưa chạy được GUI Qt thực tế trên Windows**. Cần nghiệm thu giao diện, DPI và Tesseract engine trên máy Windows sau khi cài.

## OCR và tài nguyên

- Trong môi trường dựng, Tesseract 5.5.0 với `eng` và `vie` đã chạy được.
- Gói FULL kèm `assets/tessdata/eng.traineddata` và `assets/tessdata/vie.traineddata`.
- Tesseract executable vẫn cần được cài trên Windows; có thể dùng `CAI_TESSERACT_OCR.bat` (winget) nếu máy chưa có.

## Bảo toàn chức năng

- Không đổi project schema.
- Giữ Mask, Branding, Downloader, Batch Processing, project save/open, Export/QC và Precise Timeline Seek.
- Không tự động cắt CTA; chỉ các khoảng người dùng chọn mới được đưa vào luồng cắt.
