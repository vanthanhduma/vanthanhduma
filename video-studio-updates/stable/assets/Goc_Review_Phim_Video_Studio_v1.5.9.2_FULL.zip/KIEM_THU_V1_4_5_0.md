# KIỂM THỬ v1.4.5.0 — CTA Detector Image Only + Selected CTA Cut

Ngày kiểm thử: 12/11/2026

## 1. Compile và regression

| Ca kiểm thử | Kết quả |
|---|---|
| `py_compile` app.py | PASS |
| `py_compile` qt_app.py | PASS |
| `py_compile` engine_worker.py | PASS |
| `py_compile` cta_detector.py | PASS |
| `py_compile` tests/test_cta_detector.py | PASS |
| Downloader URL / format / cancellation / progress regressions | PASS — 8/8 |
| CTA image-region tests | PASS — 5/5 |

## 2. CTA detector

| Ca kiểm thử | Kết quả |
|---|---|
| Nhận diện nút đỏ kiểu Subscribe trên frame synthetic | PASS |
| Không tạo candidate với frame nền phẳng, không có nút | PASS |
| Quét video synthetic 5 giây, nút xuất hiện từ giây 1 đến 3.5 | PASS — gom thành một khoảng CTA, có nhiều mẫu |
| Bố cục end-screen synthetic với hai panel chữ nhật | PASS — phát hiện một vùng end-screen nghi vấn |
| Progress callback và giới hạn số mẫu | PASS |
| Hủy scan bằng event | PASS — ném `CTAScanCancelled` đúng yêu cầu |

## 3. Giao diện CTA Detector (Tk processing worker)

Chạy bằng Xvfb với synthetic clip:
- Dialog CTA mở ở kích thước 1120×740: PASS.
- Quét nền hoàn tất, tạo 1 row candidate: PASS.
- Thumbnail và bounding box được vẽ: PASS.
- Chọn candidate bật nút cắt: PASS.
- Chỉnh mốc In/Out và kích hoạt lệnh cắt (export mocked): PASS — chỉ khoảng đã chọn được chuyển vào `excluded_ranges`.

Qt shell không thể chạy trong môi trường build này do chưa có PySide6; compile Python và route command đã được kiểm tra tĩnh. Cần nghiệm thu native window / DPI trên Windows.

## 4. Cắt CTA và đồng bộ hình/tiếng

Nguồn synthetic: MP4 H.264 + AAC, 5.0 giây, 640×360, 25 FPS.

Khoảng bỏ thử: 1.0–3.0 giây.

| Ca kiểm thử | Kết quả |
|---|---|
| Encode qua pipeline `encode_video` hiện tại với `excluded_ranges` | PASS |
| Thời lượng đầu ra | PASS — 3.0 giây |
| Video stream | PASS — H.264, 3.0 giây |
| Audio stream | PASS — AAC, 3.0 giây |
| Video nguồn | PASS — giữ nguyên, xuất sang file mới |

## 5. Tích hợp và tương thích

- CTA Detector là mục riêng trên thanh bên trái, không dùng chung danh sách candidate của Watermark Detector.
- CTA time ranges chỉ được thêm vào danh sách bỏ sau khi người dùng chọn và xác nhận cắt.
- Pipeline export sử dụng cơ chế bỏ khoảng theo frame-index đã có, cắt đồng bộ audio/video.
- Project schema không thay đổi; các `excluded_ranges` hiện có tiếp tục được giữ.
- Khi xuất, các khoảng bỏ khác đang có trong dự án cũng tiếp tục được áp dụng.
- Không thay đổi Smart Mask, branding, batch, QC, downloader hoặc detector hiện tại.

## 6. Giới hạn

CTA detector hiện là heuristic thị giác dựa trên khối màu bão hòa và hình chữ nhật, không phải OCR/AI ngữ nghĩa. Có thể bỏ sót CTA đơn sắc, trong suốt, kích thước rất nhỏ hoặc chuyển động phức tạp; có thể đề xuất nhầm vật thể màu hình chữ nhật trong cảnh phim. Người dùng phải xem thumbnail và duyệt thủ công.
