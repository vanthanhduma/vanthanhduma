# Kiểm thử v1.5.1.0

Ngày build: 2026-11-13

## Đã chạy
- `python -m py_compile app.py qt_app.py engine_worker.py`: PASS.
- `python -m pytest -q -p no:cacheprovider tests`: **20 passed, 14 subtests passed**.
- Regression CTA detector trên synthetic frames/video: PASS.
- Regression cắt khoảng CTA, đồng bộ audio/video và xuất MP4: PASS.
- Regression downloader: PASS.
- Regression các hợp đồng giao diện: PASS — tách trang Biên tập/Mask, CTA là tab Timeline, Before/After dùng preview lớn, sidebar không có Mẹo nhanh.
- Kiểm tra package ZIP, payload SHA-256 và manifest: thực hiện sau khi đóng gói.

## Chưa thể xác nhận trong môi trường build
- Không có PySide6 trong Python runtime và không thể tải package do môi trường không có kết nối mạng. Vì vậy không chạy được GUI Qt thật, không chụp được screenshot runtime và không đo DPI/layout trên Windows ở đây.
- Cần nghiệm thu trên máy Windows: mở app sau update; chuyển Biên tập ↔ Mask; đổi tab Phân cảnh ↔ CTA; quét và chọn khoảng CTA; tạo so sánh Before/After ở kích thước lớn; xác nhận Engine/Auto Save ở góc trái dưới.

## Phạm vi bảo toàn
Không chỉnh sửa `engine_worker.py`, `cta_detector.py`, `download_engine.py`, schema dự án hoặc logic xuất video. Thay đổi tập trung ở tổ chức UI `qt_app.py`, đồng bộ version `app.py`, tài liệu và tests.
