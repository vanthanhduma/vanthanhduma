# Thiết kế Auto Updater — hỏi trước khi cài

**Dự án:** Góc Review Phim Video Studio  
**Baseline tham chiếu:** v1.5.4.0  
**Nền tảng mục tiêu:** Windows 10/11  
**Chế độ đã chọn:** tự kiểm tra phiên bản mới, hỏi người dùng trước khi tải/cài.

## 1. Mục tiêu và nguyên tắc

1. Ứng dụng tự kiểm tra bản Stable mới khi khởi động, nhưng không chặn giao diện và không tự cài.
2. Chỉ tải gói cập nhật sau khi người dùng chọn **Cập nhật ngay**.
3. Không cập nhật khi đang quét CTA, xử lý Mask, Batch, tải video hoặc xuất video.
4. Không ghi đè dự án, video nguồn, output, Auto Save, settings, preset, cache OCR hoặc môi trường `.venv`.
5. Xác minh manifest, chữ ký và SHA-256 trước khi thay bất kỳ file nào.
6. Sao lưu phiên bản hiện tại; nếu cập nhật hoặc smoke test thất bại thì tự rollback.
7. Không yêu cầu PowerShell. Updater chạy bằng Python helper và Windows launcher hiện có.
8. Giữ nguyên Project Schema trừ khi một release có migration rõ ràng, có backup và có kiểm tra tương thích.

## 2. Trải nghiệm người dùng

### Khi mở ứng dụng

- Sau khi cửa sổ chính hiển thị, một worker nền kiểm tra manifest (không chạy trên UI thread).
- Mặc định kiểm tra tối đa một lần trong 24 giờ; có thể kiểm tra thủ công từ menu ứng dụng / mục Giới thiệu.
- Nếu không có mạng hoặc GitHub tạm lỗi: giữ nguyên ứng dụng, không hiện lỗi gây phiền; ghi log và thử lại ở lần mở sau.
- Dùng ETag / If-None-Match hoặc Last-Modified để giảm request.
- Không thông báo nếu đang dùng bản mới nhất, bản cài mới hơn bản trên server, hoặc người dùng đã chọn bỏ qua đúng version đó.

### Khi có bản mới

Thông báo nhỏ trong ứng dụng, hiển thị:
- Phiên bản đang dùng và phiên bản mới.
- Ngày phát hành, nội dung thay đổi, dung lượng tải.
- Yêu cầu khởi động lại nếu có.
- Nút **Cập nhật ngay**, **Để sau**, **Bỏ qua phiên bản này**.

Quy tắc:
- **Để sau:** nhắc lại ở lần mở tiếp theo, không lặp thông báo trong cùng phiên làm việc.
- **Bỏ qua phiên bản này:** lưu version bị bỏ qua trong user settings; chỉ hiện lại khi có version cao hơn.
- **Cập nhật ngay:** mới bắt đầu tải gói cập nhật. Không thay file khi người dùng còn đang làm việc.

## 3. Kiến trúc đề xuất

Tách updater thành các thành phần nhỏ, không trộn vào video processing engine:

- `updater/update_checker.py`: kiểm tra manifest, phiên bản, ETag, channel.
- `updater/manifest.py`: parse và validate schema/URL/version/compatibility.
- `updater/downloader.py`: tải asset vào thư mục staging, hỗ trợ resume và progress.
- `updater/verifier.py`: xác minh chữ ký số, SHA-256, kích thước và danh sách file.
- `updater/apply_helper.py`: helper process độc lập thay file sau khi app thoát.
- `updater/rollback.py`: phục hồi backup nếu lỗi.
- `updater/update_state.py`: quản lý trạng thái và nhật ký cập nhật.
- `updates/latest.json`: manifest phát hành Stable.
- `updates/keys/update-public-key.pem`: public key xác minh chữ ký; private key chỉ lưu offline, không đưa vào Git.

Không dùng `git pull` trực tiếp trong thư mục cài đặt của người dùng. Phát hành gói ZIP/installer đã build qua GitHub Releases; không cập nhật bằng cách tải các file rời tùy tiện.

## 4. Nguồn phát hành và xác thực

Ưu tiên GitHub Releases trong repository riêng:
- Release tag dạng `v1.5.5.0`, `v1.6.0.0`.
- Asset gồm gói cập nhật, manifest JSON và chữ ký detached.
- Repo private: xác thực một lần bằng OAuth/device flow hoặc fine-grained credential chỉ có quyền đọc nội dung repository; token lưu trong Windows Credential Manager, không ghi vào source, log hoặc project.
- Repo public: có thể tải manifest/asset qua HTTPS mà không cần credential.

Manifest phải có tối thiểu:
- `schema_version`, `app_id`, `channel`, `version`, `minimum_updater_version`.
- `min_supported_version`, `published_at`, `release_notes_url`.
- `asset_url`, `asset_size`, `asset_sha256`.
- `signature_url`, `signature_algorithm`.
- `files[]`: relative path, size, SHA-256, action (replace/delete).
- `preserve_paths[]`: paths tuyệt đối không được ghi đè/xóa.
- `project_schema_min/max` hoặc migration declaration nếu release thay đổi schema.

Bảo mật:
- Xác minh chữ ký Ed25519 của manifest bằng public key được đóng gói sẵn trong app.
- Sau đó kiểm tra SHA-256 và kích thước ZIP, rồi kiểm tra hash từng file sau giải nén.
- Chỉ cho phép đường dẫn tương đối nằm trong thư mục ứng dụng; từ chối path traversal, symlink không hợp lệ và file ngoài allowlist.
- Không chạy script cài đặt có nguồn gốc không xác minh.
- Nếu chữ ký/hash không hợp lệ, dừng cập nhật và giữ nguyên bản đang cài.

## 5. Quy trình cập nhật

1. **CHECKING:** lấy manifest trong worker nền.
2. **AVAILABLE:** so sánh semantic version và điều kiện tương thích.
3. **WAITING_FOR_USER:** hiện thông báo chọn Cập nhật ngay / Để sau / Bỏ qua.
4. **DOWNLOADING:** chỉ tải sau khi người dùng chọn cập nhật; hiển thị tiến độ và tốc độ.
5. **VERIFYING:** xác minh chữ ký, SHA-256, dung lượng, file list và đường dẫn.
6. **WAITING_FOR_IDLE:** nếu có tác vụ đang chạy thì đợi tác vụ kết thúc; không giết ngang export/quét.
7. **BACKUP:** sao lưu các file thuộc app hiện tại vào `backups/<old-version>_<timestamp>/`.
8. **APPLYING:** đóng ứng dụng có kiểm soát; chạy helper Python độc lập; thay file theo manifest.
9. **SMOKE_TEST:** compile/import các module chính và chạy health check nhẹ.
10. **COMPLETE:** ghi version mới, khởi chạy ứng dụng, hiển thị thành công.
11. **ROLLBACK:** nếu bất cứ bước áp dụng/kiểm tra nào thất bại, phục hồi backup và khởi động lại bản cũ.

App không tự cập nhật khi đang chạy job. Nếu app bị đóng trong lúc tải, staging có thể tiếp tục hoặc tải lại ở lần sau; nếu bị đóng trong lúc apply, helper dùng transaction journal để hoàn tất hoặc rollback.

## 6. Những dữ liệu phải được giữ nguyên

Không đưa các đường dẫn sau vào danh sách thay thế/xóa:
- `.venv/` và Python runtime.
- `projects/`, các file `.grproj`, autosave và project backup.
- `user_settings.json`, cấu hình người dùng, preset cá nhân.
- `assets/user/`, logo/branding do người dùng thêm.
- `downloads/`, `renders/`, video nguồn và file xuất.
- Cache/model OCR, log và thư mục staging/backup.

Danh sách chính xác cần được đối chiếu với cấu trúc source thực tế trước khi triển khai. Mặc định: cập nhật theo allowlist file ứng dụng, không dùng thao tác xóa thư mục tổng quát.

Giữ tối thiểu 3 bản backup gần nhất hoặc giới hạn theo dung lượng. Không tự xóa backup nếu chưa xác định bản hiện tại hoạt động ổn định.

## 7. Tương thích và migration

- Updater từ chối downgrade.
- Release có thể đặt `min_supported_version` để yêu cầu cài FULL khi phiên bản quá cũ.
- Không tự migrate project schema nếu chưa có migration function và test fixture.
- Migration phải backup project trước, chạy trên bản sao, validate đọc lại, rồi mới commit.
- Nếu không tương thích runtime hoặc thiếu dung lượng, hiển thị lý do và không thay đổi bản hiện tại.

## 8. Log và hỗ trợ lỗi

Lưu log cục bộ trong `logs/updater/`:
- thời điểm, version hiện tại/mới, trạng thái từng bước;
- asset size, SHA-256 (không ghi token/credential);
- lỗi mạng, verify, apply, rollback;
- kết quả smoke test.

Không log access token, mật khẩu, cookie hoặc đường dẫn có thể chứa thông tin nhạy cảm.

## 9. Kiểm thử bắt buộc trước khi bật cho người dùng

- Không có update / update mới / version bị skip / downgrade.
- GitHub offline, timeout, HTTP 401/403/404/429/5xx.
- ETag 304 và manifest malformed.
- Chữ ký sai, SHA sai, ZIP hỏng, file thiếu/thừa.
- Zip Slip/path traversal, duplicate path, symlink và file path không hợp lệ.
- Tải bị gián đoạn, resume download, thiếu dung lượng đĩa.
- Người dùng bấm Để sau/Bỏ qua.
- Đang export/Batch/CTA scan: không được đóng app hoặc thay file.
- Helper không khởi động, app không thoát, file bị lock.
- Smoke test thất bại: rollback đầy đủ.
- Sau update: mở project cũ, kiểm tra Auto Save, Mask, CTA, Downloader, Branding, Batch, Export và QC.
- Không đổi project schema nếu release không khai báo migration.
- Kiểm tra Windows 10/11, DPI phổ biến, đường dẫn có dấu/space và quyền user thường.

## 10. Lộ trình triển khai

**Phase A — Release foundation**
- Đưa source thật của Video Studio vào repo.
- Chuẩn hóa version, README, changelog, test và cách build FULL/UPDATE.
- Tạo GitHub Releases và manifest ký số cho bản thử nghiệm.

**Phase B — Read-only update checker**
- Thêm kiểm tra nền và hộp thoại hỏi người dùng.
- Chỉ thông báo version/changelog, chưa tự thay file.
- Test repo private authentication và lỗi mạng.

**Phase C — Download + verify**
- Tải sau khi người dùng đồng ý.
- Xác minh manifest signature, ZIP hash và file list.
- Chưa áp dụng khi app còn chạy.

**Phase D — Apply helper + rollback**
- Python helper độc lập, transaction journal, backup, atomic replace.
- Health check sau khi cập nhật.
- Test lỗi giả lập và khôi phục.

**Phase E — Stable rollout**
- Chỉ bật kênh Stable sau khi test trên Windows thật.
- Mặc định vẫn hỏi trước khi cài; không chuyển sang auto-install nếu người dùng chưa đổi lựa chọn.

## 11. Tiêu chí hoàn thành

Updater chỉ được coi là hoàn tất khi:
- Người dùng mở app và nhận được thông báo update mới mà UI không bị treo.
- Không tải/cài nếu người dùng chưa đồng ý.
- Không tác động khi video processing đang chạy.
- Hash/chữ ký được xác minh trước khi ghi file.
- Dự án/cấu hình/video/output không bị thay đổi.
- Update thành công có thể mở app và project cũ.
- Update thất bại có thể rollback về bản hoạt động.
- Tất cả ca kiểm thử nêu trên chạy trên Windows thật.
