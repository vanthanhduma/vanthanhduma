# Release workflow v1.5.5.7+

## Mục tiêu

Mỗi release mới tạo ra một FULL bootstrap và một UPDATE incremental. Người dùng không phải tải ZIP thủ công: app đọc Stable feed và xử lý toàn bộ từ nút **Kiểm tra & cập nhật**.

## Build local

Từ thư mục source:

```powershell
python tools/build_full.py --root . --version 1.5.5.7 --base-version 1.5.5.6 --output dist
python tools/build_update.py --root . --version 1.5.5.7 --base-version 1.5.5.6 --output dist\Goc_Review_Phim_Video_Studio_v1.5.5.7_UPDATE.zip --files PHIEN_BAN.txt README.md RELEASE_NOTES_V1_5_5_7.md qt_app.py cta_detector.py updater/core.py updater/apply_helper.py
```

`build_update.py` bắt buộc có PHIEN_BAN.txt và kiểm tra version chính xác. Manifest UPDATE ghi `package_type: UPDATE` và SHA-256 từng file. FULL không đóng gói .venv hoặc dữ liệu người dùng.

## Publish

Feed Stable là file `video-studio-updates/stable/latest.json` trong repository public `vanthanhduma/vanthanhduma`. Asset ZIP phải nằm trong `video-studio-updates/stable/assets/`. Manifest mới nên dùng `trust_mode: https-sha256-v1`, URL HTTPS Raw GitHub cố định, size và SHA-256 đúng artifact.

Commit feed phải cập nhật manifest và asset theo cùng một tree/commit. Sau publish, fetch lại feed và asset, so sánh size/hash trước khi thông báo phát hành.

## Chính sách an toàn

Không thay toàn bộ thư mục cài đặt. Chỉ replace path có trong manifest; giữ .venv, projects, autosave, settings, branding, downloads, renders, video, output, logs và backups. Nếu base version không khớp, hash không khớp, redirect sai host/path hoặc health-check lỗi, updater phải giữ bản cũ hoặc rollback tự động.
