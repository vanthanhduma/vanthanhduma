# Trạng thái đồng bộ — Góc Review Phim Video Studio v1.5.6.7

**Ngày đồng bộ:** 14/11/2026  
**Source:** `vanthanhduma/Goc-Review-Phim-Video-Studio`, nhánh `main`  
**Stable feed:** `vanthanhduma/vanthanhduma/video-studio-updates/stable/latest.json`  
**Phiên bản Stable:** **v1.5.6.7**

## Artifact Stable

- Loại gói: `UPDATE`
- Tên: `Goc_Review_Phim_Video_Studio_v1.5.6.7_UPDATE.zip`
- Dung lượng: `147012` bytes
- SHA-256: `aef62f177d83cd0862e8f764bf72c8dd53b2dc580bd6b1139206cab39955d343`
- `base_version`: `1.5.5.10`
- Danh sách phiên bản nền tương thích được lấy từ manifest Stable.

## Nội dung v1.5.6.7

- Thêm Tạm dừng / Tiếp tục cho Overlay Detector; giữ kết quả đã phát hiện khi tạm dừng.
- Giữ thumbnail, danh sách ứng viên và thao tác đưa vùng được chọn vào Mask trong workspace.
- Overlay vẫn xử lý theo vùng ảnh; CTA vẫn xử lý theo khoảng thời gian.
- Không thay đổi dữ liệu project, cài đặt hay môi trường xử lý.

## Đồng bộ source

Đã thay các file runtime theo payload đã phát hành:

- `qt_app.py`
- `engine_worker.py`
- `app.py`
- `PHIEN_BAN.txt`
- `RELEASE_NOTES_V1_5_6_7.md`

Đồng thời cập nhật README, test contract version và tài liệu trạng thái updater.

## Kiểm chứng payload

- SHA-256 ZIP khớp manifest Stable.
- SHA-256 và kích thước của **5/5 file payload** khớp manifest.
- Payload gồm đúng ba file runtime, file phiên bản và release notes.

## Kiểm thử còn cần thực hiện

Việc đồng bộ GitHub không thay thế kiểm thử runtime. Cần chạy test suite và nghiệm thu GUI trên Windows sau khi cập nhật; đặc biệt xác nhận Overlay Pause/Resume thực tế, giữ nguyên candidate, chọn vùng và đưa vùng đã duyệt vào Mask.
