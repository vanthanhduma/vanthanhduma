# Đặc tả giao diện và trải nghiệm In-App Updater

**Dự án:** Góc Review Phim Video Studio  
**Baseline tham chiếu:** v1.5.4.0  
**Nền tảng:** Windows 10/11  
**Chế độ:** Tự kiểm tra; chỉ tải/cài sau khi người dùng bấm **Cập nhật ngay**.

Tài liệu này bổ sung cho [UPDATER_DESIGN.md](UPDATER_DESIGN.md). Đây là đặc tả thiết kế, chưa phải mã nguồn updater đã được tích hợp.

## 1. Mục tiêu UX

- Người dùng cập nhật ngay trong cửa sổ chính, không phải mở GitHub, tải ZIP, giải nén hoặc chép file.
- Một lần bấm **Cập nhật ngay** bắt đầu toàn bộ quy trình: tải, xác minh, chờ tác vụ an toàn, áp dụng, kiểm tra và khởi động lại.
- Không làm gián đoạn công việc hoặc tự ý đóng ứng dụng khi tác vụ video đang chạy.
- Luôn có trạng thái rõ ràng và khả năng hủy trước giai đoạn thay file.
- Không chiếm không gian Workspace bằng một trang Settings/Updater độc lập.

## 2. Vị trí trong Workspace

### 2.1 Điểm truy cập chính

Đặt mục **Cập nhật** nhỏ gọn trên thanh tiêu đề chính, cạnh thông tin phiên bản hoặc menu ứng dụng:

- Bình thường: `v1.x.x.x · Kiểm tra cập nhật`.
- Có bản mới: nhãn `Có bản mới` kèm chấm trạng thái; không dùng popup liên tục.
- Đang tải/chờ: nhãn trạng thái ngắn `Đang cập nhật…`.
- Không đặt updater vào vùng trạng thái góc trái dưới. Vùng đó tiếp tục dành cho Engine, Auto Save và tác vụ nền.
- Không tạo cửa sổ updater riêng. Bảng cập nhật là dialog/modal nằm trong cửa sổ chính, dùng cùng theme navy/teal/cyan.

### 2.2 Trung tâm cập nhật

Bảng cập nhật có các vùng:

1. **Header:** Trung tâm cập nhật + trạng thái.
2. **Version comparison:** Phiên bản đang cài và phiên bản Stable mới.
3. **Release summary:** Ngày phát hành, nội dung thay đổi, dung lượng thực tế, yêu cầu khởi động lại nếu có.
4. **Progress area:** Thanh tiến trình, MB đã tải/tổng dung lượng, tốc độ, bước hiện tại.
5. **Action area:** Nút chính thay đổi theo state; nút đóng/để sau/hủy chỉ xuất hiện ở trạng thái an toàn.

Không hardcode version, changelog hoặc dung lượng mẫu. Tất cả dữ liệu phải đến từ manifest/release đã xác thực.

## 3. Các trạng thái giao diện

| State | Hiển thị | Hành động |
|---|---|---|
| CURRENT | Đang dùng phiên bản mới nhất | Kiểm tra lại |
| AVAILABLE | Có phiên bản mới, so sánh version/changelog/size | Cập nhật ngay; Để sau; Bỏ qua phiên bản |
| DOWNLOADING | Tiến trình, tốc độ, dung lượng, phần trăm | Hủy tải |
| VERIFYING | Đang xác minh gói cập nhật | Không cho đóng tiến trình xác minh |
| WAITING_FOR_IDLE | Đã tải và xác minh; đang chờ tác vụ hiện tại hoàn tất | Hủy cập nhật; tiếp tục làm việc |
| READY_TO_APPLY | Tất cả tác vụ đã dừng an toàn | Tự chuyển sang apply theo lựa chọn đã xác nhận |
| APPLYING | Đang sao lưu và thay file | Không cho hủy giữa transaction |
| CHECKING_NEW_VERSION | Đang chạy health check sau cập nhật | Chờ kết quả |
| COMPLETE | Đã cập nhật thành công, ứng dụng đã mở lại | Xem phiên bản |
| ROLLED_BACK | Cập nhật lỗi, đã khôi phục bản trước | Xem log / thử lại sau |
| ERROR | Lỗi trước khi thay file | Thử lại; đóng bảng |

## 4. Luồng tương tác một lần bấm

1. Ứng dụng hiển thị cửa sổ chính hoàn chỉnh.
2. Worker nền kiểm tra manifest Stable (tối đa một lần/24 giờ, trừ khi người dùng kiểm tra thủ công).
3. Khi có bản mới, nút **Cập nhật** hiện trạng thái mới. Người dùng mở Trung tâm cập nhật để xem thông tin.
4. Người dùng bấm **Cập nhật ngay** một lần. Đây là sự đồng ý tải, xác minh, áp dụng và tự khởi động lại khi an toàn.
5. Downloader tải vào staging và thể hiện tiến độ.
6. Verifier xác minh chữ ký manifest, SHA-256, kích thước, danh sách file, đường dẫn và compatibility. Nếu bất kỳ kiểm tra nào thất bại, không thay file.
7. Nếu đang có tác vụ chạy, chuyển sang WAITING_FOR_IDLE. Tác vụ đang chạy được phép hoàn tất; không kill process, không cắt ngang export, không tự xóa candidate hoặc project.
8. Khi toàn bộ tác vụ đã idle, app ghi transaction journal, tạo backup rồi yêu cầu launcher/helper độc lập áp dụng gói.
9. Helper chờ process chính thoát hoàn toàn, thay các file allowlist, ghi journal từng bước và chạy health check.
10. Nếu health check PASS, ghi version mới và khởi chạy lại ứng dụng. Nếu FAIL, rollback về backup và khởi chạy bản cũ.

**Quy tắc hủy:** Có thể hủy ở DOWNLOADING, VERIFYING (sau khi tác vụ hiện tại kết thúc) hoặc WAITING_FOR_IDLE trước khi bắt đầu apply. Một khi transaction thay file đã bắt đầu, không cho hủy thủ công; helper phải hoàn tất hoặc rollback.

## 5. Kiểm tra tác vụ đang chạy

Updater cần một giao diện trạng thái thống nhất từ task manager của ứng dụng. Chỉ coi ứng dụng idle khi không còn bất kỳ job nào thuộc các nhóm:

- CTA scan (cả lượt 1/lượt 2, pause/resume vẫn được tính là job đang tồn tại).
- Mask processing / Before-After.
- Batch processing.
- Downloader.
- Export / render / QC đang phụ thuộc vào file đầu ra.
- Các tác vụ nền có thể đang giữ lock hoặc ghi dữ liệu.

Pause không có nghĩa là idle. Chỉ trạng thái hoàn tất, dừng chủ động an toàn hoặc lỗi đã giải phóng tài nguyên mới được tính idle. Trạng thái WAITING_FOR_IDLE phải hiển thị tác vụ nào còn chạy.

## 6. Chính sách phiên bản

- Kênh phát hành mặc định: Stable.
- Chỉ nhận version mới hơn theo Semantic Versioning; không downgrade.
- Nếu app quá cũ hoặc không tương thích với incremental update, yêu cầu FULL package qua cùng updater flow.
- Changelog và metadata hiển thị phải lấy từ release đã xác minh.
- Tùy chọn bỏ qua chỉ bỏ qua đúng phiên bản được chọn; khi có phiên bản cao hơn, thông báo lại.
- Kiểm tra tự động không tải bất cứ asset nào. Chỉ gọi download sau thao tác **Cập nhật ngay**.

## 7. Dữ liệu và an toàn

Updater chỉ được thay thế các file chương trình nằm trong allowlist phát hành. Không copy đè toàn bộ thư mục cài đặt.

Mặc định phải giữ nguyên:
- `.venv/`, Python runtime và môi trường cài đặt.
- `projects/`, `.grproj`, autosave và project backups.
- User settings, preset cá nhân và cấu hình.
- `assets/user/`, logo/branding do người dùng thêm.
- `downloads/`, `renders/`, video nguồn và file xuất.
- OCR cache/model, log, staging và backups.

Các path trên là chính sách bảo vệ ở mức thiết kế; danh sách cuối cùng phải được đối chiếu source/package thực tế trước khi triển khai. Manifest phải khai báo rõ file được replace/delete. Mặc định từ chối path không được liệt kê, path traversal, duplicate path, symlink không an toàn hoặc file vượt khỏi app root.

## 8. Lỗi và phản hồi người dùng

- Offline, timeout, rate limit: giữ nguyên app, nêu trạng thái kiểm tra thất bại nếu người dùng chủ động mở Trung tâm cập nhật; không popup lỗi lúc khởi động.
- Signature/hash/ZIP/path sai: từ chối apply và giữ bản cũ nguyên trạng.
- Không đủ dung lượng: báo dung lượng cần và dung lượng còn trống; không xóa project hay output để lấy chỗ.
- Process không thoát/file bị lock: không cưỡng bức kill tác vụ; dừng apply và giữ bản hiện tại.
- Apply/health check lỗi: rollback tự động; hiển thị phiên bản đang chạy và vị trí log.
- App khởi động lại nhưng chưa xác nhận khỏe: dùng transaction marker để lần khởi động kế tiếp có thể hoàn tất health check hoặc rollback.

## 9. Tiêu chí nghiệm thu UX

- Người dùng tìm thấy mục Cập nhật trong Workspace mà không phải đi vào Settings.
- Một lần bấm Cập nhật ngay khởi động chuỗi tải → xác minh → chờ idle → apply → restart.
- Không tự tải/cài trước khi người dùng đồng ý.
- Có tiến trình và trạng thái chính xác trong từng bước.
- Có thể tiếp tục sử dụng ứng dụng khi updater đang chờ job kết thúc.
- Không gián đoạn CTA, Mask, Batch, Downloader, Export hoặc QC.
- Bảo toàn project, autosave, settings, preset, branding và dữ liệu đầu ra.
- Rollback được kiểm thử bằng cách cố ý làm health check thất bại.
- Nghiệm thu cuối cùng trên Windows 10/11 với đường dẫn có dấu, có khoảng trắng, DPI khác nhau và tài khoản user thường.

## 10. Thứ tự triển khai

1. Bootstrap source thật vào repository và chuẩn hóa packaging/version.
2. Xây task-idle interface trong ứng dụng để updater biết lúc nào an toàn.
3. Tích hợp điểm truy cập và Trung tâm cập nhật (read-only checker trước).
4. Tích hợp download + manifest signature/hash validation.
5. Xây helper riêng, transaction journal, backup, apply và rollback.
6. Kiểm thử lỗi giả lập, bảo toàn dữ liệu và nghiệm thu Windows thật.
7. Chỉ bật Stable updater sau khi toàn bộ tiêu chí đạt.

**Trạng thái hiện tại:** Đây là thiết kế UX/luồng hoạt động. Chưa có updater code trong source ứng dụng; repository cần source thật trước khi triển khai và kiểm thử end-to-end.
