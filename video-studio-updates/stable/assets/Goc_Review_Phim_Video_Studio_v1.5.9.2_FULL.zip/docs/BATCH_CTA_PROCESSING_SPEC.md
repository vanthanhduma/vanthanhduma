# Batch CTA Processing — Technical Specification

Target branch: `feature/batch-cta-processing`
Base: v1.5.8.0 (`33861fd`)

## Confirmed product behavior
- Batch Processing becomes a CTA scan-and-project-creation queue, not a multi-video export workflow.
- Add multiple video files; one output root is selected once.
- One video is scanned at a time, using the existing CTA Detector engine and its current sampling/recognition behavior.
- When scanning finishes, save an independent `.grproj` project for that source video, including the CTA candidate data and thumbnail/cache assets supported by the existing project schema.
- Keep source videos in place; do not duplicate multi-gigabyte source media into each project.
- Never approve or cut CTA automatically. The user opens each project and manually reviews candidates, chooses ranges, and exports.
- After the queue finishes, navigate back to the main workspace.
- When the application closes during a batch, cancel the active scan safely, persist queue state, and stop without prompting. On next launch, offer to resume.
- Completed projects must not be scanned again during resume. An interrupted active video is restarted from its beginning unless the detector exposes a durable, validated checkpoint.

## Output layout
```
<chosen-output>/
  <safe-video-name>/
    <safe-video-name>.grproj
    CTA/                 # only if existing project schema stores CTA assets here
    Thumbnails/          # only if existing project schema stores thumbnails here
  Batch_Queue/
    queue.json
```
- Resolve duplicate stems deterministically with suffixes (`_2`, `_3`, ...).
- Persist absolute source paths and project paths; validate source existence before starting/resuming.
- Write queue JSON atomically (temporary file + fsync + replace).
- Queue states: queued, scanning, saving, completed, failed, skipped.
- Only one job may be in scanning/saving state at any time.
- Closing while scanning sets cancellation, waits for the detector thread to stop, then writes the queue state. Completed jobs remain completed; active work returns to queued.

## Integration plan
1. Replace the existing Qt Batch page (currently an encode/export queue) with the CTA queue interface. Preserve the separate video merge workflow.
2. Add a Qt worker command dedicated to batch CTA; do not reuse the legacy Tk export batch.
3. Reuse the existing CTA detector implementation and project schema v4. Add a safe project creation path that writes a project for an arbitrary source without changing the user's currently open project or CTA table.
4. Serialize CTA candidates in the format already consumed by the existing CTA cache/project loader; include preview thumbnails using existing project asset helpers.
5. Persist queue state after each transition and progress checkpoint; restore/resume after restart.
6. On completion, send a UI event that navigates to the main workspace. On close, cancel and join/await active detector work before process teardown.
7. Add tests for queue persistence, duplicate video paths, duplicate filenames, interrupted-job recovery, completed-job skip, sequential-only enforcement, invalid/missing sources, and safe shutdown.

## Important compatibility boundary
The existing Qt page currently sends `batch_start` to the legacy engine, whose implementation performs video encoding with mask/branding and QC. This must be replaced for the Qt Batch CTA workflow without silently changing the independent merge/export features. Do not remove or rewrite the legacy export engine until all call sites and compatibility expectations are verified.
