# Góc Review Phim Video Studio v1.5.6.36

## CTA Detector — ảnh bằng chứng trực tiếp
- Tạo ảnh JPEG từ chính khung hình đã được đọc để OCR, khoanh vùng phần chữ CTA và gửi kèm từng ứng viên ngay khi phát hiện.
- Bảng kết quả và khung xem lớn cập nhật ảnh bằng chứng trong lúc quét; không cần chạy thêm một tiến trình FFmpeg cho mỗi ứng viên mới.
- Ảnh mẫu được chọn theo lần nhận diện OCR có điểm cao nhất của ứng viên, đồng thời mốc thời gian ảnh được giữ chính xác.
- Kết quả cũ chưa có ảnh vẫn dùng cơ chế trích xuất dự phòng sau khi quét.

## An toàn khi duyệt và cắt
- Ứng viên có độ tin cậy OCR dưới 50/100 được tô cảnh báo và yêu cầu xác nhận thêm khi tick chọn cắt.
- Người dùng vẫn phải tự chọn khoảng CTA; không tự động cắt theo kết quả nhận diện.
- Lỗi tạo ảnh của một ứng viên được ghi riêng, không làm hỏng toàn bộ lượt quét hoặc các ứng viên khác.

## Giao diện
- Rút gọn tiêu đề cột để không bị cắt chữ ở vùng bảng hẹp.
- Bỏ nhãn đơn vị “phút” gây nhầm; trường thời gian cho phép nhập giây hoặc phút:giây.
- Trạng thái ảnh phân biệt rõ đang trích xuất, có ảnh và ảnh lỗi.

## Giữ nguyên phạm vi CTA
- Chỉ nhận diện từ khóa CTA hiển thị trong hình ảnh/video như LIKE, SHARE, SUBSCRIBE và các biến thể tiếng Việt hiện có.
- Không mở rộng sang phân loại cảnh phim, không phân tích lời nói hoặc âm thanh.
- Giữ mật độ lấy mẫu đã chọn (mặc định 2 giây/ảnh), Pause/Resume, Quét tiếp, cache và duyệt thủ công.

## Nâng cấp
- UPDATE tương thích từ v1.5.6.35.
- Gói chỉ chứa các file mã ứng dụng thay đổi và metadata phiên bản; không chứa video nguồn, dự án, autosave, settings, downloads hoặc renders.
