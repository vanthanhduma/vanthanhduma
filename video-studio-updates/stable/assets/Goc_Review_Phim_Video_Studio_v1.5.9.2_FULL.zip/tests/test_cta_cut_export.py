"""Small FFmpeg integration regression for the existing selected-range export path."""
from __future__ import annotations

import json
import subprocess
import tempfile
import unittest
from pathlib import Path

import numpy as np

import app as core


class CTACutExportTests(unittest.TestCase):
    def test_excluded_cta_interval_cuts_video_and_audio_together(self):
        ffmpeg = core.get_ffmpeg()
        if not core.ffmpeg_has_encoder(ffmpeg, "libx264"):
            self.skipTest("FFmpeg build does not provide libx264")
        with tempfile.TemporaryDirectory() as folder:
            source = str(Path(folder) / "source.mp4")
            output = str(Path(folder) / "cta_cut.mp4")
            command = [
                ffmpeg, "-hide_banner", "-loglevel", "error",
                "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=25:duration=5",
                "-f", "lavfi", "-i", "sine=frequency=1000:sample_rate=48000:duration=5",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac",
                "-shortest", "-movflags", "+faststart", source,
            ]
            subprocess.run(command, check=True, capture_output=True)
            metadata = core.read_video_info(source)
            overlay = np.zeros((metadata["height"], metadata["width"], 4), dtype=np.uint8)
            core.encode_video(source, output, 0.0, None, None, 0, overlay,
                              lambda _pct, _message: None, prefer_gpu=False,
                              excluded_ranges=[(1.0, 3.0)])
            report = subprocess.run(
                [core.get_ffprobe(), "-v", "error", "-show_entries",
                 "stream=codec_type,duration", "-of", "json", output],
                check=True, capture_output=True, text=True,
            )
            streams = json.loads(report.stdout)["streams"]
            by_type = {item["codec_type"]: float(item["duration"]) for item in streams}
            self.assertAlmostEqual(by_type["video"], 3.0, delta=0.08)
            self.assertAlmostEqual(by_type["audio"], 3.0, delta=0.08)
            self.assertTrue(Path(source).is_file())


if __name__ == "__main__":
    unittest.main()
