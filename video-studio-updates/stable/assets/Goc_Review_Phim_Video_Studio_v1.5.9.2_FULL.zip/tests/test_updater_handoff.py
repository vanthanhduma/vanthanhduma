import os
import subprocess
import sys
import time
from pathlib import Path

import pytest

from updater.apply_helper import _wait_for_pid
from updater.core import UpdateError


def test_wait_for_already_exited_process_returns():
    proc = subprocess.Popen([sys.executable, "-c", "pass"])
    proc.wait(timeout=5)
    _wait_for_pid(proc.pid, timeout=2)


def test_wait_for_live_process_times_out():
    proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(10)"])
    try:
        with pytest.raises(UpdateError):
            _wait_for_pid(proc.pid, timeout=1)
    finally:
        proc.terminate()
        proc.wait(timeout=5)


def test_full_launcher_uses_localappdata_log_path():
    root = Path(__file__).resolve().parents[1]
    launcher = (root / "launcher.py").read_text(encoding="utf-8")
    assert "GocReviewVideoStudio" in launcher
    assert "launcher.log" in launcher
    assert "CREATE_NO_WINDOW" in launcher
