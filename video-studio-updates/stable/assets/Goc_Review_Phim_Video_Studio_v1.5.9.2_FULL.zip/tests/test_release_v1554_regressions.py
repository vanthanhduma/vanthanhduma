from pathlib import Path

import launcher

ROOT = Path(__file__).resolve().parents[1]


def test_launcher_prefers_windowless_python_runtime(tmp_path):
    scripts = tmp_path / ".venv" / "Scripts"
    scripts.mkdir(parents=True)
    python = scripts / "python.exe"
    pythonw = scripts / "pythonw.exe"
    python.touch()
    pythonw.touch()

    assert launcher._gui_python(tmp_path) == pythonw
    pythonw.unlink()
    assert launcher._gui_python(tmp_path) == python


def test_shortcut_uses_hidden_windows_script_host_and_pythonw():
    vbs = (ROOT / "MO_GOC_REVIEW_PHIM.vbs").read_text(encoding="utf-8")
    shortcut = (ROOT / "TAO_LOI_TAT_DESKTOP.vbs").read_text(encoding="utf-8")
    batch = (ROOT / "CHAY_TOOL.bat").read_text(encoding="utf-8")

    assert "pythonw.exe" in vbs
    assert 'sh.Run(cmd, 0, True)' in vbs
    assert 'link.TargetPath = wscriptPath' in shortcut
    assert 'link.Arguments = "//B //NoLogo "' in shortcut
    assert "wscript.exe" in batch
    assert 'start ""' in batch
    assert "pause" not in batch.lower()


def test_one_click_check_starts_download_without_second_confirmation():
    ui = (ROOT / "updater" / "qt_ui.py").read_text(encoding="utf-8")
    main = (ROOT / "qt_app.py").read_text(encoding="utf-8")

    assert 'QPushButton("Kiểm tra & cập nhật")' in ui
    assert "self.start_check(silent=False, auto_install=True)" in ui
    assert "if self._auto_install_after_check:" in ui
    assert "self.start_update()" in ui
    assert "QMessageBox.question" not in ui
    assert "self.update_dialog.start_check(silent=False, auto_install=True)" in main
    assert "self.update_dialog.start_update()" in main


def test_update_idle_gate_uses_qthread_api():
    main = (ROOT / "qt_app.py").read_text(encoding="utf-8")
    assert "self._download_thread.isRunning()" in main
    assert "self._download_thread.is_alive()" not in main


def test_missing_project_logo_is_non_modal_fallback():
    source = (ROOT / "app.py").read_text(encoding="utf-8")
    start = source.index("    def _load_project_file(")
    end = source.index("    def _timeline_duration(", start)
    block = source[start:end]

    assert 'logo_fallback = True' in block
    assert 'dùng logo mặc định' in block
    assert 'warnings.append("Không tìm thấy logo riêng' not in block
    assert 'messagebox.showinfo("Đã mở dự án"' not in block


def test_worker_reports_full_tesseract_preflight_detail():
    worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
    assert 'detail = str(ocr_status.get("detail", "")).strip()' in worker
    assert 'Chi tiết kỹ thuật:' in worker
