from __future__ import annotations

import os
import sys
import tempfile
import time
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("PYTHONUNBUFFERED", "1")

import cv2
import numpy as np
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from cta_detector import find_cta_regions, get_subscribe_ocr_status
from qt_app import MainWindow


def make_synthetic_video(path: Path, label: str) -> None:
    # Reuse the exact frame layouts already covered by the CTA detector tests,
    # then encode them to MP4 to exercise the real video decoder and scan loop.
    width, height, fps, seconds = 640, 360, 8, 6
    writer = cv2.VideoWriter(
        str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
    )
    if not writer.isOpened():
        raise RuntimeError("OpenCV could not create the synthetic MP4 fixture.")
    try:
        for _ in range(fps * seconds):
            frame = np.full((height, width, 3), (38, 42, 46), dtype=np.uint8)
            if label == "SUBSCRIBE":
                cv2.rectangle(frame, (420, 285), (595, 335), (0, 0, 235), -1)
                cv2.rectangle(frame, (432, 298), (580, 322), (255, 255, 255), -1)
                cv2.putText(
                    frame, "SUBSCRIBE", (440, 318), cv2.FONT_HERSHEY_SIMPLEX,
                    0.52, (0, 0, 0), 1, cv2.LINE_AA,
                )
            elif label == "LIKE":
                cv2.rectangle(frame, (80, 120), (560, 230), (255, 255, 255), -1)
                cv2.putText(
                    frame, "LIKE", (150, 195), cv2.FONT_HERSHEY_SIMPLEX,
                    1.6, (0, 0, 0), 3, cv2.LINE_AA,
                )
            else:
                raise ValueError(f"Unknown synthetic CTA label: {label}")
            writer.write(frame)
    finally:
        writer.release()


def main() -> int:
    status = get_subscribe_ocr_status()
    if not status.get("ready"):
        raise RuntimeError("CTA OCR is not ready on Windows runner: " + str(status))
    with tempfile.TemporaryDirectory(prefix="batch-cta-e2e-") as temp:
        root = Path(temp)
        source_dir = root / "inputs"
        output_dir = root / "projects"
        source_dir.mkdir()
        first = source_dir / "fixture_subscribe.mp4"
        second = source_dir / "fixture_like_share.mp4"
        make_synthetic_video(first, "SUBSCRIBE")
        make_synthetic_video(second, "LIKE")

        # Verify the encoded MP4 itself still exposes the expected OCR text.
        for source, expected in ((first, {"SUBSCRIBE"}), (second, {"LIKE"})):
            capture = cv2.VideoCapture(str(source))
            try:
                ok, frame = capture.read()
                if not ok or frame is None:
                    raise RuntimeError(f"Cannot read the first frame from {source.name}")
                detections = find_cta_regions(frame)
                detected_terms = {
                    str(term).upper()
                    for detection in detections
                    for term in detection.get("terms", [])
                }
                if not (detected_terms & expected):
                    raise RuntimeError(
                        f"Single-frame OCR failed on encoded {source.name}: "
                        f"expected {sorted(expected)}, found {sorted(detected_terms)}"
                    )
                print(
                    f"Single-frame OCR {source.name}: {sorted(detected_terms)} PASS",
                    flush=True,
                )
            finally:
                capture.release()

        app = QApplication(sys.argv)
        window = MainWindow()
        window.show()
        result = {"finished": False, "error": "", "exit": 1, "opening_project": False, "expected_project": ""}

        def finish(code: int, message: str) -> None:
            if result["finished"]:
                return
            result["finished"] = True
            result["exit"] = code
            print(message, flush=True)
            window.close()
            QTimer.singleShot(300, app.quit)

        def begin_batch() -> None:
            if result["finished"]:
                return
            if not window.engine_ready:
                QTimer.singleShot(100, begin_batch)
                return
            window.batch_files = [str(first), str(second)]
            window.batch_folder_edit.setText(str(output_dir))
            window._batch_refresh_table()
            window._batch_start()

        def inspect_opened_project() -> None:
            if result["finished"]:
                return
            expected = str(result.get("expected_project", "") or "")
            active = str(window.state.get("project_path", "") or "")
            try:
                project_is_active = bool(expected and active) and Path(active).resolve() == Path(expected).resolve()
            except OSError:
                project_is_active = False
            if project_is_active:
                metadata = getattr(window, "cta_cache_metadata", {}) or {}
                cached_candidates = metadata.get("candidates", []) if isinstance(metadata, dict) else []
                visible_candidates = getattr(window, "cta_candidates", []) or []
                if metadata.get("complete") and cached_candidates and visible_candidates:
                    thumbnails = [
                        Path(str(item.get("preview_path", "")))
                        for item in visible_candidates
                    ]
                    if all(str(path) and path.is_file() for path in thumbnails):
                        terms = {
                            str(term).upper()
                            for item in visible_candidates
                            for term in item.get("terms", [])
                        }
                        finish(
                            0,
                            "Batch CTA E2E PASS: OCR recognized SUBSCRIBE and LIKE in two synthetic MP4s; "
                            "two separate projects/caches/thumbnails saved; opening a saved project in Qt "
                            f"reloaded {len(visible_candidates)} visible CTA candidate(s), terms={sorted(terms)}.",
                        )
                        return
            QTimer.singleShot(150, inspect_opened_project)

        def inspect_batch() -> None:
            if not window.batch_running and window.batch_jobs:
                statuses = [job.get("status") for job in window.batch_jobs]
                if statuses == ["completed", "completed"]:
                    projects = sorted(output_dir.glob("*/**/*.grproj"))
                    if len(projects) != 2:
                        finish(1, f"Expected two independent .grproj files, found {len(projects)}: {projects}")
                        return
                    for project in projects:
                        data = json.loads(project.read_text(encoding="utf-8"))
                        if data.get("schema_version") != 4:
                            finish(1, f"Unexpected project schema in {project}")
                            return
                        video = data.get("media", {}).get("video", {}).get("absolute", "")
                        if not Path(video).is_file():
                            finish(1, f"Source video path is not valid in {project}")
                            return
                        workspace = project.parent / "Analysis" / "CTA"
                        caches = list(workspace.glob("video_*.json"))
                        if len(caches) != 1:
                            finish(1, f"CTA cache missing for {project}")
                            return
                        cache = json.loads(caches[0].read_text(encoding="utf-8"))
                        if not cache.get("complete"):
                            finish(1, f"CTA cache is not marked complete for {project}")
                            return
                        candidates = cache.get("candidates", [])
                        if not candidates:
                            finish(1, f"The real CTA detector produced no candidates for {Path(video).name}")
                            return
                        found_terms = {
                            str(term).upper()
                            for candidate in candidates
                            for term in candidate.get("terms", [])
                        }
                        expected_terms = {"SUBSCRIBE"} if "subscribe" in Path(video).name.lower() else {"LIKE"}
                        if not (found_terms & expected_terms):
                            finish(
                                1,
                                f"CTA OCR did not recognize an expected term in {Path(video).name}: "
                                f"expected one of {sorted(expected_terms)}, found {sorted(found_terms)}",
                            )
                            return
                        for candidate in candidates:
                            thumb = candidate.get("thumbnail", "")
                            if not thumb or not (caches[0].parent / thumb).is_file():
                                finish(1, f"CTA evidence thumbnail is missing for candidate {candidate.get('label')}: {thumb}")
                                return
                        print(
                            f"{Path(video).name}: {len(candidates)} candidate(s), "
                            f"terms={sorted(found_terms)}, thumbnails=PASS",
                            flush=True,
                        )
                    if not result["opening_project"]:
                        expected_project = projects[0].resolve()
                        result["expected_project"] = str(expected_project)
                        matching_row = next(
                            (
                                index for index, job in enumerate(window.batch_jobs)
                                if str(job.get("project_path", "") or "")
                                and Path(str(job.get("project_path"))).resolve() == expected_project
                            ),
                            -1,
                        )
                        if matching_row < 0:
                            finish(1, f"Saved project {expected_project.name} is not linked to its Batch CTA queue row.")
                            return
                        window.batch_table.selectRow(matching_row)
                        window.batch_table.setCurrentCell(matching_row, 0)
                        result["opening_project"] = True
                        window._batch_open_selected_project()
                        QTimer.singleShot(150, inspect_opened_project)
                elif any(status == "failed" for status in statuses):
                    errors = [job.get("error", "") for job in window.batch_jobs if job.get("status") == "failed"]
                    finish(1, "Batch CTA job failed: " + " | ".join(errors))
            if not result["finished"]:
                QTimer.singleShot(200, inspect_batch)

        QTimer.singleShot(100, begin_batch)
        QTimer.singleShot(200, inspect_batch)
        QTimer.singleShot(180000, lambda: finish(1, "Timed out waiting for two-video Batch CTA run."))
        app.exec()
        return int(result["exit"])


if __name__ == "__main__":
    raise SystemExit(main())
