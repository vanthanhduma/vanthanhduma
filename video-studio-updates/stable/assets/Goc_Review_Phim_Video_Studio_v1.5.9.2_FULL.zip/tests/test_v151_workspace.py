from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class UnifiedWorkspaceLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt = (ROOT / "qt_app.py").read_text(encoding="utf-8")
        cls.core = (ROOT / "app.py").read_text(encoding="utf-8")

    def test_version_is_consistent(self):
        self.assertIn('APP_VERSION = _load_app_version()', self.qt)
        self.assertRegex((ROOT / 'PHIEN_BAN.txt').read_text(encoding='utf-8'), r'v1\.5\.6\.\d+')
        self.assertIn('APP_VERSION', self.core)

    def test_edit_and_mask_have_distinct_inspector_pages(self):
        self.assertIn('self.inspector_stack.addWidget(self._build_edit_tab())', self.qt)
        self.assertIn('self.inspector_stack.addWidget(self._build_watermark_tab())', self.qt)
        self.assertIn('"edit": (0, "Thuộc tính cảnh")', self.qt)
        self.assertIn('"mask": (1, "Làm sạch · Mask & Before / After")', self.qt)

    def test_cta_is_a_timeline_tab_not_a_sidebar_or_workspace_page(self):
        self.assertIn('self.cta_page = self._build_cta_page()', self.qt)
        self.assertIn('self.workspace_stack.addWidget(self.cta_page)', self.qt)
        self.assertIn('self.cta_page = self._build_cta_page()', self.qt)
        self.assertIn('def _cta_start_scan(self, preserve_existing=False):', self.qt)
        self.assertIn('def _cta_cut_selected(self):', self.qt)

    def test_before_after_uses_large_central_preview(self):
        self.assertIn('self.compare_before_large = FitPixmapLabel()', self.qt)
        self.assertIn('self.compare_after_large = FitPixmapLabel()', self.qt)
        self.assertIn('self.preview_tabs.addTab(compare_page, "Before / After")', self.qt)
        self.assertIn('self.preview_tabs.setCurrentIndex(1)', self.qt)
        self.assertIn('Tạo & xem so sánh lớn', self.qt)

    def test_quick_tips_are_removed_and_sidebar_is_system_status_only(self):
        self.assertNotIn('QLabel("Mẹo nhanh")', self.qt)
        self.assertNotIn('Mở video → chia cảnh → xử lý Mask/CTA → xuất MP4.', self.qt)
        self.assertIn('Trạng thái hệ thống', self.qt)
        self.assertIn('self.sidebar_engine_status', self.qt)
        self.assertIn('self.sidebar_autosave_status', self.qt)
        self.assertIn('self.resource_hint', self.qt)


    def test_seek_previews_selected_time_while_dragging(self):
        self.assertIn('self.seek.sliderMoved.connect(self._seek_preview_position)', self.qt)
        self.assertIn('def _seek_preview_position(self, milliseconds: int):', self.qt)
        self.assertIn('preview_time = self.seek.value() / 1000.0', self.qt)

    def test_project_save_and_export_controls_are_preserved(self):
        self.assertIn('self.save_btn = QPushButton("Lưu dự án")', self.qt)
        self.assertIn('self.save_as_btn = QPushButton("Lưu thành")', self.qt)
        self.assertIn('self.export_top_btn = QPushButton("Xuất video")', self.qt)
        self.assertIn('more_menu.addAction("Xử lý nhiều video")', self.qt)


    def test_cta_has_pause_resume_and_stop_controls(self):
        self.assertIn('self.cta_pause_btn = QPushButton("Tạm dừng")', self.qt)
        self.assertIn('self.cta_pause_btn.setText("Tiếp tục")', self.qt)
        self.assertIn('self.send("cta_scan_pause")', self.qt)
        self.assertIn('self.send("cta_scan_resume")', self.qt)
        self.assertIn('self.cta_stop_btn = QPushButton("Dừng quét")', self.qt)

    def test_manual_cut_plays_original_video_without_scene_controls(self):
        self.assertIn('Cắt bỏ thủ công · Từ–Đến (phút)', self.qt)
        self.assertIn('Mở video gốc Từ–Đến', self.qt)
        self.assertIn('cut_ranges', (ROOT / 'engine_worker.py').read_text(encoding='utf-8'))
        self.assertIn('Thêm khoảng bỏ', self.qt)
        self.assertNotIn('QPushButton("Thêm cảnh")', self.qt)
        self.assertNotIn('QPushButton("Tách cảnh")', self.qt)
        self.assertNotIn('QPushButton("Xóa cảnh")', self.qt)
        worker = (ROOT / 'engine_worker.py').read_text(encoding='utf-8')
        self.assertIn('video_preview_start', worker)
        self.assertIn('if len(paths) > 8:', worker)

    def test_cta_live_results_are_rendered_while_scanning(self):
        self.assertIn('elif msg_type == "cta_update":', self.qt)
        self.assertIn('def _cta_live_update(self, payload):', self.qt)
        self.assertIn('đã phát hiện {len(self.cta_candidates)} khoảng CTA', self.qt)
        self.assertIn('candidate_callback=report_candidates', (ROOT / "engine_worker.py").read_text(encoding="utf-8"))

    def test_cta_results_show_a_thumbnail_for_every_match(self):
        self.assertIn('self.cta_table = QTableWidget(0, 8)', self.qt)
        self.assertIn('self.cta_table.setCellWidget(row, 0, self._cta_thumbnail_widget(candidate))', self.qt)
        self.assertIn('def _cta_thumbnail_widget(self, candidate):', self.qt)
        self.assertIn('QPixmap(path)', self.qt)
        self.assertIn('Ảnh khung hình nhận diện', self.qt)
        self.assertIn('self.cta_preview.set_source(path, placeholder)', self.qt)
        self.assertIn('Đang trích xuất ảnh bằng chứng từ khung hình OCR…', self.qt)
        self.assertIn('Không có ảnh bằng chứng cho kết quả này.', self.qt)


    def test_cta_low_confidence_requires_explicit_selection_confirmation(self):
        self.assertIn('if confidence < 50.0:', self.qt)
        self.assertIn('Ứng viên CTA có độ tin cậy thấp', self.qt)
        self.assertIn('QMessageBox.StandardButton.No', self.qt)
        self.assertIn('Độ tin cậy thấp — kiểm tra kỹ ảnh trước khi chọn cắt.', self.qt)

    def test_cta_time_fields_do_not_claim_minute_units_when_displaying_media_time(self):
        self.assertIn('start_label = QLabel("Bắt đầu")', self.qt)
        self.assertIn('end_label = QLabel("Kết thúc")', self.qt)
        self.assertIn('Nhập thời điểm theo giây hoặc phút:giây.', self.qt)
        self.assertNotIn('QLabel("Bắt đầu (phút)")', self.qt)
        self.assertNotIn('QLabel("Kết thúc (phút)")', self.qt)

    def test_cta_thumbnail_decode_errors_are_isolated_per_candidate(self):
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn('except Exception as exc:', worker)
        self.assertIn('item["thumbnail_error"] = str(exc)[:220]', worker)
        self.assertIn('A failed preview must not prevent other cached CTA results from loading.', worker)


    def test_cta_results_are_cached_and_thumbnails_rebuilt(self):
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn('def _cta_cache_file(self, video_path: str | None = None)', self.qt)
        self.assertIn('def _save_cta_cache_now(self):', self.qt)
        self.assertIn('def _load_cta_cache_for_video(self, video_path: str):', self.qt)
        self.assertIn('self.send("cta_cache_thumbnails", candidates=candidates)', self.qt)
        self.assertIn('def _cta_cache_thumbnails(candidates: list[dict]) -> dict:', worker)
        self.assertIn('elif cmd == "cta_cache_thumbnails":', worker)
        self.assertIn('self._save_cta_cache_now()', self.qt)

    def test_cta_keeps_fixed_two_second_sampling_and_improves_ocr(self):
        self.assertIn('self.cta_interval = QLabel("1 ảnh / 2 giây")', self.qt)
        self.assertIn('interval = 2.0', self.qt)
        self.assertNotIn('0,5 giây / ảnh', self.qt)
        self.assertIn('Quét LIKE · SHARE · SUBSCRIBE', self.qt)
        self.assertIn('self.cta_filter.addItems(["Tất cả", "LIKE", "SHARE", "SUBSCRIBE"])', self.qt)
        detector = (ROOT / "cta_detector.py").read_text(encoding="utf-8")
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn('sample_interval: float = 2.0', detector)
        self.assertIn('detections = parse_ocr(run_ocr(padded, psm=11))', detector)
        self.assertIn('detections = parse_ocr(run_ocr(padded, psm=6))', detector)
        self.assertIn('spatial_groups', detector)
        self.assertIn('requested_interval = max(0.5, float(sample_interval))', detector)
        self.assertIn('if interval not in (0.25, 0.5, 1.0, 2.0):', worker)
        self.assertIn('max_width: int = 1280', detector)
        self.assertIn('"pass2_samples": 0', detector)
        self.assertNotIn('0,5 giây/ảnh · quét kỹ hơn', self.qt)

    def test_cta_uses_sequential_sampling_and_throttled_live_events(self):
        detector = (ROOT / "cta_detector.py").read_text(encoding="utf-8")
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn("class _SequentialFrameSampler", detector)
        self.assertIn("sampler.read_at(seconds)", detector)
        self.assertIn("now - last_progress_emit_at[0] >= 1.0", worker)
        self.assertIn("now - last_candidate_emit_at[0] < 3.0", worker)
        self.assertIn('prepared = _with_live_thumbnails(raw_candidates, force=False)', worker)
        self.assertIn('item.pop("_preview_jpeg", None)', worker)
        self.assertNotIn('"preview_path": ""', worker)
        self.assertIn('candidate_callback=report_candidates', worker)
        self.assertIn('os.environ.setdefault("OMP_THREAD_LIMIT", "1")', worker)

    def test_cta_scan_exposes_multi_hour_density_and_rescan_semantics(self):
        self.assertIn('không quét lại phần video đã hoàn tất', self.qt)
        self.assertIn('"pass1_interval"', self.qt)
        detector = (ROOT / "cta_detector.py").read_text(encoding="utf-8")
        self.assertIn("MAX_PASS1_SAMPLES = 120_000", detector)
        self.assertIn("test_full_length_sample_plan_for_2_to_3_hour_sources",
                      (ROOT / "tests" / "test_cta_detector.py").read_text(encoding="utf-8"))

    def test_cta_clear_all_and_live_updates_are_batched(self):
        self.assertIn('self.cta_clear_btn = QPushButton("Xóa tất cả")', self.qt)
        self.assertIn('def _cta_clear_all(self):', self.qt)
        self.assertIn('cache_file.unlink(missing_ok=True)', self.qt)
        self.assertIn('self.cta_live_refresh_timer.setInterval(2500)', self.qt)
        self.assertIn('def _flush_cta_live_update(self):', self.qt)
        self.assertIn('self.cta_table.setRowCount(len(self.cta_candidates))', self.qt)
        self.assertIn('self.cta_table.setUpdatesEnabled(False)', self.qt)

    def test_cta_can_scan_additional_results_without_dropping_cache(self):
        self.assertIn('self.cta_rescan_btn = QPushButton("Quét tiếp")', self.qt)
        self.assertIn('def _cta_scan_additional(self):', self.qt)
        self.assertIn('self._cta_start_scan(preserve_existing=True)', self.qt)
        self.assertIn('replace=not self.cta_scan_preserve_existing', self.qt)
        self.assertIn('start_at=resume_from', self.qt)
        self.assertIn('def _fmt_scan_key(self, sec):', self.qt)
        self.assertIn('def _cta_resume_time(self):', self.qt)
        self.assertIn('start_at: float = 0.0', (ROOT / 'cta_detector.py').read_text(encoding='utf-8'))
        self.assertIn('start_at=start_at', (ROOT / 'engine_worker.py').read_text(encoding='utf-8'))

    def test_cta_worker_supports_pause_resume_commands(self):
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn('elif cmd == "cta_scan_pause":', worker)
        self.assertIn('elif cmd == "cta_scan_resume":', worker)
        self.assertIn('pause_event=pause', worker)

    def test_cta_detector_uses_ocr_keywords_not_scene_or_motion_detection(self):
        detector = (ROOT / "cta_detector.py").read_text(encoding="utf-8")
        self.assertIn('"LIKE"', detector)
        self.assertIn('"SHARE"', detector)
        self.assertIn('"SUBSCRIBE"', detector)
        self.assertIn('"DANGKY"', detector)
        regions = detector.split("def find_subscribe_regions(", 1)[1].split(
            "# Backward compatibility for callers/tests from v1.5.2.0.", 1
        )[0]
        self.assertNotIn("_find_graphic_subscribe_buttons(", regions)
        self.assertNotIn("_motion_score(", regions)
        self.assertIn('phase_callback=report_phase', (ROOT / "engine_worker.py").read_text(encoding="utf-8"))
        self.assertIn('vie.traineddata', detector)
        self.assertIn('pytesseract>=0.3.13', (ROOT / "requirements.txt").read_text(encoding="utf-8"))

    def test_mask_generation_runs_outside_the_tk_event_loop(self):
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn("MASK_TASK_EVENTS", worker)
        self.assertIn("def _start_mask_task(cmd: str)", worker)
        self.assertIn("def _poll_mask_task_events()", worker)
        self.assertIn('return _start_mask_task("auto_extract")', worker)
        self.assertIn('return _start_mask_task("use_selection_mask")', worker)
        self.assertIn('"set_selection", "mask_stroke", "use_selection_mask"', worker)
        self.assertIn('"mask_busy": bool(getattr(app, "mask_busy", False))', worker)
        self.assertIn('elif msg_type == "mask_task_started":', self.qt)
        self.assertIn("self._set_mask_task_busy(mask_busy)", self.qt)

    def test_preview_resizes_before_full_resolution_mask_blending(self):
        worker = (ROOT / "engine_worker.py").read_text(encoding="utf-8")
        self.assertIn("preview_w = max(1, int(round(w * scale)))", worker)
        self.assertIn("show = cv2.resize(show, (preview_w, preview_h), interpolation=cv2.INTER_NEAREST)", worker)
        self.assertIn("cv2.addWeighted(frame, 0.62, tint, 0.38, 0)", worker)

    def test_mask_brush_clips_a_cached_selection_roi(self):
        self.assertIn('def _mask_clip_region(self):', self.core)
        self.assertIn('self._mask_clip_cache_key', self.core)
        self.assertIn('cv2.bitwise_and(roi, allowed, dst=roi)', self.core)
        self.assertNotIn('allowed = polygon_to_mask(self.frame.shape, self.lasso_points)', self.core)

    def test_overlay_fallback_uses_one_ffmpeg_process(self):
        self.assertIn('def _decode_overlay_samples_ffmpeg(', self.core)
        self.assertIn('_decode_overlay_samples_ffmpeg(', self.core)
        self.assertNotIn('frame = read_frame(video_path, float(seconds))', self.core)

    def test_seek_slider_supports_direct_click_and_timecode_entry(self):
        self.assertIn('class ClickSeekSlider(QSlider)', self.qt)
        self.assertIn('self.seek.sliderReleased.connect(self._seek_released)', self.qt)
        self.assertIn('self.seek_input.returnPressed.connect(self._seek_from_timecode)', self.qt)
        self.assertIn('self._seek_to_seconds(self.seek.value() / 1000.0)', self.qt)
        self.assertIn('self.seek.setRange(0, max(1, int(round(duration * 1000))))', self.qt)
        self.assertIn('if not self.seek.isSliderDown():', self.qt)


if __name__ == "__main__":
    unittest.main()

