from timeline_seek import format_media_time, parse_timecode


def test_media_time_always_uses_unbounded_mm_ss():
    assert format_media_time(0) == "00:00"
    assert format_media_time(9.4) == "00:09"
    assert format_media_time(90) == "01:30"
    assert format_media_time(7530) == "125:30"


def test_media_time_rounds_for_display_only():
    assert format_media_time(59.6) == "01:00"


def test_mm_ss_input_preserves_seconds():
    assert parse_timecode("01:30") == 90
    assert parse_timecode("125:30") == 7530
    assert parse_timecode("01:02:03") == 3723
