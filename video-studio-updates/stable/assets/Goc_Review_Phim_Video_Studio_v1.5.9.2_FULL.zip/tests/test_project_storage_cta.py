from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
import zipfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cta_merge import merge_boundary_candidate
from project_storage import (
    WORKSPACE_DIRS,
    create_project_archive,
    default_output_directory,
    default_output_directory_for_project,
    ensure_project_workspace,
    restore_project_archive,
    restore_project_backup,
    backup_project_file,
    list_project_backups,
    suggested_project_file,
    suggested_storage_root,
    sync_project_assets,
    video_fingerprint,
)


class ProjectStorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "E" / "fb"
        self.source_dir = self.root / "video nguồn"
        self.source_dir.mkdir(parents=True)
        (self.root / "video xuất").mkdir()
        self.video = self.source_dir / "Review_A.mp4"
        self.video.write_bytes(os.urandom(1024 * 1024 + 333))
        self.project = suggested_project_file(self.video)
        self.project.parent.mkdir(parents=True)
        self.workspace = ensure_project_workspace(self.project)
        self.logo = Path(self.temp.name) / "logo.png"
        self.logo.write_bytes(b"logo-test-data")
        payload = {
            "format": "goc-review-phim-video-studio-project",
            "schema_version": 4,
            "media": {
                "video": {"absolute": str(self.video), "relative": os.path.relpath(self.video, self.project.parent)},
                "logo": {"absolute": str(self.logo), "relative": os.path.relpath(self.logo, self.project.parent)},
                "output_dir": {"absolute": str(self.root / "video xuất"), "relative": os.path.relpath(self.root / "video xuất", self.project.parent)},
                "output_dir_custom": False,
            },
            "scenes": [{"branding_logo": {"absolute": str(self.logo), "relative": os.path.relpath(self.logo, self.project.parent)}}],
            "settings": {}, "selection": {}, "excluded_ranges": [],
        }
        self.payload = sync_project_assets(payload, self.project)
        self.project.write_text(json.dumps(self.payload, ensure_ascii=False), encoding="utf-8")
        (self.workspace / "Backups" / "Review_A_old.grproj").write_text(
            json.dumps(self.payload, ensure_ascii=False), encoding="utf-8"
        )
        cta = self.workspace / "Analysis" / "CTA"
        (cta / "thumbnails" / "evidence").mkdir(parents=True)
        (cta / "thumbnails" / "evidence" / "sample.jpg").write_bytes(b"jpeg-test")
        (cta / "video_test.json").write_text(
            json.dumps({"schema_version": 4, "resume_time": 30, "video_fingerprint": video_fingerprint(self.video)}),
            encoding="utf-8",
        )

    def tearDown(self):
        self.temp.cleanup()

    def test_storage_layout_and_fingerprint(self):
        self.assertEqual(self.project, self.root / "dự án lưu trữ" / "Review_A" / "Review_A.grproj")
        self.assertEqual(suggested_storage_root(self.video), self.root / "dự án lưu trữ")
        self.assertEqual(default_output_directory(self.video), self.root / "video xuất")
        self.assertEqual(default_output_directory_for_project(self.project, self.video), self.root / "video xuất")
        for folder in WORKSPACE_DIRS:
            self.assertTrue((self.workspace / folder).is_dir())
        moved = Path(self.temp.name) / "moved" / self.video.name
        moved.parent.mkdir()
        shutil.copy2(self.video, moved)
        self.assertEqual(video_fingerprint(self.video), video_fingerprint(moved))

    def test_archive_defaults_to_including_original_video(self):
        archive = create_project_archive(self.project, self.video)
        with zipfile.ZipFile(archive) as zf:
            names = set(zf.namelist())
        self.assertIn("Review_A/Media/Review_A.mp4", names)

    def test_asset_copy(self):
        logo_record = self.payload["media"]["logo"]
        self.assertTrue((self.project.parent / logo_record["relative"]).is_file())
        self.assertTrue(logo_record["relative"].startswith("Assets/"))

    def test_archive_with_and_without_video(self):
        archive = create_project_archive(self.project, self.video, include_video=True)
        self.assertEqual(archive.parent, self.root / "dự án lưu trữ" / "Gói ZIP" / "Review_A")
        self.assertTrue(archive.is_file())
        self.assertFalse(archive.with_name(archive.name + ".tmp").exists())
        with zipfile.ZipFile(archive) as zf:
            names = set(zf.namelist())
            self.assertIn("Review_A/Media/Review_A.mp4", names)
            self.assertIn("Review_A/Analysis/CTA/video_test.json", names)
            self.assertIn("Review_A/Analysis/CTA/thumbnails/evidence/sample.jpg", names)
            self.assertIn("Review_A/Backups/Review_A_old.grproj", names)
            main = json.loads(zf.read("Review_A/Review_A.grproj"))
            backup = json.loads(zf.read("Review_A/Backups/Review_A_old.grproj"))
            self.assertEqual(main["media"]["video"]["relative"], "Media/Review_A.mp4")
            self.assertEqual(main["media"]["output_dir"]["relative"], "../../video xuất")
            self.assertEqual(backup["media"]["video"]["relative"], "../Media/Review_A.mp4")
            self.assertEqual(backup["media"]["output_dir"]["relative"], "../../../video xuất")
            self.assertTrue(backup["media"]["logo"]["relative"].startswith("../Assets/"))

        restore_root = self.root / "dự án lưu trữ"
        restored = restore_project_archive(archive, restore_root)
        self.assertTrue((restored.parent / "Media" / "Review_A.mp4").is_file())
        self.assertTrue((restored.parent / "Analysis" / "CTA" / "video_test.json").is_file())
        self.assertEqual(video_fingerprint(restored.parent / "Media" / "Review_A.mp4"), video_fingerprint(self.video))

        no_video_archive = create_project_archive(self.project, self.video, include_video=False)
        restored_without_video = restore_project_archive(no_video_archive, restore_root)
        self.assertTrue(restored_without_video.is_file())
        self.assertFalse((restored_without_video.parent / "Media" / "Review_A.mp4").exists())

        restored_again = restore_project_archive(archive, restore_root)
        self.assertEqual(restored_again.parent.name, "Review_A_4")

    def test_manual_backup_rotation_and_restore_to_new_project(self):
        # Manual-save checkpoints represent the newly committed project state.
        for index in range(10):
            payload = json.loads(self.project.read_text(encoding="utf-8"))
            payload["settings"]["checkpoint"] = index
            self.project.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            backup_project_file(self.project, keep=8)
        backups = list_project_backups(self.project, keep=8)
        self.assertEqual(len(backups), 8)
        newest_payload = json.loads(backups[0].read_text(encoding="utf-8"))
        self.assertEqual(newest_payload["settings"]["checkpoint"], 9)

        recovered = restore_project_backup(backups[-1], self.project)
        self.assertTrue(recovered.is_file())
        self.assertNotEqual(recovered.resolve(), self.project.resolve())
        recovered_payload = json.loads(recovered.read_text(encoding="utf-8"))
        self.assertEqual(recovered_payload["settings"]["checkpoint"], 2)
        recovered_video = Path(recovered_payload["media"]["video"]["absolute"])
        self.assertEqual(recovered_video.resolve(), self.video.resolve())
        recovered_logo = Path(recovered.parent / recovered_payload["media"]["logo"]["relative"])
        self.assertTrue(recovered_logo.is_file())
        self.assertTrue((recovered.parent / "Analysis" / "CTA" / "video_test.json").is_file())

    def test_identical_manual_save_does_not_duplicate_backup(self):
        first = backup_project_file(self.project, keep=8)
        second = backup_project_file(self.project, keep=8)
        self.assertEqual(first, second)
        self.assertEqual(len(list_project_backups(self.project, keep=8)), 1)

    def test_reject_path_traversal_and_symlinks(self):
        traversal = Path(self.temp.name) / "traversal.zip"
        with zipfile.ZipFile(traversal, "w") as zf:
            zf.writestr("../escape.txt", "bad")
            zf.writestr("Bad/Bad.grproj", self.project.read_text(encoding="utf-8"))
        with self.assertRaises(ValueError):
            restore_project_archive(traversal, Path(self.temp.name) / "traversal-out")

        symlink = Path(self.temp.name) / "symlink.zip"
        info = zipfile.ZipInfo("Bad/link")
        info.create_system = 3
        info.external_attr = 0o120777 << 16
        with zipfile.ZipFile(symlink, "w") as zf:
            zf.writestr(info, "target")
            zf.writestr("Bad/Bad.grproj", self.project.read_text(encoding="utf-8"))
        with self.assertRaises(ValueError):
            restore_project_archive(symlink, Path(self.temp.name) / "symlink-out")


class CTABoundaryMergeTests(unittest.TestCase):
    def setUp(self):
        self.old = {
            "scan_id": 1, "start": 28.8, "end": 30.5, "x": 100, "y": 600,
            "w": 300, "h": 80, "terms": ["SUBSCRIBE"], "confidence": 75,
            "peak_confidence": 80, "samples": 2, "label": "SUBSCRIBE", "evidence": ["text_cta"],
        }
        self.new = {
            "scan_id": 32000, "start": 30.0, "end": 31.8, "x": 105, "y": 605,
            "w": 298, "h": 78, "terms": ["SUBSCRIBE"], "confidence": 89,
            "peak_confidence": 92, "samples": 2, "label": "SUBSCRIBE", "evidence": ["text_cta"],
        }

    def test_same_cta_merges(self):
        merged = merge_boundary_candidate(self.old, self.new, max_gap=2.2)
        self.assertIsNotNone(merged)
        self.assertEqual(merged["start"], 28.8)
        self.assertEqual(merged["end"], 31.8)
        self.assertEqual(merged["confidence"], 89)

    def test_different_location_or_term_does_not_merge(self):
        self.assertIsNone(merge_boundary_candidate(self.old, {**self.new, "x": 800}, max_gap=2.2))
        self.assertIsNone(merge_boundary_candidate(self.old, {**self.new, "terms": ["LIKE"]}, max_gap=2.2))


if __name__ == "__main__":
    unittest.main()
