from __future__ import annotations

import tempfile
import unittest
from unittest import mock
from pathlib import Path

import cv2
import numpy as np

from cta_detector import (CTAScanCancelled, detect_cta_image_candidates, find_cta_regions,
                          find_end_screen_panels, _classify_subscribe_text, _find_graphic_subscribe_buttons,
                          _effective_pass1_sample_limit, _tracks_to_candidates,
                          _SequentialFrameSampler, _encode_cta_preview)


class CTARegionTests(unittest.TestCase):
    def make_frame(self, button: bool = True):
        frame = np.zeros((360, 640, 3), dtype=np.uint8)
        # Film-like, low-saturation background.
        frame[:] = (38, 42, 46)
        if button:
            cv2.rectangle(frame, (420, 285), (595, 335), (0, 0, 235), -1)
            cv2.rectangle(frame, (432, 298), (580, 322), (255, 255, 255), -1)
            cv2.putText(frame, "SUBSCRIBE", (440, 318), cv2.FONT_HERSHEY_SIMPLEX,
                        0.52, (0, 0, 0), 1, cv2.LINE_AA)
        return frame

    def test_full_length_sample_plan_for_2_to_3_hour_sources(self):
        for duration in (2 * 60 * 60, 3 * 60 * 60, 227 * 60):
            for interval, expected_count in ((2.0, int(duration // 2)), (1.0, int(duration)), (0.5, int(duration * 2))):
                with self.subTest(duration=duration, interval=interval):
                    limit, capped = _effective_pass1_sample_limit(duration, interval, 1800)
                    self.assertEqual(limit, expected_count)
                    self.assertFalse(capped)

    def test_multi_day_source_reports_explicit_sample_ceiling(self):
        limit, capped = _effective_pass1_sample_limit(200_000, 0.25, 1800)
        self.assertEqual(limit, 120_000)
        self.assertTrue(capped)

    def test_low_confidence_single_frame_subscribe_text_is_kept_for_review(self):
        track = {
            "scan_id": 0, "times": [5.0], "scores": [28.0],
            "intervals": [1.0], "box": {"x": 10, "y": 20, "w": 80, "h": 30},
            "evidence": ["text_en"], "methods": ["OCR tiếng Anh"],
            "texts": ["SUBSCRIBE"], "locations": ["dưới"], "animated": False,
            "motion_scores": [0.0],
        }
        result = _tracks_to_candidates([track], 10.0, 1.0)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["text"], "SUBSCRIBE")
        track["evidence"] = ["graphic_button"]
        self.assertEqual(_tracks_to_candidates([track], 10.0, 1.0), [])

    def test_tracks_preserve_zero_second_evidence_timestamp(self):
        track = {
            "scan_id": 0, "times": [0.0, 1.0, 2.0], "scores": [80.0, 81.0, 82.0],
            "intervals": [1.0], "box": {"x": 10, "y": 20, "w": 80, "h": 30},
            "evidence": ["text_cta"], "methods": ["OCR từ khóa CTA"],
            "texts": ["SUBSCRIBE"], "locations": ["dưới"],
            "terms": ["SUBSCRIBE"], "labels": ["SUBSCRIBE"],
            "_preview_jpeg": b"evidence", "_preview_confidence": 82.0,
            "_preview_sample_time": 0.0,
        }
        result = _tracks_to_candidates([track], 3.0, 1.0)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["sample_time"], 0.0)


    def test_sequential_sampler_uses_grabs_between_nearby_samples(self):
        class FakeCapture:
            def __init__(self):
                self.next_index = 0
                self.current = None
                self.set_calls = []
                self.grab_calls = 0

            def set(self, prop, value):
                self.set_calls.append((prop, value))
                self.next_index = int(value)
                return True

            def read(self):
                if self.next_index >= 100:
                    return False, None
                self.current = np.full((8, 8, 3), self.next_index % 255, dtype=np.uint8)
                self.next_index += 1
                return True, self.current

            def grab(self):
                if self.next_index >= 100:
                    return False
                self.current = np.full((8, 8, 3), self.next_index % 255, dtype=np.uint8)
                self.next_index += 1
                self.grab_calls += 1
                return True

        capture = FakeCapture()
        sampler = _SequentialFrameSampler(capture, fps=10.0, frame_count=100)
        values = []
        for seconds in (0.5, 1.5, 2.5, 3.5):
            ok, frame = sampler.read_at(seconds)
            self.assertTrue(ok)
            values.append(int(frame[0, 0, 0]))
        self.assertEqual(values, [5, 15, 25, 35])
        self.assertEqual(sampler.seek_count, 1)
        self.assertEqual(len(capture.set_calls), 1)
        self.assertGreater(capture.grab_calls, 0)

    def test_sequential_sampler_seeks_again_after_distant_gap(self):
        class FakeCapture:
            def __init__(self):
                self.next_index = 0
                self.current = None
                self.set_calls = []

            def set(self, prop, value):
                self.set_calls.append((prop, value))
                self.next_index = int(value)
                return True

            def read(self):
                if self.next_index >= 1000:
                    return False, None
                self.current = np.full((4, 4, 3), self.next_index % 255, dtype=np.uint8)
                self.next_index += 1
                return True, self.current

            def grab(self):
                if self.next_index >= 1000:
                    return False
                self.current = np.zeros((4, 4, 3), dtype=np.uint8)
                self.next_index += 1
                return True

        capture = FakeCapture()
        sampler = _SequentialFrameSampler(capture, fps=10.0, frame_count=1000)
        self.assertTrue(sampler.read_at(0.5)[0])
        self.assertTrue(sampler.read_at(30.0)[0])
        self.assertEqual(sampler.seek_count, 2)
        self.assertEqual(len(capture.set_calls), 2)

    def test_detects_subscribe_word_inside_button(self):
        detections = find_cta_regions(self.make_frame(True))
        self.assertTrue(detections)
        self.assertGreaterEqual(detections[0]["confidence"], 55)
        self.assertGreater(detections[0]["w"], 100)

    def test_ignores_plain_frame_without_subscribe_text(self):
        self.assertEqual(find_cta_regions(self.make_frame(False)), [])

    def test_scan_candidates_include_jpeg_evidence_from_the_sampled_ocr_frame(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_frame_evidence_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for _ in range(40):
                writer.write(self.make_frame(False))
            writer.release()

            detection = {
                "x": 410, "y": 270, "w": 180, "h": 58, "confidence": 84.0,
                "kind": "text_cta", "method": "OCR từ khóa CTA",
                "label": "SUBSCRIBE", "text": "SUBSCRIBE",
                "terms": ["SUBSCRIBE"], "evidence": ["text_cta"],
                "location": "dưới",
            }
            with (
                mock.patch("cta_detector.get_subscribe_ocr_status", return_value={"ready": True}),
                mock.patch("cta_detector.find_subscribe_regions", return_value=[detection]),
            ):
                result = detect_cta_image_candidates(path, sample_interval=0.5, max_samples=100)

        self.assertTrue(result["candidates"])
        candidate = result["candidates"][0]
        self.assertIsInstance(candidate.get("_preview_jpeg"), bytes)
        self.assertGreaterEqual(candidate["sample_time"], 0.0)
        decoded = cv2.imdecode(np.frombuffer(candidate["_preview_jpeg"], dtype=np.uint8), cv2.IMREAD_COLOR)
        self.assertIsNotNone(decoded)
        self.assertEqual(decoded.shape[1], 640)
        self.assertGreater(candidate.get("_preview_confidence", 0), 0)


    def test_detects_short_cta_interval_in_synthetic_video(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for frame_index in range(50):
                show = 10 <= frame_index < 35
                writer.write(self.make_frame(show))
            writer.release()
            result = detect_cta_image_candidates(path, sample_interval=0.5, max_samples=100)
        self.assertGreaterEqual(result["samples"], 8)
        self.assertTrue(result["candidates"])
        best = max(result["candidates"], key=lambda item: item["confidence"])
        self.assertLessEqual(best["start"], 1.8)
        self.assertGreaterEqual(best["end"], 2.8)
        self.assertGreaterEqual(best["samples"], 2)


    def test_ignores_end_screen_panels_without_subscribe_text(self):
        frame = np.full((360, 640, 3), (15, 20, 25), dtype=np.uint8)
        cv2.rectangle(frame, (55, 105), (275, 285), (240, 240, 240), 3)
        cv2.rectangle(frame, (365, 105), (585, 285), (240, 240, 240), 3)
        cv2.circle(frame, (320, 195), 42, (240, 240, 240), 3)
        panels = find_end_screen_panels(frame)
        self.assertEqual(panels, [], "End-screen cards are outside the Subscribe-only scope")

    def test_ignores_red_button_without_subscribe_word(self):
        frame = np.full((360, 640, 3), (38, 42, 46), dtype=np.uint8)
        cv2.rectangle(frame, (420, 285), (595, 335), (0, 0, 235), -1)
        self.assertEqual(find_cta_regions(frame), [])

    def test_detects_like_keyword(self):
        frame = np.full((360, 640, 3), (38, 42, 46), dtype=np.uint8)
        cv2.rectangle(frame, (80, 120), (560, 230), (255, 255, 255), -1)
        cv2.putText(frame, "LIKE", (150, 195), cv2.FONT_HERSHEY_SIMPLEX,
                    1.6, (0, 0, 0), 3, cv2.LINE_AA)
        detections = find_cta_regions(frame)
        self.assertTrue(detections)
        self.assertIn("LIKE", detections[0]["label"])
        self.assertEqual(detections[0]["kind"], "text_cta")

    def test_matches_split_and_common_ocr_confusion_cta_words(self):
        accepted = [
            "SUB SCRIBE", "S U B S C R I B E", "L I K E",
            "SH ARE", "SH4RE", "L1KE", "5UB5CR1BE",
        ]
        for phrase in accepted:
            with self.subTest(phrase=phrase):
                self.assertIsNotNone(_classify_subscribe_text(phrase))

    def test_matches_only_complete_cta_words(self):
        for phrase in ("LIKE", "SHARE THIS", "SUBSCRIBE NOW"):
            with self.subTest(phrase=phrase):
                self.assertIsNotNone(_classify_subscribe_text(phrase))
        for phrase in ("LIKELY", "BIKE", "SUBMARINE", "SHAREHOLDER", "SUBSCRIBER"):
            with self.subTest(phrase=phrase):
                self.assertIsNone(_classify_subscribe_text(phrase))



    def test_normal_scan_uses_sparse_text_ocr_fallback_when_psm6_misses(self):
        import pytesseract
        from cta_detector import find_subscribe_regions

        empty = {
            "text": [], "conf": [], "left": [], "top": [], "width": [], "height": [],
            "block_num": [], "par_num": [], "line_num": [],
        }
        split_word = {
            "text": ["SUB", "SCRIBE"], "conf": [91.0, 88.0],
            "left": [120, 180], "top": [150, 150], "width": [52, 112],
            "height": [28, 28], "block_num": [1, 1],
            "par_num": [1, 1], "line_num": [1, 1],
        }
        fake_ocr = mock.Mock()
        fake_ocr.Output = pytesseract.Output
        fake_ocr.TesseractError = pytesseract.TesseractError
        fake_ocr.image_to_data.side_effect = [empty, split_word]
        frame = np.full((360, 640, 3), (38, 42, 46), dtype=np.uint8)

        with (
            mock.patch("cta_detector._get_tesseract", return_value=fake_ocr),
            mock.patch("cta_detector._ocr_language", return_value="eng"),
            mock.patch("cta_detector._tessdata_config", return_value=""),
        ):
            detections = find_subscribe_regions(frame)

        self.assertEqual(len(fake_ocr.image_to_data.call_args_list), 2)
        self.assertIn("--psm 11", fake_ocr.image_to_data.call_args_list[0].kwargs["config"])
        self.assertIn("--psm 6", fake_ocr.image_to_data.call_args_list[1].kwargs["config"])
        self.assertTrue(detections)
        self.assertEqual(detections[0]["terms"], ["SUBSCRIBE"])
        self.assertIn("SUB SCRIBE", detections[0]["text"])

    def test_sparse_ocr_joins_adjacent_word_pieces_across_tesseract_blocks(self):
        import pytesseract
        from cta_detector import find_subscribe_regions

        split_word = {
            "text": ["SUB", "SCRIBE"], "conf": [91.0, 88.0],
            "left": [120, 178], "top": [150, 151], "width": [50, 112],
            "height": [28, 28], "block_num": [1, 2],
            "par_num": [1, 1], "line_num": [1, 1],
        }
        fake_ocr = mock.Mock()
        fake_ocr.Output = pytesseract.Output
        fake_ocr.TesseractError = pytesseract.TesseractError
        fake_ocr.image_to_data.return_value = split_word
        frame = np.full((360, 640, 3), (38, 42, 46), dtype=np.uint8)

        with (
            mock.patch("cta_detector._get_tesseract", return_value=fake_ocr),
            mock.patch("cta_detector._ocr_language", return_value="eng"),
            mock.patch("cta_detector._tessdata_config", return_value=""),
        ):
            detections = find_subscribe_regions(frame)

        self.assertEqual(len(fake_ocr.image_to_data.call_args_list), 1)
        self.assertTrue(detections)
        self.assertEqual(detections[0]["terms"], ["SUBSCRIBE"])
        self.assertIn("SUB SCRIBE", detections[0]["text"])


    def test_bundled_ocr_status_includes_vietnamese_pack(self):
        from cta_detector import get_subscribe_ocr_status
        status = get_subscribe_ocr_status()
        self.assertTrue(status.get("ready"), status)
        self.assertIn("eng", status.get("languages", []))
        self.assertIn("vie", status.get("languages", []))

    def test_ocr_overrides_a_stale_tessdata_prefix_with_app_models(self):
        import os
        from cta_detector import get_subscribe_ocr_status
        bundled = Path(__file__).resolve().parents[1] / "assets" / "tessdata"
        stale = str(bundled.parent / "wrong-tessdata")
        with mock.patch.dict(os.environ, {"TESSDATA_PREFIX": stale}):
            status = get_subscribe_ocr_status()
            self.assertTrue(status.get("ready"), status)
            self.assertEqual(Path(os.environ["TESSDATA_PREFIX"]).resolve(), bundled.resolve())
            self.assertEqual(Path(status["tessdata_dir"]).resolve(), bundled.resolve())
            self.assertEqual(set(status.get("languages", [])), {"eng", "vie"})

    def test_ocr_falls_back_to_user_cache_when_app_folder_cannot_load_models(self):
        import cta_detector
        bundled = Path(__file__).resolve().parents[1] / "assets" / "tessdata"
        with tempfile.TemporaryDirectory() as tmp:
            cache = Path(tmp) / "ocr" / "tessdata"

            real_probe = cta_detector._probe_tesseract_models

            def probe(ocr, directory, languages):
                if Path(directory).resolve() == bundled.resolve():
                    raise RuntimeError("simulated app-folder access failure")
                self.assertTrue((Path(directory) / "eng.traineddata").is_file())
                self.assertTrue((Path(directory) / "vie.traineddata").is_file())
                return real_probe(ocr, directory, languages)

            with mock.patch.object(cta_detector, "_find_tesseract_path", return_value=cta_detector.shutil.which("tesseract")), \
                 mock.patch.object(cta_detector, "_user_tessdata_dir", return_value=cache), \
                 mock.patch.object(cta_detector, "_probe_tesseract_models", side_effect=probe):
                status = cta_detector.get_subscribe_ocr_status()

            self.assertTrue(status.get("ready"), status)
            self.assertEqual(Path(status["tessdata_dir"]).resolve(), cache.resolve())
            self.assertTrue(status.get("warning"))
            for language in ("eng", "vie"):
                src = bundled / f"{language}.traineddata"
                dst = cache / f"{language}.traineddata"
                self.assertEqual(src.stat().st_size, dst.stat().st_size)
                self.assertEqual(cta_detector._sha256_file(src), cta_detector._sha256_file(dst))

    def test_tessdata_config_uses_inherited_prefix_for_paths_with_spaces(self):
        import cta_detector
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp) / "folder with spaces" / "tessdata"
            with mock.patch.object(cta_detector, "_configure_tessdata_prefix", return_value=directory):
                config = cta_detector._tessdata_config(directory)
            self.assertEqual(config, "")

    def test_tesseract_model_error_is_not_misreported_as_timeout(self):
        import pytesseract
        import cta_detector
        fake_ocr = mock.Mock()
        fake_ocr.Output = pytesseract.Output
        fake_ocr.TesseractError = pytesseract.TesseractError
        fake_ocr.image_to_data.side_effect = pytesseract.TesseractError(
            1, "Error opening data file eng.traineddata"
        )
        frame = np.full((100, 200, 3), 255, dtype=np.uint8)
        with mock.patch.object(cta_detector, "_get_tesseract", return_value=fake_ocr), \
             mock.patch.object(cta_detector, "_ocr_language", return_value="eng+vie"), \
             mock.patch.object(cta_detector, "_tessdata_config", return_value='--tessdata-dir "X:/ocr/tessdata"'):
            with self.assertRaisesRegex(RuntimeError, "không mở được model OCR") as error:
                cta_detector.find_subscribe_regions(frame)
        self.assertNotIn("quá thời gian", str(error.exception).lower())

    def test_recognises_vietnamese_subscribe_phrases_but_not_account_signup(self):
        accepted = [
            "Đăng ký kênh", "Nhớ đăng ký nhé", "Hãy đăng ký", "Đừng quên đăng ký",
            "Đăng ký ngay", "Mời bạn đăng ký kênh", "SUBSCRIBE NOW",
        ]
        for phrase in accepted:
            with self.subTest(phrase=phrase):
                self.assertIsNotNone(_classify_subscribe_text(phrase))
        self.assertIsNone(_classify_subscribe_text("Đăng ký tài khoản"))


    def test_ocr_reads_vietnamese_ascii_cta_in_a_video_frame(self):
        from cta_detector import find_subscribe_regions
        frame = np.full((360, 640, 3), (38, 42, 46), dtype=np.uint8)
        cv2.rectangle(frame, (120, 125), (525, 225), (255, 255, 255), -1)
        cv2.putText(frame, "DANG KY KENH", (140, 190), cv2.FONT_HERSHEY_SIMPLEX,
                    1.0, (0, 0, 0), 2, cv2.LINE_AA)
        detections = find_subscribe_regions(frame)
        self.assertTrue(detections)
        self.assertEqual(detections[0]["kind"], "text_cta")
        self.assertEqual(detections[0]["label"], "SUBSCRIBE")
        self.assertEqual(detections[0]["terms"], ["SUBSCRIBE"])

    def test_detects_graphic_subscribe_button_with_play_icon(self):
        frame = np.full((360, 640, 3), (38, 42, 46), dtype=np.uint8)
        cv2.rectangle(frame, (420, 285), (595, 335), (0, 0, 235), -1)
        triangle = np.array([[492, 297], [492, 323], [514, 310]], dtype=np.int32)
        cv2.fillConvexPoly(frame, triangle, (255, 255, 255))
        detections = _find_graphic_subscribe_buttons(frame)
        self.assertTrue(detections)
        self.assertEqual(detections[0]["kind"], "graphic_button")

    def test_motion_or_red_button_without_keyword_is_not_a_cta(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_graphic_only_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for frame_index in range(40):
                frame = np.full((360, 640, 3), (35, 40, 45), dtype=np.uint8)
                if frame_index >= 15:
                    cv2.rectangle(frame, (420, 285), (595, 335), (0, 0, 235), -1)
                    cv2.circle(frame, (505, 310), 16, (255, 255, 255), -1)
                writer.write(frame)
            writer.release()
            result = detect_cta_image_candidates(path, sample_interval=1.0, max_samples=50)
        self.assertEqual(result["candidates"], [])


    def test_scan_uses_one_pass_at_the_requested_two_second_interval(self):
        phases = []
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_single_pass_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for frame_index in range(60):
                writer.write(self.make_frame(14 <= frame_index < 45))
            writer.release()
            result = detect_cta_image_candidates(
                path, sample_interval=2.0, max_samples=100,
                phase_callback=lambda phase, done, total: phases.append((phase, done, total)),
            )
        self.assertEqual(result["pass1_samples"], 3)
        self.assertEqual(result["pass2_samples"], 0)
        self.assertAlmostEqual(result["pass1_interval"], 2.0, places=2)
        self.assertTrue(result["candidates"])
        self.assertTrue(any(phase == "pass1" for phase, *_ in phases))
        self.assertTrue(any(phase == "done" for phase, *_ in phases))


    def test_resumed_scan_ids_do_not_collide_with_cached_scan_ids(self):
        fake_detection = {
            "x": 420, "y": 285, "w": 175, "h": 50, "confidence": 88.0,
            "kind": "text_cta", "method": "OCR từ khóa CTA", "label": "SUBSCRIBE",
            "text": "SUBSCRIBE", "terms": ["SUBSCRIBE"], "evidence": ["text_cta"],
            "location": "dưới", "animated": False,
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_resume_id_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for _ in range(100):
                writer.write(self.make_frame(False))
            writer.release()
            with mock.patch("cta_detector.find_subscribe_regions", return_value=[fake_detection]):
                first = detect_cta_image_candidates(path, sample_interval=2.0, max_samples=20)
                resumed = detect_cta_image_candidates(
                    path, sample_interval=2.0, max_samples=20, start_at=6.0
                )
        self.assertTrue(first["candidates"])
        self.assertTrue(resumed["candidates"])
        first_ids = {item["scan_id"] for item in first["candidates"]}
        resumed_ids = {item["scan_id"] for item in resumed["candidates"]}
        self.assertTrue(first_ids.isdisjoint(resumed_ids))
        self.assertGreater(min(resumed_ids), max(first_ids))


    def test_cancelled_scan_stops_cleanly(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_cancel_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            for _ in range(10):
                writer.write(self.make_frame(True))
            writer.release()
            import threading
            cancel = threading.Event()
            cancel.set()
            with self.assertRaises(CTAScanCancelled):
                detect_cta_image_candidates(path, cancel_event=cancel)


    def test_incremental_candidates_are_published_with_stable_ids(self):
        updates = []
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_live_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for frame_index in range(60):
                writer.write(self.make_frame(12 <= frame_index < 42))
            writer.release()
            result = detect_cta_image_candidates(
                path, sample_interval=0.2, max_samples=100,
                candidate_callback=lambda items, done, total: updates.append((done, total, list(items)))
            )
        self.assertTrue(updates)
        partial = [items for _done, _total, items in updates if items]
        self.assertTrue(partial, "CTA candidates should be emitted before the scan completes")
        first_id = partial[0][0]["scan_id"]
        self.assertTrue(any(item["scan_id"] == first_id for batch in partial for item in batch))
        self.assertTrue(result["candidates"])

    def test_scan_can_pause_and_resume_without_restarting(self):
        import threading
        import time
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_pause_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for frame_index in range(60):
                writer.write(self.make_frame(12 <= frame_index < 42))
            writer.release()

            pause = threading.Event()
            paused = threading.Event()
            progress = []
            errors = []
            pause_triggered = []
            # Keep this control-flow test fast and deterministic. OCR itself is
            # covered by dedicated end-to-end tests above. Returning a stable
            # Subscribe detection also exercises the pass-2 resume path.
            fake_detection = {
                "x": 420, "y": 285, "w": 175, "h": 50, "confidence": 88.0,
                "kind": "text_en", "method": "OCR test", "label": "Subscribe",
                "text": "SUBSCRIBE", "evidence": ["text_en"],
                "location": "dưới", "animated": False,
            }
            def on_progress(done, total):
                progress.append(done)
                if done == 2 and not pause_triggered:
                    pause_triggered.append(True)
                    pause.set()
            def run_scan():
                try:
                    with mock.patch(
                        "cta_detector.find_subscribe_regions", return_value=[fake_detection]
                    ):
                        detect_cta_image_candidates(
                            path, sample_interval=0.1, max_samples=100,
                            pause_event=pause, pause_callback=paused.set,
                            progress_callback=on_progress,
                        )
                except Exception as exc:
                    errors.append(exc)
            thread = threading.Thread(target=run_scan, daemon=True)
            thread.start()
            self.assertTrue(paused.wait(5), "scanner did not enter paused state")
            paused_progress = list(progress)
            time.sleep(0.2)
            self.assertEqual(progress, paused_progress, "sample progress must stop while paused")
            pause.clear()
            thread.join(8)
            self.assertFalse(thread.is_alive(), "scanner did not resume")
            self.assertFalse(errors, f"scan failed after resume: {errors}")
            self.assertGreater(progress[-1], paused_progress[-1])


    def test_cancel_unblocks_a_paused_scan(self):
        import threading
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "cta_cancel_paused_test.mp4")
            writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (640, 360))
            self.assertTrue(writer.isOpened())
            for _ in range(30):
                writer.write(self.make_frame(True))
            writer.release()
            pause = threading.Event(); pause.set()
            cancel = threading.Event()
            paused = threading.Event()
            errors = []
            def run_scan():
                try:
                    detect_cta_image_candidates(
                        path, sample_interval=0.1, max_samples=100,
                        pause_event=pause, cancel_event=cancel,
                        pause_callback=paused.set,
                    )
                except Exception as exc:
                    errors.append(exc)
            thread = threading.Thread(target=run_scan, daemon=True)
            thread.start()
            self.assertTrue(paused.wait(5), "scanner did not enter paused state")
            cancel.set()
            thread.join(3)
            self.assertFalse(thread.is_alive(), "cancel must release a paused scan")
            self.assertEqual(len(errors), 1)
            self.assertIsInstance(errors[0], CTAScanCancelled)


if __name__ == "__main__":
    unittest.main()
