import tempfile
import threading
import time
import unittest
import sys
from pathlib import Path
from unittest import mock

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cta_detector


class CTAResumeRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.video_path = str(Path(self.temp_dir.name) / "resume_recovery.mp4")
        writer = cv2.VideoWriter(
            self.video_path,
            cv2.VideoWriter_fourcc(*"mp4v"),
            10.0,
            (640, 360),
        )
        self.assertTrue(writer.isOpened(), "OpenCV cannot create the synthetic test video")
        for index in range(80):
            frame = np.full((360, 640, 3), 32 + (index % 150), dtype=np.uint8)
            writer.write(frame)
        writer.release()

    def tearDown(self):
        self.temp_dir.cleanup()

    def _scan(self, **kwargs):
        with mock.patch.object(cta_detector, "get_subscribe_ocr_status", return_value={"ready": True}):
            return cta_detector.detect_cta_image_candidates(
                self.video_path,
                sample_interval=0.5,
                max_samples=100,
                **kwargs,
            )

    def test_tesseract_timeout_skips_one_sample_and_scan_continues(self):
        calls = []
        progress = []

        def flaky_ocr(_frame, **_kwargs):
            calls.append(len(calls) + 1)
            if len(calls) == 2:
                raise RuntimeError("Tesseract OCR quá thời gian khi đọc khung hình: process timeout")
            return []

        with mock.patch.object(cta_detector, "find_subscribe_regions", side_effect=flaky_ocr):
            result = self._scan(progress_callback=lambda done, total: progress.append((done, total)))

        self.assertEqual(result["ocr_timeouts"], 1)
        self.assertEqual(len(calls), result["pass1_samples"])
        self.assertEqual(progress[-1][0], progress[-1][1])
        self.assertEqual(result["samples"], result["pass1_samples"])
        self.assertIn("Bỏ qua 1 khung hình OCR Timeout", result["note"])

    def test_pause_resume_keeps_sample_order_and_exact_checkpoint(self):
        pause = threading.Event()
        paused = threading.Event()
        progress = []
        checkpoints = []
        pause_triggered = []
        pause_notifications = []
        errors = []

        def on_progress(done, total):
            progress.append(done)
            if done == 2 and not pause_triggered:
                pause_triggered.append(True)
                pause.set()

        def run_scan():
            try:
                with mock.patch.object(cta_detector, "find_subscribe_regions", return_value=[]):
                    self._scan(
                        pause_event=pause,
                        pause_callback=lambda: (pause_notifications.append(True), paused.set()),
                        progress_callback=on_progress,
                        checkpoint_callback=checkpoints.append,
                    )
            except Exception as exc:  # pragma: no cover - failure is asserted below
                errors.append(exc)

        thread = threading.Thread(target=run_scan, daemon=True)
        thread.start()
        self.assertTrue(paused.wait(5), "scanner did not acknowledge Pause")
        paused_progress = list(progress)
        paused_checkpoint = list(checkpoints)
        time.sleep(0.2)
        self.assertEqual(progress, paused_progress, "progress must stay still while paused")
        self.assertEqual(checkpoints, paused_checkpoint, "checkpoint must stay still while paused")

        pause.clear()
        thread.join(8)
        self.assertFalse(thread.is_alive(), "scanner did not resume")
        self.assertFalse(errors, f"scan failed after Resume: {errors}")
        self.assertEqual(progress, list(range(1, len(progress) + 1)), "Resume must not replay samples")
        self.assertEqual(len(pause_notifications), 1, "Pause acknowledgement should be emitted once")
        self.assertGreater(progress[-1], paused_progress[-1])
        self.assertEqual(len(checkpoints), len(progress))
        self.assertEqual(checkpoints, sorted(checkpoints))


if __name__ == "__main__":
    unittest.main()
