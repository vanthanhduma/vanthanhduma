from pathlib import Path
import ast
import re

ROOT = Path(__file__).resolve().parents[1]

def test_nav_labels_escape_qt_mnemonics():
    source = (ROOT / "qt_app.py").read_text(encoding="utf-8")
    assert 'def _qt_button_label(text: str)' in source
    assert 'return str(text).replace("&", "&&")' in source
    assert 'btn = QPushButton(_qt_button_label(label))' in source

def test_sidebar_is_wide_enough_and_section_headers_are_transparent():
    source = (ROOT / "qt_app.py").read_text(encoding="utf-8")
    assert "SIDEBAR_MIN_WIDTH = 224" in source
    assert "SIDEBAR_WIDTH = 240" in source
    assert "SIDEBAR_MAX_WIDTH = 252" in source
    assert 'background:transparent; color:{MUTED}' in source
    assert "splitter.setSizes([SIDEBAR_WIDTH, 1600 - SIDEBAR_WIDTH])" in source
