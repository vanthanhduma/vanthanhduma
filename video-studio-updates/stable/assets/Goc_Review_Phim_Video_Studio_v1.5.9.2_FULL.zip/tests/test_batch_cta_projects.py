from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from batch_cta_projects import _path_record, save_batch_cta_project


class BatchCTAProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.video = self.root / "source" / "Film A.mp4"
        self.video.parent.mkdir()
        self.video.write_bytes(b"test-source-video-bytes")
        self.project = self.root / "projects" / "Film A" / "Film A.grproj"

    def tearDown(self):
        self.temp.cleanup()

    def test_creates_schema_v4_project_and_cta_cache_with_thumbnail(self):
        result = save_batch_cta_project(
            self.video,
            self.project,
            {"width": 1920, "height": 1080, "duration": 123.5, "fps": 25.0},
            {
                "duration": 123.5,
                "samples": 62,
                "pass1_samples": 62,
                "pass2_samples": 0,
                "sample_interval": 2.0,
                "pass1_interval": 2.0,
                "pass2_interval": 0.0,
                "candidates": [{
                    "scan_id": 2, "start": 15.0, "end": 18.0, "duration": 3.0,
                    "sample_time": 16.0, "confidence": 91.0, "peak_confidence": 96.0,
                    "samples": 3, "label": "SUBSCRIBE", "terms": ["SUBSCRIBE"],
                    "evidence": ["ocr_text"], "x": 10, "y": 20, "w": 300, "h": 80,
                }],
            },
            "1.5.8.0",
            thumbnail_bytes={0: b"mock-jpeg-evidence"},
        )
        self.assertTrue(self.project.is_file())
        payload = json.loads(self.project.read_text(encoding="utf-8"))
        self.assertEqual(payload["format"], "goc-review-phim-video-studio-project")
        self.assertEqual(payload["schema_version"], 4)
        self.assertEqual(payload["app_version"], "1.5.8.0")
        self.assertEqual(payload["media"]["video"]["absolute"], str(self.video.resolve()))
        self.assertEqual(payload["media"]["video"]["video_width"] if "video_width" in payload["media"]["video"] else payload["media"]["video_width"], 1920)
        cache_path = Path(result["cache_path"])
        self.assertTrue(cache_path.is_file())
        cache = json.loads(cache_path.read_text(encoding="utf-8"))
        self.assertTrue(cache["complete"])
        self.assertEqual(cache["video_path"], str(self.video.resolve()))
        self.assertEqual(len(cache["candidates"]), 1)
        thumbnail_rel = cache["candidates"][0]["thumbnail"]
        thumbnail = cache_path.parent / thumbnail_rel
        self.assertTrue(thumbnail.is_file())
        self.assertEqual(thumbnail.read_bytes(), b"mock-jpeg-evidence")
        self.assertEqual(result["candidate_count"], 1)

    def test_absolute_paths_remain_valid_if_windows_drives_differ(self):
        with patch("batch_cta_projects.os.path.relpath", side_effect=ValueError("different drives")):
            record = _path_record(self.video, self.project.parent)
        self.assertEqual(record["absolute"], str(self.video.resolve()))
        self.assertEqual(record["relative"], "")


if __name__ == "__main__":
    unittest.main()
