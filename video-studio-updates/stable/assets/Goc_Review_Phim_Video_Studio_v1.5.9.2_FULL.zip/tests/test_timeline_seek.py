from __future__ import annotations

import unittest
from timeline_seek import parse_timecode, format_timecode


class TimelineSeekTests(unittest.TestCase):
    def test_parse_full_timecode_with_milliseconds(self):
        self.assertAlmostEqual(parse_timecode("01:02:03.500"), 3723.5)

    def test_parse_minutes_seconds(self):
        self.assertAlmostEqual(parse_timecode("12:34"), 754.0)

    def test_parse_seconds(self):
        self.assertAlmostEqual(parse_timecode("75.25"), 75.25)

    def test_format_milliseconds_round_trip(self):
        value = 3723.456
        self.assertAlmostEqual(parse_timecode(format_timecode(value)), value)

    def test_reject_invalid_seconds_field(self):
        with self.assertRaises(ValueError):
            parse_timecode("00:61:00")

    def test_reject_negative_and_non_finite(self):
        for bad in ("-1", "nan", "inf"):
            with self.assertRaises(ValueError):
                parse_timecode(bad)


if __name__ == "__main__":
    unittest.main()
