from __future__ import annotations

import base64
import hashlib
import json
import zipfile
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from updater.apply_helper import apply_update, recover_incomplete_transactions
from updater.core import (
    APP_ID, PUBLIC_ASSET_ROOT, MANIFEST_URL, PublicUpdateClient, UpdateError,
    extract_and_verify_package, is_newer, validate_manifest, verify_manifest_signature,
)


def _manifest(files, version="1.5.6.0"):
    return {
        "schema_version": 1,
        "app_id": APP_ID,
        "channel": "stable",
        "version": version,
        "base_version": "1.5.5.0",
        "asset_name": "test_UPDATE.zip",
        "asset_size": 10,
        "asset_sha256": "a" * 64,
        "files": files,
    }



def test_https_sha256_manifest_is_accepted_without_signing_key(monkeypatch, tmp_path):
    manifest = _manifest([{"path": "qt_app.py", "size": 1, "sha256": "a" * 64}])
    manifest.update({
        "trust_mode": "https-sha256-v1",
        "asset_url": PUBLIC_ASSET_ROOT + "test_UPDATE.zip",
    })
    raw = json.dumps(manifest, sort_keys=True).encode("utf-8")

    def fake_fetch_bytes(self, url, max_bytes=2 * 1024 * 1024):
        assert url == MANIFEST_URL
        return raw

    monkeypatch.setattr(PublicUpdateClient, "fetch_bytes", fake_fetch_bytes)
    result = PublicUpdateClient().fetch_manifest("1.5.5.0", tmp_path / "no-private-key-needed.pem")
    assert result is not None
    checked, _release = result
    assert checked["version"] == "1.5.6.0"
    assert checked["_signature_bytes_b64"] == ""


def test_https_sha256_apply_requires_explicit_trust_mode(tmp_path, monkeypatch):
    import updater.apply_helper as helper
    monkeypatch.setattr(helper, "_wait_for_pid", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(helper, "_health_check", lambda *_args, **_kwargs: None)

    root = tmp_path / "app"
    root.mkdir()
    (root / "PHIEN_BAN.txt").write_text("Video Studio v1.5.5.5\n", encoding="utf-8")
    (root / "qt_app.py").write_text("old", encoding="utf-8")

    stage = tmp_path / "stage"
    payload = stage / "verified" / "payload"
    payload.mkdir(parents=True)
    body = b"new app code"
    (payload / "qt_app.py").write_bytes(body)
    version_body = b"Goc Review Phim Video Studio v1.5.5.6\n"
    (payload / "PHIEN_BAN.txt").write_bytes(version_body)
    manifest = _manifest([
        {"path": "qt_app.py", "size": len(body), "sha256": hashlib.sha256(body).hexdigest()},
        {"path": "PHIEN_BAN.txt", "size": len(version_body), "sha256": hashlib.sha256(version_body).hexdigest()},
    ], version="1.5.5.6")
    manifest.update({
        "base_version": "1.5.5.5",
        "trust_mode": "https-sha256-v1",
        "asset_url": PUBLIC_ASSET_ROOT + "test_UPDATE.zip",
    })
    (stage / "update-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    apply_update(root, stage, pid=12345, python_exe=Path(__import__("sys").executable))
    assert (root / "qt_app.py").read_bytes() == body
    assert (root / "PHIEN_BAN.txt").read_bytes() == version_body


def test_download_rejects_redirect_to_different_host(tmp_path):
    class Response:
        url = "https://updates.example.invalid/package.zip"
        status_code = 200
        headers = {"Content-Type": "application/zip"}

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        def iter_content(self, chunk_size=1024):
            yield b"unexpected"

        def raise_for_status(self):
            return None

    class Session:
        def get(self, *_args, **_kwargs):
            return Response()

    client = PublicUpdateClient()
    client.session = Session()
    with pytest.raises(UpdateError, match="chuyển hướng khỏi GitHub HTTPS chính chủ"):
        client.download_asset(PUBLIC_ASSET_ROOT + "test_UPDATE.zip", 10, tmp_path / "package.zip")


def test_manifest_rejects_unsupported_base_before_download(monkeypatch, tmp_path):
    manifest = _manifest([{"path": "PHIEN_BAN.txt", "size": 1, "sha256": "a" * 64}], version="1.5.6.0")
    manifest.update({
        "trust_mode": "https-sha256-v1",
        "asset_url": PUBLIC_ASSET_ROOT + "test_UPDATE.zip",
        "base_version": "1.5.5.6",
    })
    raw = json.dumps(manifest, sort_keys=True).encode("utf-8")

    monkeypatch.setattr(PublicUpdateClient, "fetch_bytes", lambda self, url, max_bytes=2 * 1024 * 1024: raw)
    with pytest.raises(UpdateError, match="không hỗ trợ nâng cấp trực tiếp"):
        PublicUpdateClient().fetch_manifest("1.5.5.5", tmp_path / "unused.pem")


def test_apply_rolls_back_when_version_file_was_omitted(tmp_path, monkeypatch):
    import updater.apply_helper as helper
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local"))
    monkeypatch.setattr(helper, "_wait_for_pid", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(helper, "_health_check", lambda *_args, **_kwargs: None)

    root = tmp_path / "app"
    root.mkdir()
    (root / "PHIEN_BAN.txt").write_text("Video Studio v1.5.5.5\n", encoding="utf-8")
    (root / "qt_app.py").write_text("old", encoding="utf-8")
    stage = tmp_path / "stage"
    payload = stage / "verified" / "payload"
    payload.mkdir(parents=True)
    body = b"new app code"
    (payload / "qt_app.py").write_bytes(body)
    manifest = _manifest([{
        "path": "qt_app.py", "size": len(body), "sha256": hashlib.sha256(body).hexdigest()
    }], version="1.5.5.6")
    manifest.update({
        "base_version": "1.5.5.5",
        "trust_mode": "https-sha256-v1",
        "asset_url": PUBLIC_ASSET_ROOT + "test_UPDATE.zip",
    })
    (stage / "update-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    with pytest.raises(UpdateError, match="PHIEN_BAN.txt không khớp"):
        apply_update(root, stage, pid=12345, python_exe=Path(__import__("sys").executable))
    assert (root / "qt_app.py").read_text(encoding="utf-8") == "old"


def test_unsigned_manifest_without_https_trust_mode_is_rejected(tmp_path, monkeypatch):
    import updater.apply_helper as helper
    monkeypatch.setattr(helper, "_wait_for_pid", lambda *_args, **_kwargs: None)
    root = tmp_path / "app"
    root.mkdir()
    (root / "PHIEN_BAN.txt").write_text("Video Studio v1.5.5.5\n", encoding="utf-8")
    stage = tmp_path / "stage"
    (stage / "verified" / "payload").mkdir(parents=True)
    manifest = _manifest([{"path": "qt_app.py", "size": 0, "sha256": hashlib.sha256(b"").hexdigest()}], version="1.5.5.6")
    (stage / "update-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(UpdateError, match="không có chữ ký"):
        apply_update(root, stage, pid=12345, python_exe=Path(__import__("sys").executable))


def test_semver_comparison():
    assert is_newer("1.5.6.0", "1.5.5.0")
    assert not is_newer("1.5.5.0", "1.5.5.0")
    assert not is_newer("1.5.4.9", "1.5.5.0")


def test_reject_invalid_app_id_and_version():
    data = _manifest([{"path": "qt_app.py", "size": 1, "sha256": "a" * 64}])
    data["app_id"] = "other-app"
    with pytest.raises(UpdateError):
        validate_manifest(data)
    data = _manifest([{"path": "qt_app.py", "size": 1, "sha256": "a" * 64}], version="latest")
    with pytest.raises(UpdateError):
        validate_manifest(data)


@pytest.mark.parametrize("path", ["../app.py", "/app.py", "C:/app.py", "..\\app.py", ".venv/x", "projects/a.grproj", "user_settings.json", "CON.txt", "folder./app.py", "app.py:stream"])
def test_manifest_rejects_unsafe_or_preserved_paths(path):
    data = _manifest([{"path": path, "size": 1, "sha256": "a" * 64}])
    with pytest.raises(UpdateError):
        validate_manifest(data)



def test_manifest_allows_versioned_tessdata_assets():
    data = _manifest([{"path": "assets/tessdata/vie.traineddata", "size": 1, "sha256": "a" * 64}])
    assert validate_manifest(data)["files"][0]["path"] == "assets/tessdata/vie.traineddata"


def test_legacy_signature_only_allows_existing_1552_feed(tmp_path, monkeypatch):
    new_private = Ed25519PrivateKey.generate()
    old_private = Ed25519PrivateKey.generate()
    public_path = tmp_path / "update-public-key.pem"
    legacy_path = tmp_path / "update-public-key-legacy.pem"
    public_path.write_bytes(new_private.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    ))
    legacy_path.write_bytes(old_private.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    ))

    import updater.core as updater_core
    old_manifest = json.dumps({"version": "1.5.5.2"}, sort_keys=True).encode()
    monkeypatch.setattr(updater_core, "LEGACY_MANIFEST_SHA256", hashlib.sha256(old_manifest).hexdigest())
    old_signature = base64.b64encode(old_private.sign(old_manifest))
    assert verify_manifest_signature(old_manifest, old_signature, public_path) == {"version": "1.5.5.2"}

    # Even a valid legacy signature is rejected if it is not the one exact
    # historical manifest that was already trusted by v1.5.5.2.
    altered_same_version = json.dumps({"version": "1.5.5.2", "changed": True}, sort_keys=True).encode()
    altered_signature = base64.b64encode(old_private.sign(altered_same_version))
    with pytest.raises(UpdateError):
        verify_manifest_signature(altered_same_version, altered_signature, public_path)

    forged_future_manifest = json.dumps({"version": "1.5.5.3"}, sort_keys=True).encode()
    forged_future_signature = base64.b64encode(old_private.sign(forged_future_manifest))
    with pytest.raises(UpdateError):
        verify_manifest_signature(forged_future_manifest, forged_future_signature, public_path)

    new_manifest = json.dumps({"version": "1.5.5.3"}, sort_keys=True).encode()
    new_signature = base64.b64encode(new_private.sign(new_manifest))
    assert verify_manifest_signature(new_manifest, new_signature, public_path) == {"version": "1.5.5.3"}

def test_manifest_rejects_duplicate_paths():
    entry = {"path": "qt_app.py", "size": 1, "sha256": "a" * 64}
    with pytest.raises(UpdateError):
        validate_manifest(_manifest([entry, dict(entry)]))
    second = {"path": "QT_APP.py", "size": 1, "sha256": "b" * 64}
    with pytest.raises(UpdateError):
        validate_manifest(_manifest([entry, second]))


def test_manifest_signature_valid_and_tampered(tmp_path):
    private = Ed25519PrivateKey.generate()
    public_path = tmp_path / "public.pem"
    public_path.write_bytes(private.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    ))
    raw = json.dumps({"hello": "world"}).encode()
    signature = base64.b64encode(private.sign(raw))
    assert verify_manifest_signature(raw, signature, public_path) == {"hello": "world"}
    with pytest.raises(UpdateError):
        verify_manifest_signature(raw + b"!", signature, public_path)


def test_zip_extract_validates_all_payload_hashes(tmp_path):
    body = b"print('safe')\n"
    digest = hashlib.sha256(body).hexdigest()
    manifest = _manifest([{"path": "qt_app.py", "size": len(body), "sha256": digest}])
    zip_path = tmp_path / "update.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("payload/qt_app.py", body)
    output = extract_and_verify_package(zip_path, manifest, tmp_path / "stage")
    assert (output / "payload/qt_app.py").read_bytes() == body


def test_zip_rejects_path_traversal(tmp_path):
    body = b"bad"
    manifest = _manifest([{"path": "app.py", "size": len(body), "sha256": hashlib.sha256(body).hexdigest()}])
    zip_path = tmp_path / "bad.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("payload/../app.py", body)
    with pytest.raises(UpdateError):
        extract_and_verify_package(zip_path, manifest, tmp_path / "stage")


def test_zip_rejects_unlisted_file(tmp_path):
    body = b"safe"
    manifest = _manifest([{"path": "qt_app.py", "size": len(body), "sha256": hashlib.sha256(body).hexdigest()}])
    zip_path = tmp_path / "extra.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("payload/qt_app.py", body)
        zf.writestr("payload/unexpected.py", b"extra")
    with pytest.raises(UpdateError):
        extract_and_verify_package(zip_path, manifest, tmp_path / "stage")


def test_zip_rejects_hash_mismatch(tmp_path):
    manifest = _manifest([{"path": "qt_app.py", "size": 4, "sha256": "0" * 64}])
    zip_path = tmp_path / "wrong.zip"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("payload/qt_app.py", b"code")
    with pytest.raises(UpdateError):
        extract_and_verify_package(zip_path, manifest, tmp_path / "stage")


def test_helper_recovers_interrupted_transaction(tmp_path, monkeypatch):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local"))
    root = tmp_path / "app"
    root.mkdir()
    (root / "qt_app.py").write_text("new version", encoding="utf-8")
    backup = tmp_path / "local" / "GocReviewVideoStudio" / "updater" / "backups" / "test-backup"
    old = backup / "qt_app.py"
    old.parent.mkdir(parents=True)
    old.write_text("old version", encoding="utf-8")
    journal = {
        "root": str(root.resolve()),
        "status": "applying",
        "files": [{"path": "qt_app.py", "existed": True}, {"path": "new_module.py", "existed": False}],
    }
    (backup / "transaction.json").write_text(json.dumps(journal), encoding="utf-8")
    (root / "new_module.py").write_text("partial", encoding="utf-8")
    (root / "qt_app.py.updater-tmp").write_text("partial temp", encoding="utf-8")

    recovered = recover_incomplete_transactions(root)

    assert recovered == [str(backup)]
    assert (root / "qt_app.py").read_text(encoding="utf-8") == "old version"
    assert not (root / "new_module.py").exists()
    assert not (root / "qt_app.py.updater-tmp").exists()
    saved = json.loads((backup / "transaction.json").read_text(encoding="utf-8"))
    assert saved["status"] == "rolled_back_after_interruption"
