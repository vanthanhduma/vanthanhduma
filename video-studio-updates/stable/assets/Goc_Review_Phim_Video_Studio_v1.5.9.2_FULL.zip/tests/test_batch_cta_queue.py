from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from batch_cta_queue import BatchCTAQueue


class BatchCTAQueueTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.out = self.root / "BatchProjects"
        self.out.mkdir()
        self.video_dir_a = self.root / "A"
        self.video_dir_b = self.root / "B"
        self.video_dir_a.mkdir()
        self.video_dir_b.mkdir()
        self.video_a = self.video_dir_a / "same.mp4"
        self.video_b = self.video_dir_b / "same.mp4"
        self.video_a.write_bytes(b"video-a")
        self.video_b.write_bytes(b"video-b")

    def tearDown(self):
        self.temp.cleanup()

    def test_create_queue_deduplicates_same_source_and_persists(self):
        queue = BatchCTAQueue.create([self.video_a, self.video_a], self.out)
        self.assertEqual(len(queue.jobs), 1)
        self.assertEqual(queue.jobs[0]["status"], "queued")
        self.assertTrue(queue.state_path.is_file())
        loaded = BatchCTAQueue.load(queue.state_path)
        self.assertEqual(loaded.jobs[0]["source_path"], str(self.video_a.resolve()))

    def test_duplicate_video_names_get_different_project_folders(self):
        queue = BatchCTAQueue.create([self.video_a, self.video_b], self.out)
        self.assertEqual(len(queue.jobs), 2)
        self.assertNotEqual(queue.jobs[0]["project_dir"], queue.jobs[1]["project_dir"])
        self.assertEqual(Path(queue.jobs[0]["project_path"]).name, "same.grproj")
        self.assertEqual(Path(queue.jobs[1]["project_path"]).name, "same.grproj")

    def test_interrupted_scan_is_requeued_but_completed_job_is_not_repeated(self):
        queue = BatchCTAQueue.create([self.video_a, self.video_b], self.out)
        first_id, second_id = [job["id"] for job in queue.jobs]
        queue.set_status(first_id, "completed")
        queue.set_status(second_id, "scanning", progress=43)
        restored = BatchCTAQueue.load(queue.state_path)
        self.assertEqual(restored.jobs[0]["status"], "completed")
        self.assertEqual(restored.jobs[1]["status"], "queued")
        self.assertEqual(restored.jobs[1]["progress"], 0)
        self.assertEqual(restored.next_job()["id"], second_id)

    def test_failed_job_is_queued_for_retry_when_resuming(self):
        queue = BatchCTAQueue.create([self.video_a], self.out)
        queue.set_status(queue.jobs[0]["id"], "failed", error="OCR timeout")
        restored = BatchCTAQueue.load(queue.state_path)
        self.assertEqual(restored.jobs[0]["status"], "queued")
        self.assertIn("OCR timeout", restored.jobs[0]["error"])

    def test_sequential_guard_rejects_second_active_job(self):
        queue = BatchCTAQueue.create([self.video_a, self.video_b], self.out)
        queue.set_status(queue.jobs[0]["id"], "scanning")
        with self.assertRaises(RuntimeError):
            queue.next_job()

    def test_stop_safely_persists_active_job_as_queued(self):
        queue = BatchCTAQueue.create([self.video_a], self.out)
        queue.set_status(queue.jobs[0]["id"], "saving")
        queue.stop_safely()
        saved = json.loads(queue.state_path.read_text(encoding="utf-8"))
        self.assertEqual(saved["status"], "stopped")
        self.assertEqual(saved["jobs"][0]["status"], "queued")

    def test_missing_source_is_rejected(self):
        with self.assertRaises(FileNotFoundError):
            BatchCTAQueue.create([self.root / "missing.mp4"], self.out)


if __name__ == "__main__":
    unittest.main()
