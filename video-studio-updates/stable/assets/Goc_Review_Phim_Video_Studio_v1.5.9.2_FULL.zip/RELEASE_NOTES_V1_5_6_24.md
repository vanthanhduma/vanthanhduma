# Góc Review Phim Video Studio v1.5.6.24

## Cắt đúng nghĩa

- Đổi **Xuất đoạn Từ–Đến** thành **Cắt bỏ & xuất phần còn lại**.
- Khoảng Từ–Đến được loại khỏi video, phần trước và sau được nối lại đồng bộ hình/tiếng.
- Video gốc không bị ghi đè; các khoảng đã bỏ được lưu theo dự án để không bị xuất lại nhầm.

## Xem video gốc

- Giữ nút **Phát video gốc Từ–Đến** để duyệt trước khoảng cần bỏ.
- Kết hợp tối ưu preview rolling-buffer của v1.5.6.23 để giảm lag và không tích file tạm dài hạn.
