# v1.5.5.2 — Public One-Click Updater + Startup Reliability

- Tích hợp sẵn updater Stable công khai qua HTTPS; không cần token, đăng nhập hoặc kết nối GitHub.
- Giữ repository source ở chế độ riêng tư; kênh phân phối chỉ chứa manifest đã ký và gói cập nhật nhị phân.
- Bổ sung launcher có log để phát hiện lỗi khi khởi động lại sau cập nhật.
- Sửa process handoff: helper chờ GUI thoát bằng cơ chế đồng bộ process của Windows, hoàn tất transaction và dọn staging trước khi gọi launcher.
- Giữ nguyên project, Auto Save, settings, Branding cá nhân, video, output và `.venv` trong cập nhật incremental.
- Không thay đổi engine video hoặc project schema.
