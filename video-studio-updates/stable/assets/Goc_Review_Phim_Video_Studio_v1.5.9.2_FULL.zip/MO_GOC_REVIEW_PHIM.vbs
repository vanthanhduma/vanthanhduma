Option Explicit
Dim fso, sh, root, python, launcher, cmd, rc, logPath
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
python = root & "\.venv\Scripts\pythonw.exe"
If Not fso.FileExists(python) Then python = root & "\.venv\Scripts\python.exe"
launcher = root & "\launcher.py"
logPath = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\GocReviewVideoStudio\logs\launcher.log"

If Not fso.FileExists(root & "\qt_app.py") Or Not fso.FileExists(launcher) Then
    MsgBox "Khong tim thay giao dien Qt hoac launcher.py." & vbCrLf & root, vbCritical, "Goc Review Phim"
    WScript.Quit 1
End If
If Not fso.FileExists(python) Then
    MsgBox "Tool chua duoc cai dat day du." & vbCrLf & _
           "Hay chay CAI_DAT_VA_CHAY.bat mot lan de cai Python va thu vien.", _
           vbInformation, "Goc Review Phim"
    WScript.Quit 2
End If

sh.CurrentDirectory = root
cmd = Chr(34) & python & Chr(34) & " " & Chr(34) & launcher & Chr(34)
' WindowStyle 0 prevents console windows; launcher redirects child output to launcher.log.
rc = sh.Run(cmd, 0, True)
If rc <> 0 Then
    MsgBox "Khong the khoi dong Video Studio (ma loi " & rc & ")." & vbCrLf & _
           "Nhat ky: " & logPath, vbCritical, "Goc Review Phim"
    WScript.Quit rc
End If
WScript.Quit 0
