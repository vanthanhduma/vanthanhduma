# v1.5.5.6 — Auto Update Bootstrap

- Hoàn thiện cập nhật một lần bấm: kiểm tra → tải → xác minh SHA-256 → chờ tác vụ rảnh → sao lưu → áp dụng → health-check → tự khởi động lại.
- Chuyển kênh phát hành Stable sang HTTPS cố định của kho GitHub chính chủ kết hợp SHA-256 cho gói và từng file; không cần PAT, GitHub Secrets, Environment hoặc private signing key trên máy người dùng.
- Giữ hỗ trợ manifest Ed25519 cũ để tương thích trong giai đoạn chuyển đổi.
- Giữ bản sửa Tesseract OCR của v1.5.5.5.
- Giữ nguyên project, Auto Save, settings, Branding, video nguồn, output và môi trường Python.
