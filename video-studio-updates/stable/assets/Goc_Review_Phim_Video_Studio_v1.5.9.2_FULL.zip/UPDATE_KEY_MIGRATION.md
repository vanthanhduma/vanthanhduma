# Auto Update trust migration — v1.5.5.6

Bắt đầu từ v1.5.5.6, Stable feed dùng HTTPS từ đúng repository GitHub đã cấu hình, kèm SHA-256 của gói ZIP và từng file payload. Requests bật xác minh TLS mặc định; redirect bị giới hạn về đúng host `raw.githubusercontent.com`; asset URL bị giới hạn vào đúng thư mục phát hành.

Không còn yêu cầu private signing key, PAT, GitHub Actions Secret hoặc Environment để máy người dùng kiểm tra/tải update. Các manifest Ed25519 cũ vẫn được hỗ trợ trong giai đoạn chuyển đổi.

SHA-256 không thay thế TLS: ứng dụng chỉ nhận manifest qua HTTPS từ `vanthanhduma/vanthanhduma` và từ chối host/đường dẫn khác. Repository phân phối cần bật 2FA, giới hạn quyền ghi và giữ lịch sử commit.

Vì các bản cũ chỉ tin khóa Ed25519 đã nhúng, cần cài bootstrap v1.5.5.6 một lần để chuyển trust mode. Sau đó cập nhật tiếp theo thực hiện hoàn toàn trong app bằng nút **Kiểm tra & cập nhật**.
