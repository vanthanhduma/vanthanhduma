# Release Notes — v1.5.3.0

## Subscribe Detector: narrowed scope and OCR
- Chuyển phạm vi phát hiện thành Subscribe-only: nhận diện từ SUBSCRIBE qua OCR Tesseract.
- Loại bỏ các nhánh nhận diện Like, Share, chuông và end-screen.
- Giữ Pause/Resume, Stop & Keep Results, live incremental candidate updates và manual approval before cut.
- Cải thiện thông báo tình trạng thiếu Tesseract và cung cấp script cài đặt tùy chọn `CAI_TESSERACT_OCR.bat`.

## Timeline navigation
- Thanh seek nhận click trên toàn vùng widget và ánh xạ vị trí click sang thời gian video.
- Giữ thao tác kéo nút trượt truyền thống.
- Thêm ô nhập timecode và nút `Đi tới`; nhận `HH:MM:SS.mmm`, `MM:SS` và số giây.
- Chuyển thanh seek sang độ phân giải mili-giây.
- Không ghi đè vị trí tay khi engine đẩy snapshot trong lúc người dùng kéo.

## Compatibility
- Không đổi project schema.
- Không thay đổi logic cắt/xuất, Mask, Branding, Downloader, Batch hoặc QC.
- Gói phát hành là FULL để tránh nhầm lẫn với các gói UPDATE trước đó.
