# Kiểm thử v1.5.5.3 — Tesseract OCR + Sidebar + Updater Trust Migration

## Kiểm thử trong môi trường dựng

- Full test suite: **70 passed, 21 subtests passed**.
- Biên dịch cú pháp toàn bộ 22 file Python trong gói: PASS.
- Tesseract 5.5.0 nạp hai model `eng` và `vie` từ `assets/tessdata`: PASS.
- Mô phỏng `TESSDATA_PREFIX` trỏ tới thư mục không tồn tại: ứng dụng ghi đè về `assets/tessdata`: PASS.
- OCR ảnh thử chứa `DANG KY KENH` với `lang=vie+eng`: nhận diện `DANG KY KENH`: PASS.
- Sidebar source regression: min 224 px / width 240 px / max 252 px; ký tự `&` được escape cho Qt: PASS.
- Khóa Ed25519 v2 riêng/công khai khớp nhau; khóa riêng không được đưa vào gói phát hành: PASS.
- SHA-256 manifest Stable 1.5.5.2 đang công khai khớp chính xác giá trị giới hạn trong legacy-key bridge: PASS.
- FULL ZIP CRC, cấu trúc flat, 68 file trong manifest + manifest, mọi kích thước và SHA-256: PASS.

## Thay đổi trong bản phát hành

- Tesseract OCR sử dụng đúng hai model tiếng Anh/Việt đi kèm ứng dụng; ép `TESSDATA_PREFIX` về thư mục model của app và truyền `--tessdata-dir` tường minh.
- Sidebar rộng 240 px, tiêu đề nhóm trong suốt có separator; ký tự `&` không còn bị Qt diễn giải thành mnemonic.
- Updater dùng khóa Ed25519 mới. Khóa cũ chỉ được dùng xác minh đúng duy nhất manifest Stable v1.5.5.2 đã phát hành, không thể xác thực bản cập nhật mới.
- Dữ liệu dự án, Auto Save, `user_settings.json`, `.venv`, tải xuống và video xuất không nằm trong ZIP FULL; giải nén đè mã nguồn không xóa các mục này.

## Giới hạn nghiệm thu

- Môi trường dựng không có PySide6 và không phải Windows, vì vậy chưa thể chạy GUI Qt native/DPI hoặc kiểm thử thao tác cài đặt trên Windows tại đây.
- Tesseract được kiểm thử trên môi trường dựng Linux với Tesseract 5.5.0; Windows executable cần được nghiệm thu khi chạy trên máy người dùng.
