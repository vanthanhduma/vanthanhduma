# Góc Review Phim Video Studio v1.5.6.20

## CTA Subscribe

- Chế độ `Quét kỹ` thêm OCR fallback cho banner sáng, chữ nhỏ và trạng thái `SUBSCRIBED`.
- Tăng độ phân giải OCR ở chế độ quét kỹ để giảm bỏ sót chữ trong CTA dạng ảnh ghép.
- Ghi nhận đúng bằng chứng OCR thay vì chỉ phân loại chung là nút / biểu tượng.
- Quét thường giữ nguyên tốc độ và luồng xem/cắt hiện tại.

