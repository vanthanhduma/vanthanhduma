# Góc Review Phim Video Studio v1.5.6.31

## Sửa tình trạng đứng khi tạo Mask
- Chuyển **Tự tách nét (GrabCut)** và **Dùng toàn bộ vùng khoanh** sang tác vụ nền riêng; Tk Engine không phải chờ phép xử lý ảnh hoàn tất.
- Tạo undo snapshot ở luồng nền; chỉ áp dụng kết quả và cập nhật trạng thái trên luồng Tk.
- Khóa thao tác thay đổi video/vùng Mask trong lúc chạy; loại bỏ kết quả cũ nếu video hoặc vùng khoanh thay đổi.
- Giao diện hiển thị trạng thái xử lý và tự bật lại công cụ khi hoàn tất hoặc báo lỗi.
- Preview được thu nhỏ trước khi trộn mask đỏ, giảm cấp phát mảng kích thước toàn khung hình trên video 4K.

## Giữ nguyên
- Brush/Eraser ROI cache, Smart Mask, Undo/Redo, CTA Detector và nút Xóa tất cả, Overlay Detector, Branding, Auto Save, Batch, QC và xuất video.
- Mask lưu/xử lý vẫn giữ độ phân giải gốc; chỉ ảnh preview giao diện được thu nhỏ.

## Nâng cấp
- UPDATE dành riêng cho v1.5.6.30.
- Gói không chứa video nguồn, dự án, .venv, downloads hoặc renders.
- Thêm kiểm thử hồi quy cho Mask background task và preview độ phân giải cao.
