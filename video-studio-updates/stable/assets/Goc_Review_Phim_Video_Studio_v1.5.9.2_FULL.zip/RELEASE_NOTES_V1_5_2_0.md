# Release Notes — v1.5.2.0 CTA Live Scan

## CTA Detector
- Thêm điều khiển **Tạm dừng / Tiếp tục**. Việc tạm dừng xảy ra ở ranh giới giữa hai mẫu hình; tiếp tục sử dụng chính vòng quét hiện tại, không mở lượt mới.
- Thêm **Dừng & giữ kết quả** để kết thúc lượt quét và giữ lại những CTA đã tìm được.
- Kết quả CTA được phát trực tiếp theo từng đợt vào bảng khi có ứng viên đủ điều kiện; không phải đợi toàn bộ video quét xong.
- Cập nhật liên tục thời gian bắt đầu/kết thúc, thời lượng, confidence, loại/vị trí và thumbnail đại diện.
- Duy trì ID ổn định cho từng ứng viên để cập nhật dòng hiện hữu, không nhân đôi dòng hoặc làm mất lựa chọn đã đánh dấu.
- Cho phép xem và chọn ứng viên trong lúc quét; khóa chỉnh mốc/cắt cho đến khi lượt quét hoàn tất hoặc đã dừng để tránh xung đột Engine.
- Nếu người dùng dừng khi đang tạm dừng, lệnh dừng vẫn giải phóng worker và kết thúc an toàn.

## Bảo toàn
- Không thay đổi cách cắt khoảng CTA đã duyệt, đồng bộ audio/video, xuất MP4, downloader, Mask, Branding hay project schema.
- Tất cả CTA vẫn là ứng viên gợi ý thị giác; không tự động cắt.
- Tối đa 1.800 ảnh mẫu như cấu hình trước; pause/resume không làm tăng số mẫu hoặc quét lại từ đầu.
