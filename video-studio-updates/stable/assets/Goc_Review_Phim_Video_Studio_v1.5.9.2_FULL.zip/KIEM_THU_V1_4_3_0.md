# KIỂM THỬ v1.4.3.0 — Transient Overlay Cut Workflow

Ngày kiểm thử: 12/11/2026

## 1. Kiểm thử source và detector

| Hạng mục | Kết quả |
|---|---|
| `py_compile` cho `app.py`, `qt_app.py`, `engine_worker.py`, `gpu_check.py` | PASS |
| Transient profile selection, sample cap và scale 320 px | PASS |
| Synthetic overlay sạch | PASS — không tạo candidate |
| Synthetic logo/banner cố định | PASS — các candidate mong đợi được phát hiện |
| Synthetic banner chớp 0,64 giây | PASS — được phát hiện ở một mẫu, đánh dấu cần review kỹ |
| Synthetic banner xuất hiện khoảng 2 giây | PASS — candidate Banner và occurrence ước tính |
| Hai clip MP4 mẫu người dùng | PASS — Standard/Deep/Transient chạy hết; phát hiện logo/chữ/watermark/banner theo nội dung mẫu |

## 2. Kiểm thử giao diện Detector (Tk processing dialog)

| Ca kiểm thử | Kết quả |
|---|---|
| Mở cửa sổ Detector trong Xvfb | PASS — 1160×790 |
| Có đủ control chọn occurrence, nhập mốc, danh sách khoảng bỏ | PASS |
| Chọn occurrence thứ hai và lấy mốc đề xuất | PASS |
| Thêm, cập nhật, xóa khoảng | PASS |

## 3. Kiểm thử cắt hình/tiếng

| Ca kiểm thử | Kết quả |
|---|---|
| Cắt hai khoảng chồng/tiếp giáp trong clip thử 12 giây | PASS — đầu ra đúng 3 giây; QC 10 đạt / 0 cảnh báo / 0 lỗi |
| Cắt clip không có audio | PASS — đầu ra đúng 6 giây; QC 10 đạt / 0 cảnh báo / 0 lỗi |
| Xuất đoạn trên clip mẫu thật 1280×720, 25 FPS | PASS — đoạn nguồn 6 giây, bỏ 0,5 giây, đầu ra 5,5 giây; QC 10 đạt / 0 cảnh báo / 0 lỗi |
| Đồng bộ stream audio/video của clip mẫu thật | PASS — video 5,48 giây, audio 5,50 giây, sai lệch 0,02 giây |
| Chuẩn hóa khoảng âm, vượt thời lượng, trùng/chồng lấn | PASS — clamp, bỏ khoảng không hợp lệ và merge đúng |

## 4. Kiểm thử dự án

| Ca kiểm thử | Kết quả |
|---|---|
| Project schema 4: lưu/mở lại các khoảng bỏ | PASS |
| Project schema 3: mở tương thích ngược | PASS — không áp dụng nhầm khoảng bỏ mới |

## 5. Giới hạn và nghiệm thu cần làm trên Windows

- Môi trường build không có PySide6 nên không thể khởi chạy Qt main window thật trong lượt kiểm thử này. Cửa sổ Detector thuộc processing engine đã được smoke test dưới Xvfb; người dùng cần xác nhận bản cập nhật trên Windows sau khi chép UPDATE.
- Ảnh chụp từ người dùng xác nhận Qt GUI của v1.4.2.0 đang mở được trên Windows; điều đó chưa thay thế nghiệm thu Qt GUI sau khi cập nhật v1.4.3.0.
- Chưa benchmark video dài hàng chục phút/giờ trên Windows RTX 2070 Super Max-Q. Transient giới hạn 1.800 mẫu và 320 px chiều rộng để hạn chế RAM; với video rất dài khoảng lấy mẫu thực tế sẽ thưa hơn 2 ảnh/giây.
- Detector heuristic có thể bỏ sót overlay mờ/di chuyển hoặc nhận nhầm thành phần đồ họa. Candidate chỉ là gợi ý; người dùng phải xem lại thời điểm và xác nhận khoảng bỏ.
- Các bài xuất ở môi trường build chạy CPU x264; NVENC trên laptop Windows không được nghiệm thu lại trong lượt này.

## Kết luận

Các kiểm thử thực thi được trong môi trường build đều PASS. Bản 1.4.3.0 có luồng Transient → review occurrence → xác nhận khoảng bỏ → cắt đồng bộ hình/tiếng khi export. Đây là bản sẵn sàng để cập nhật và nghiệm thu GUI trên Windows; không tuyên bố đã hoàn tất nghiệm thu Qt/NVENC trên laptop người dùng.
