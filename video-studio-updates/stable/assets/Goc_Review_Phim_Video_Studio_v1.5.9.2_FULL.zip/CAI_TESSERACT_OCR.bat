@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Cai Tesseract OCR cho CTA Subscribe Detector

echo.
echo =====================================================
echo   TESSERACT OCR - CTA SUBSCRIBE DETECTOR
echo =====================================================
echo.
where tesseract >nul 2>nul
if not errorlevel 1 (
  echo Tesseract OCR da co trong PATH.
  tesseract --version
  echo.
  echo Video Studio da kem san du lieu OCR eng + vie trong assets\tessdata.
  goto done
)
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" (
  echo Tim thay Tesseract tai Program Files.
  echo Video Studio da kem san du lieu OCR eng + vie trong assets\tessdata.
  goto done
)
if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" (
  echo Tim thay Tesseract tai Program Files x86.
  echo Video Studio da kem san du lieu OCR eng + vie trong assets\tessdata.
  goto done
)
where winget >nul 2>nul
if errorlevel 1 goto manual

echo Chua tim thay Tesseract. Cong cu se cai Tesseract OCR mien phi bang winget.
echo May can Internet. Xac nhan cai dat neu Windows hoi.
echo.
winget install --id UB-Mannheim.TesseractOCR -e --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto manual

echo.
echo Da gui lenh cai dat. Hay dong va mo lai Video Studio.
echo Neu ung dung van chua nhan OCR, hay khoi dong lai Windows Terminal.
goto done

:manual
echo Khong the cai tu dong.
echo Hay cai Tesseract OCR (Windows) tu UB Mannheim hoac chay lenh:
echo winget install --id UB-Mannheim.TesseractOCR -e
echo Sau khi cai, mo lai Video Studio.

:done
echo.
pause
endlocal
