# Kiểm thử — Góc Review Phim Video Studio v1.5.0.0

Ngày build: 12/11/2026

## Đã chạy trong môi trường build

| Hạng mục | Kết quả |
|---|---|
| `py_compile` app.py, qt_app.py, engine_worker.py | PASS |
| Bộ test hiện có (Downloader, CTA detector, CTA cut/export) | PASS |
| Test mới cho xác thực/hợp nhất khoảng CTA | PASS |
| Test hợp đồng bố cục: không có mục Settings, CTA workspace, Before/After trong Mask, Batch toolbar, QC inline | PASS |
| Tạo và kiểm tra ZIP FULL/UPDATE | PASS |
| Kiểm tra SHA-256 các payload | PASS |

Tổng: 20 tests PASS (kèm 14 subtests).

## Giới hạn nghiệm thu

- Môi trường build hiện không có PySide6 và yt-dlp. Vì vậy chưa thể khởi chạy giao diện Qt thật, thực hiện tải YouTube/Facebook thật hoặc kiểm thử DPI Windows trong phiên này.
- Chưa chạy trực tiếp trên Windows với GTA đang hoạt động. Cơ chế Below Normal/giới hạn OpenCV đã được thêm vào source; cần nghiệm thu CPU/GPU thực tế trên máy người dùng.
- CTA detector vẫn là heuristic thị giác dựa trên khối màu và layout hình chữ nhật; chưa phải mô hình hiểu nội dung. Cần duyệt thumbnail để tránh false positive.
- Pipeline export hiện có được dùng lại; chưa thay đổi thuật toán encode, Smart Mask, watermark/logo hay cấu trúc project.
- Branding editor và một số tiện ích cũ vẫn còn dạng hộp thoại phụ. CTA Detector, Before/After và báo cáo QC đã chuyển vào workspace chính theo yêu cầu ở đợt này.

## Cài đặt an toàn

UPDATE tạo backup các file sẽ thay thế, kiểm tra SHA-256 và compile ba file Python trước khi báo thành công. Dữ liệu project, .venv, assets, video nguồn, renders, autosave và user_settings.json không nằm trong payload update.
