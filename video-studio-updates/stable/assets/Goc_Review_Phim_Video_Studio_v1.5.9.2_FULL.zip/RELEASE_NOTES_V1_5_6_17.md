# Góc Review Phim Video Studio v1.5.6.17

## CTA Subscribe

- Sửa mô tả và bộ lọc để phân biệt đúng CTA đọc được bằng OCR với nút / biểu tượng đồ họa.
- Giữ nguyên chế độ Quét kỹ, tìm kiếm, lọc kết quả, xem lại và cắt CTA của v1.5.6.16.

