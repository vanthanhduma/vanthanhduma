# v1.5.5.3 — OCR + Sidebar Repair and Update Trust Migration

- Nạp Tesseract với đường dẫn tessdata đi kèm ứng dụng; sửa lại hai mô hình tiếng Anh/Việt từ bộ phát hành đã kiểm tra.
- Mở rộng sidebar lên 240 px, sửa hiển thị ký tự `&` trong nhãn Qt.
- Thay khóa ký phát hành do không còn private key cũ. Khóa cũ chỉ được phép xác thực đúng manifest v1.5.5.2 hiện có; mọi bản phát hành mới phải dùng khóa mới.
- Cho phép cập nhật các mô hình OCR ứng dụng trong các bản sau; vẫn bảo vệ project, autosave, cài đặt, `.venv`, video nguồn và output người dùng.
