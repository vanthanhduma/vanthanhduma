# v1.4.5.0 — CTA Detector (Image Only) + Selected CTA Cut

## Added
- Dedicated **CTA Detector** entry in the left sidebar, separate from Watermark / Logo / Banner detection.
- Local visual scan for short-lived, high-contrast colored rectangular graphics commonly used by Subscribe, bell and Like–Share–Subscribe buttons; in the final 20% of a video, a stricter two-panel layout heuristic can also suggest end-screen cards.
- Adjustable sample interval (0.5 / 1.0 / 2.0 seconds), bounded to 1,800 frames to control CPU/RAM on long videos.
- Candidate list with start/end time, duration, heuristic score, sample count, location and a thumbnail preview with a highlighted region; start/end values for the focused candidate can be edited before cutting.
- Manual select / deselect of each suggested time interval.
- **Cắt đoạn đã chọn & xuất MP4** applies only selected CTA intervals to the existing frame-accurate exclusion/export path. Audio and video are cut together; source files remain unchanged.

## Design / safety
- CTA scan is separate from the existing Watermark / Logo / Banner detector.
- It does not analyze speech or audio.
- It does not automatically remove any candidate. The user must preview and select intervals before cutting.
- Existing excluded ranges remain in effect when exporting, and are preserved in the project schema.

## Validation
- `py_compile`: app.py, qt_app.py, engine_worker.py, cta_detector.py and new tests.
- CTA detector unit tests: 5/5 PASS, including a red Subscribe-style button, clean frame, cancellation and a two-panel end-screen layout.
- Existing downloader regression tests: 8/8 PASS.
- Tk CTA dialog Xvfb smoke test: dialog opens, synthetic scan returns one candidate, preview loads, selected row enables the cut action and edited in/out values are passed to the export exclusion list.
- Export integration: 5.0 s synthetic source with a 1.0–3.0 s exclusion produced a 3.0 s MP4; H.264 video and AAC audio streams both measured 3.0 s.

## Known constraints
- This is a heuristic visual detector, not OCR or semantic AI. It can miss monochrome/transparent/small/moving CTAs and can suggest false positives from colorful rectangular objects or multiple rectangular panels in the film. The end-screen panel heuristic only runs during the final 20%. Always inspect the thumbnail and timestamps.
- The Qt shell cannot be launched in this build container because PySide6 is unavailable. Native Windows DPI/layout and the full click-through flow must be confirmed on the user's machine.
- The detector is bounded to at most 1,800 samples; very long videos may be sampled less densely than 2 frames/second.
