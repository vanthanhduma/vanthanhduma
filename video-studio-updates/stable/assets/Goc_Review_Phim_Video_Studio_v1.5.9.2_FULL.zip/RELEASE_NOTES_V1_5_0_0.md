# Release Notes — v1.5.0.0 Unified Workspace

## Giao diện
- Loại bỏ trang Cài đặt độc lập khỏi sidebar chính.
- Giữ Auto Save bằng công tắc nhỏ trên header; giữ thông tin GPU trong thanh trạng thái.
- Sắp xếp lại sidebar theo luồng dự án → nguồn video → biên tập/làm sạch → thành phẩm.
- Đặt Batch Processing ở thanh công cụ góc trên bên phải.
- Đưa Before/After vào phần Mask.
- Đưa kết quả QC vào trang Xuất video sau khi hoàn tất.

## CTA Detector
- Trang CTA Detector chạy trong workspace Qt chính, không mở cửa sổ Tk riêng.
- Hỗ trợ quét hình ảnh/animation CTA; không phân tích tiếng nói hoặc âm thanh.
- Hiển thị khoảng thời gian, thời lượng, confidence, vị trí và thumbnail có đánh dấu vùng nghi vấn.
- Có checkbox chọn từng ứng viên và chỉnh In/Out cho dòng đang chọn.
- Lệnh cắt xác thực khoảng, hợp nhất đoạn chồng lấn, áp dụng vào excluded ranges của project và xuất MP4 mới.

## Hiệu năng
- Engine nền được đặt Below Normal trên Windows để nhường CPU cho ứng dụng foreground.
- OpenCV và các thư viện BLAS được giới hạn 2 luồng mặc định.
- Đây là biện pháp giảm tranh chấp CPU, không phải giới hạn GPU cứng; cần kiểm tra trên máy thật khi chạy GTA cùng NVENC.

## Tương thích
- Kế thừa source của v1.4.5.2; giữ nguyên schema dự án và dữ liệu người dùng.
- Gói UPDATE hỗ trợ base v1.4.5.0, v1.4.5.1 và v1.4.5.2.
