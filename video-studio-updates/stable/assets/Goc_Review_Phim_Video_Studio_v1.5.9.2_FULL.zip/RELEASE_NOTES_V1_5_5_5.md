# v1.5.5.5 — Tesseract OCR Model Loading Fix

- Xác minh Tesseract thực sự nạp và chạy được hai model `eng` + `vie` trước khi bắt đầu quét CTA; không chỉ dựa vào danh sách tên model.
- Nếu Tesseract không đọc được model trong thư mục ứng dụng, tự sao chép model đã kiểm tra SHA-256 sang `%LOCALAPPDATA%\GocReviewVideoStudio\ocr\tessdata` rồi thử lại.
- Chuẩn hóa đường dẫn `--tessdata-dir` bằng dấu `/` để tránh lỗi phân tích dấu gạch chéo ngược trên Windows.
- Phân biệt lỗi không mở được model với timeout thật; không còn báo nhầm mọi `RuntimeError` là quá thời gian.
- Khi vẫn không khởi tạo được, hiển thị cả chi tiết kỹ thuật đã thử để có thể chẩn đoán chính xác.
- Không thay đổi cơ chế quét hai lượt, Pause/Resume, gom khoảng CTA hoặc duyệt thủ công trước khi cắt.
