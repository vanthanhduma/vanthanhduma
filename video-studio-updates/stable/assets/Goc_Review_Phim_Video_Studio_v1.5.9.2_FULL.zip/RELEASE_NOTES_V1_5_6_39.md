# Góc Review Phim Video Studio v1.5.6.39

## CTA Detector — Resume Checkpoint & OCR Timeout Recovery

- Resume hiển thị tiến độ theo thời điểm thực trên toàn bộ video, không reset thanh tiến độ về 0 khi tiếp tục phần còn lại.
- Checkpoint lưu chính xác khung hình kế tiếp sau mỗi mẫu đã xử lý; khi Pause, checkpoint được ghi ngay xuống cache.
- Cache vẫn lưu tiến độ kể cả khi chưa phát hiện CTA nào, cho phép dùng **Quét tiếp** sau khi ứng dụng/engine gặp lỗi hoặc được mở lại.
- Lỗi Tesseract OCR Timeout ở một khung hình được ghi nhận và bỏ qua; detector tiếp tục những khung hình kế tiếp thay vì làm kết thúc cả phiên quét.
- Pause chỉ phát xác nhận một lần cho mỗi lần tạm dừng, tránh gửi sự kiện lặp liên tục.
- Giữ nguyên các CTA đã phát hiện trước đó khi tiếp tục quét.

## Kiểm thử

- `py_compile`: `cta_detector.py`, `engine_worker.py`, `qt_app.py`, `app.py` — PASS.
- `tests/test_cta_resume_recovery.py`: 2 test — PASS (OCR Timeout recovery; Pause/Resume không phát lại mẫu và checkpoint tăng tuần tự).
- Chưa kiểm thử GUI trực tiếp trên Windows trong môi trường build; cần xác nhận thao tác thực tế sau khi cài gói.
