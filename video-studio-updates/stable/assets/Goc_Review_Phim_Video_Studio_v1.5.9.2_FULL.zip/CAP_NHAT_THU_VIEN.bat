@echo off
setlocal EnableExtensions
chcp 65001 >nul
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "PY=%ROOT%\.venv\Scripts\python.exe"
echo.
echo ===== CAP NHAT ENGINE TAI VIDEO =====
if not exist "%PY%" (
  echo Khong tim thay .venv. Hay chay CAI_DAT_VA_CHAY.bat truoc.
  goto finish
)
echo Dang cai / cap nhat yt-dlp trong moi truong rieng cua Video Studio...
"%PY%" -m pip install --disable-pip-version-check --upgrade "yt-dlp>=2025.10.22"
if errorlevel 1 (
  echo.
  echo CAP NHAT THAT BAI. Kiem tra Internet va thu lai.
  goto finish
)
"%PY%" -c "import yt_dlp; print('yt-dlp OK:', yt_dlp.version.__version__)"
if errorlevel 1 goto finish
echo.
echo Da cap nhat engine tai video thanh cong.
:finish
echo.
pause
exit /b
