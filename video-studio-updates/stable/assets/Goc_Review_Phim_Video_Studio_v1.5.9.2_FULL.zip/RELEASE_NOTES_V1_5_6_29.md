# Gốc Review Phim Video Studio v1.5.6.29

## Chuyển tiếp cache CTA cũ

- Cache từ bản trước chưa có key thời gian sẽ lấy mốc kết thúc CTA xa nhất làm key tiếp tục tạm thời.
- Cache mới lưu key quét chuẩn theo giờ/phút/giây.
- Không phải quét lại từ đầu chỉ vì nâng cấp phiên bản.

