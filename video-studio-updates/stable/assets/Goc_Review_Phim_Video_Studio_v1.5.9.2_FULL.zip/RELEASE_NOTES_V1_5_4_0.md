# Release Notes — v1.5.4.0

## Subscribe CTA Detector — expanded on-screen recognition
- Mở rộng khỏi OCR chữ `SUBSCRIBE` đơn lẻ.
- OCR tiếng Anh và tiếng Việt, gồm cụm `Đăng ký kênh`, `Nhớ đăng ký nhé`, `Hãy đăng ký`, `Đừng quên đăng ký`, `Đăng ký ngay`, cùng dạng không dấu.
- Thêm nhận diện đồ họa nút Subscribe màu đỏ có glyph tam giác phát màu sáng bên trong. Không nhận diện một hình chữ nhật đỏ trơn hoặc chữ LIKE là Subscribe.
- Ghi nhận biến đổi trong vùng nút/khung phát hiện để hỗ trợ duyệt animation.
- Nhận diện banner/outro khi có chữ hoặc nút Subscribe; không phát hiện end-screen chung chung.
- Không phân tích âm thanh/lời nói.
- Đóng gói kèm `eng.traineddata` và `vie.traineddata` để OCR tiếng Việt hoạt động ngay khi máy đã có Tesseract engine.

## Two-pass scan
- Lượt 1 rà toàn video.
- Lượt 2 kiểm tra dày quanh những khoảng nghi vấn để tinh chỉnh thời gian và gom kết quả.
- Giữ Pause/Resume, Stop & Keep Results và cập nhật ứng viên trực tiếp trong lúc quét.
- Cắt chỉ chạy trên các khoảng đã được người dùng duyệt/chọn.

## CTA result UI
- Bảng kết quả tách cột Bằng chứng, Tin cậy và Vị trí.
- Thumbnail có phương pháp phát hiện, nội dung OCR và dấu hiệu thay đổi hình ảnh.
- Status tiến độ thể hiện rõ Lượt 1/2 và Lượt 2/2.

## Preserved
- Precise Timeline Seek (click, kéo, nhập timecode).
- Mask, Branding, Downloader, project save/open, batch, export và QC.
- Không đổi project schema.
