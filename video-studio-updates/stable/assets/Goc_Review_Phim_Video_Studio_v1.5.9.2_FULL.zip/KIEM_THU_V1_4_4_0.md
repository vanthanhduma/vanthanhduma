# KIỂM THỬ v1.4.4.0 — Downloader + Update Packaging

Ngày: 12/11/2026
Nền tảng build: Linux container (source/logic validation). Windows GUI và live platform tests cần nghiệm thu trên máy Windows của người dùng.

## PASS
- `py_compile`: `qt_app.py`, `download_engine.py`, `app.py`, `engine_worker.py`, test module.
- 8 unit tests: Facebook/YouTube URL validation; rejection of playlist/channel/unsupported domains; format-selector highest/1080p/720p and FFmpeg fallback; local browser-cookie option plumbing; progress hook; cancel-before-start.
- Downloader is a separate module and uses `yt-dlp` lazily; existing processing worker and `app.py` are unchanged.
- The downloader page is inserted as a separate `QStackedWidget` page; existing editor center/inspector remain nested in their own workspace and are not rebuilt by the downloader.
- Update payload manifest hashes and archive integrity verified after packaging (recorded in SHA256 file).
- Update script designed to require exact base version, verify every payload hash before copying, and back up replaced files before applying.
- FULL package excludes `.venv`, cache, user media, project files, autosaves, logs and generated output.
- UPDATE package contains only modified/new runtime files, updater, manifest and release notes.

## Not run / limitations
- PySide6 and yt-dlp are not installed in this build container. The container also cannot reach PyPI (DNS/network unavailable); therefore the Qt GUI was not launched here and no real Facebook/YouTube video download was executed.
- The one-click update PowerShell script was statically reviewed but not executed on Windows in this environment.
- Facebook/YouTube extractors depend on platform-side changes and may require a newer yt-dlp; not every link, privacy state, login state or stream can be downloaded.
- Actual Windows UI/DPI, browser-cookie read, FFmpeg merge and NVENC-independent downloader acceptance remain for user-machine verification.

## Preserve unchanged
- `app.py`, `engine_worker.py`, project schema, Detector, Mask, Branding, Batch, QC and export logic.
- `.venv`, assets, `user_settings.json`, source videos, projects and autosave.
