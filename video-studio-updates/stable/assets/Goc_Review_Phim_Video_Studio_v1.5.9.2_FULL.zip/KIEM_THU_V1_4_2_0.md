# Kiểm thử v1.4.2.0 – Detector Engine Foundation

## Phạm vi thực hiện
- Thêm 3 profile quét: Quick (mục tiêu 1 mẫu/30 giây, tối đa 120 mẫu), Standard (1/10 giây, tối đa 360 mẫu), Deep (1/5 giây, tối đa 720 mẫu).
- Bảo vệ RAM bằng giới hạn ảnh phân tích 480 px chiều rộng và giới hạn số mẫu. Đây là lấy mẫu thời gian, không phải quét từng frame.
- Tăng mật độ tối thiểu lên 12 mẫu với clip ngắn để cải thiện khả năng bắt banner xuất hiện ngắn.
- Cho phép giữ candidate banner có coverage thấp hơn; candidate vẫn chỉ là gợi ý để người dùng duyệt, không tự tạo Mask.
- Gắn profile và khoảng lấy mẫu ước tính vào kết quả.

## Test đã chạy trong container
| Test | Kết quả |
|---|---|
| Python compile `app.py`, `engine_worker.py`, `qt_app.py`, `gpu_check.py` | PASS |
| Synthetic clip có watermark chữ cố định | PASS – phát hiện vùng chữ |
| Synthetic clip có logo tròn cố định | PASS – phát hiện Logo |
| Synthetic clip có banner xuất hiện tạm thời | PASS – phát hiện Banner, khoảng 9.14–12.59s |
| Synthetic clip sạch không overlay | PASS – 0 candidate |
| Quick / Standard / Deep profile selection | PASS – cùng phát hiện 3 vùng trên clip thử 20s; clip ngắn dùng tối thiểu 12 mẫu nên mật độ giữa các profile gần nhau |
| Cancellation/progress callback source check | PASS theo kiểm tra đường gọi hiện hữu; chưa chạy thao tác GUI Qt |

## Giới hạn quan trọng
- Đây là nền tảng quét theo 3 mật độ lấy mẫu, chưa phải toàn bộ Detector 2.0.
- Chưa triển khai adaptive deep scan theo vùng nghi vấn, watermark tracking khi đổi vị trí, scene-change detection, scan resume/cache, Multi-Mask Manager và Auto Mask Proposal.
- Detector hiện vẫn heuristic computer vision, không phải AI/OCR semantic; cần duyệt kết quả thủ công.
- Chưa benchmark video dài nhiều giờ trên Windows/RTX 2070 Super Max-Q. Các profile có giới hạn số mẫu để bảo vệ RAM; vì vậy video rất dài sẽ có khoảng cách lấy mẫu thực tế lớn hơn mục tiêu danh nghĩa.
- Chưa chạy Qt GUI thật trên Windows trong môi trường build này.

## Nguyên tắc an toàn
Không candidate nào tự động được áp dụng thành Mask. Người dùng phải xem preview và xác nhận.
