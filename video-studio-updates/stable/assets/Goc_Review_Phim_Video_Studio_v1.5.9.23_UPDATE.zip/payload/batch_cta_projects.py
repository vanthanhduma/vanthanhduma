"""Create a per-video project and the CTA cache format consumed by the Qt review UI."""
from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from project_storage import ensure_project_workspace, video_fingerprint


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    try:
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _path_record(path: str | Path, project_dir: Path) -> dict:
    resolved = Path(path).expanduser().resolve()
    try:
        relative = os.path.relpath(resolved, project_dir)
    except (ValueError, OSError):
        # Absolute reference remains usable on Windows when the source and
        # project library are located on different drive letters.
        relative = ""
    return {"absolute": str(resolved), "relative": relative}




def find_batch_cta_cache(source_video: str | Path, project_path: str | Path) -> Path | None:
    """Find the CTA cache for this exact source video inside a project workspace.

    The normal cache name is fingerprint-based. This recovery lookup also handles
    legacy/renamed filenames, but never accepts a cache for a different video.
    """
    source = Path(source_video).expanduser().resolve()
    project = Path(project_path).expanduser().resolve()
    if not source.is_file() or not project.is_file():
        return None
    try:
        fingerprint = video_fingerprint(source).casefold()
    except OSError:
        return None

    workspace = ensure_project_workspace(project)
    roots = (workspace / "Analysis" / "CTA", project.parent / "Analysis" / "CTA")
    cache_files: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        if not root.is_dir():
            continue
        try:
            found = sorted(
                root.glob("video_*.json"),
                key=lambda item: item.stat().st_mtime,
                reverse=True,
            )
        except OSError:
            continue
        for item in found:
            try:
                key = os.path.normcase(str(item.resolve()))
            except OSError:
                continue
            if key not in seen:
                seen.add(key)
                cache_files.append(item)

    source_key = os.path.normcase(os.path.normpath(str(source)))
    for cache_file in cache_files:
        try:
            payload = json.loads(cache_file.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                continue
            saved_fingerprint = str(payload.get("video_fingerprint", "") or "").casefold()
            if saved_fingerprint:
                if saved_fingerprint == fingerprint:
                    return cache_file
                # A present but different fingerprint is a hard mismatch.
                continue
            saved_video = str(payload.get("video_path", "") or "")
            if saved_video:
                try:
                    saved_key = os.path.normcase(
                        os.path.normpath(str(Path(saved_video).expanduser().resolve()))
                    )
                except (OSError, ValueError):
                    continue
                if saved_key == source_key:
                    return cache_file
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    return None


def save_batch_cta_project(
    source_video: str | Path,
    project_path: str | Path,
    video_info: dict[str, Any],
    scan_result: dict[str, Any],
    app_version: str,
    *,
    output_dir: str | Path | None = None,
    thumbnail_bytes: dict[int, bytes] | None = None,
) -> dict[str, str | int]:
    """Atomically create a schema-v4 .grproj and its normal CTA analysis cache.

    The source video is referenced, never copied. Thumbnail bytes are evidence
    JPEGs encoded from sampled frames by the existing detector worker.
    """
    source = Path(source_video).expanduser().resolve()
    project = Path(project_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Không tìm thấy video nguồn: {source}")
    if project.suffix.lower() != ".grproj":
        raise ValueError("Dự án Batch CTA phải có đuôi .grproj.")

    project_dir = project.parent
    project_dir.mkdir(parents=True, exist_ok=True)
    workspace = ensure_project_workspace(project)
    duration = float(video_info.get("duration", scan_result.get("duration", 0.0)) or 0.0)
    fingerprint = video_fingerprint(source)
    output = Path(output_dir).expanduser().resolve() if output_dir else source.parent

    saved_at = datetime.now().astimezone().isoformat(timespec="seconds")
    project_payload = {
        "format": "goc-review-phim-video-studio-project",
        "schema_version": 4,
        "app_version": str(app_version),
        "saved_at": saved_at,
        "media": {
            "video": _path_record(source, project_dir),
            "logo": None,
            "output_dir": _path_record(output, project_dir),
            "output_dir_custom": False,
            "video_width": int(video_info.get("width", 0) or 0),
            "video_height": int(video_info.get("height", 0) or 0),
        },
        "settings": {
            "label_type": "Tập", "label_value": "1", "frame_time": 0.0,
            "preview_start": "0", "preview_length": "5",
            "segment_start": "0", "segment_end": str(duration),
            "mask_expansion": 14, "auto_mask_expansion": True,
            "mask_manual_override": False, "show_mask": True,
            "preview_720": True, "prefer_gpu": True, "auto_open_output": False,
            "autosave_enabled": True, "segment_from_minutes": "0",
            "segment_to_minutes": str(duration / 60.0), "branding": {},
        },
        "selection": {
            "lasso_points": [], "mask_png_base64": "",
            "mask_width": 0, "mask_height": 0, "show_mask": True,
        },
        "excluded_ranges": [],
        "scenes": [],
        "batch_cta": {
            "source_video": str(source),
            "created_at": saved_at,
        },
    }
    _atomic_json(project, project_payload)

    cache_root = workspace / "Analysis" / "CTA"
    cache_root.mkdir(parents=True, exist_ok=True)
    cache_file = cache_root / f"video_{fingerprint[:24]}.json"
    thumbnail_root = cache_root / "thumbnails" / cache_file.stem
    thumbnail_root.mkdir(parents=True, exist_ok=True)

    allowed = {
        "scan_id", "start", "end", "duration", "sample_time", "confidence",
        "peak_confidence", "samples", "kind", "method", "text", "label",
        "terms", "evidence", "animated", "x", "y", "w", "h", "location",
    }
    candidates = []
    evidence = thumbnail_bytes or {}
    for index, raw in enumerate(scan_result.get("candidates", []) or []):
        item = {key: raw[key] for key in allowed if key in raw}
        for key in ("terms", "evidence"):
            if key in item:
                item[key] = [str(value) for value in (item[key] or [])]
        sample_time = float(item.get("sample_time", item.get("start", 0.0)) or 0.0)
        image_bytes = evidence.get(index)
        if image_bytes:
            thumb_name = f"cta_batch_{index:05d}_{int(round(sample_time * 1000)):012d}.jpg"
            thumb_path = thumbnail_root / thumb_name
            temporary = thumb_path.with_name(thumb_path.name + ".tmp")
            try:
                temporary.write_bytes(image_bytes)
                os.replace(temporary, thumb_path)
                item["thumbnail"] = str(thumb_path.relative_to(cache_root).as_posix())
            finally:
                temporary.unlink(missing_ok=True)
        candidates.append(item)

    cache_payload = {
        "schema_version": 4,
        "video_path": str(source),
        "video_fingerprint": fingerprint,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "complete": True,
        "samples": int(scan_result.get("samples", 0) or 0),
        "pass1_samples": int(scan_result.get("pass1_samples", 0) or 0),
        "pass2_samples": int(scan_result.get("pass2_samples", 0) or 0),
        "sample_interval": float(scan_result.get("sample_interval", 2.0) or 2.0),
        "pass1_interval": float(scan_result.get("pass1_interval", 2.0) or 2.0),
        "pass2_interval": float(scan_result.get("pass2_interval", 0.0) or 0.0),
        "sample_cap_reached": bool(scan_result.get("sample_cap_reached", False)),
        "pass2_sample_cap_reached": bool(scan_result.get("pass2_sample_cap_reached", False)),
        "resume_time": duration,
        "resume_phase": "done",
        "candidates": candidates,
        "note": str(scan_result.get("note", "")),
    }
    _atomic_json(cache_file, cache_payload)
    return {
        "project_path": str(project),
        "cache_path": str(cache_file),
        "candidate_count": len(candidates),
    }
