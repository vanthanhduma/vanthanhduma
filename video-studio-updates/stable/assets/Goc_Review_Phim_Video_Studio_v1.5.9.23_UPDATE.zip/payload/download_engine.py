from __future__ import annotations

"""Local Facebook/YouTube downloader adapter built on yt-dlp.

The module deliberately supports only well-known Facebook and YouTube URL
families in the UI. It does not unlock private/member-only content or bypass
site access controls. Cookies, when selected, are read from the chosen local
browser profile and are never uploaded by this application.
"""

import sys

# Python 3.15 adds PEP 810 lazy imports. Resolve all imports eagerly before
# loading Qt or third-party libraries; PySide6's import hook can otherwise
# leave lazy proxies uncallable in concurrent worker paths.
if hasattr(sys, "set_lazy_imports"):
    # CPython 3.15 accepts "normal" or "all"; normal keeps regular imports eager.
    sys.set_lazy_imports("normal")
    # Also force explicitly marked lazy imports to resolve immediately.
    if hasattr(sys, "set_lazy_imports_filter"):
        sys.set_lazy_imports_filter(lambda _importing, _imported, _fromlist: False)

import json
import os
import shutil
import subprocess
import threading
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from typing import Callable


class DownloadCancelled(Exception):
    """Raised when the user stops the current download."""


_ALLOWED_HOSTS = {
    "facebook.com", "www.facebook.com", "m.facebook.com", "fb.watch",
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com",
}


def validate_video_url(url: str) -> str:
    value = (url or "").strip()
    if not value:
        raise ValueError("Bạn chưa dán liên kết video.")
    if len(value) > 4096:
        raise ValueError("Liên kết quá dài.")
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Link phải bắt đầu bằng http:// hoặc https://.")
    host = parsed.hostname.lower().rstrip(".")
    if host not in _ALLOWED_HOSTS:
        raise ValueError("Hiện chỉ hỗ trợ link Facebook và YouTube.")
    if host in {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com"}:
        is_watch = parsed.path.rstrip("/") == "/watch" and bool(parse_qs(parsed.query).get("v"))
        is_id_path = parsed.path.startswith(("/shorts/", "/live/", "/embed/")) and len(parsed.path.strip("/").split("/")) >= 2
        if not (is_watch or is_id_path):
            raise ValueError("Hãy dùng link video YouTube cụ thể (watch, Shorts hoặc Live), không dùng link kênh/danh sách phát.")
    elif host == "youtu.be":
        path_parts = [part for part in parsed.path.strip("/").split("/") if part]
        if len(path_parts) != 1:
            raise ValueError("Link youtu.be chưa hợp lệ.")
    if host in {"facebook.com", "www.facebook.com", "m.facebook.com"}:
        if not any(x in parsed.path for x in ("/reel/", "/watch", "/videos/", "/share/")):
            raise ValueError("Link Facebook chưa giống một liên kết video/Reels hợp lệ.")
    if host == "fb.watch" and not parsed.path.strip("/"):
        raise ValueError("Link fb.watch chưa có mã video.")
    return value


def detect_platform(url: str) -> str:
    host = (urlparse(url).hostname or "").lower()
    return "YouTube" if (host == "youtu.be" or host.endswith("youtube.com") or host.endswith("youtube-nocookie.com")) else "Facebook"


def _format_selector(max_height: int | None, prefer_mp4: bool, has_ffmpeg: bool) -> str:
    limit = f"[height<={max_height}]" if max_height else ""
    if prefer_mp4 and not has_ffmpeg:
        return f"best[ext=mp4]{limit}/best{limit}"
    if prefer_mp4:
        # Select a video-bearing stream explicitly, then pair it with audio.
        # Fall back to a combined MP4, then the highest compatible video+audio.
        return (
            f"bestvideo[ext=mp4]{limit}+bestaudio[ext=m4a]/"
            f"best[ext=mp4]{limit}/bestvideo{limit}+bestaudio/best{limit}"
        )
    if not has_ffmpeg:
        return f"best{limit}"
    if max_height:
        return f"bestvideo{limit}+bestaudio/best{limit}"
    return "bestvideo+bestaudio/best"


def _resolve_ffmpeg() -> str | None:
    # Respect the FFmpeg path already selected in Video Studio settings.
    settings_path = Path(__file__).resolve().parent / "user_settings.json"
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        configured = str(settings.get("ffmpeg_path", "")).strip() if isinstance(settings, dict) else ""
        if configured and Path(configured).is_file():
            return configured
    except Exception:
        pass
    system_path = shutil.which("ffmpeg")
    if system_path:
        return system_path
    try:
        import imageio_ffmpeg
        bundled = imageio_ffmpeg.get_ffmpeg_exe()
        return bundled if bundled and Path(bundled).is_file() else None
    except Exception:
        return None


def _resolve_ffprobe(ffmpeg: str | None = None) -> str | None:
    """Find ffprobe beside the selected FFmpeg binary or on PATH."""
    if ffmpeg:
        try:
            ffmpeg_path = Path(ffmpeg)
            probe_name = "ffprobe.exe" if os.name == "nt" else "ffprobe"
            sibling = ffmpeg_path.with_name(probe_name)
            if sibling.is_file():
                return str(sibling)
        except Exception:
            pass
    return shutil.which("ffprobe")


def _find_downloaded_file(info: dict, ydl, destination: Path) -> Path | None:
    """Resolve yt-dlp's final post-processed path without mistaking .part files for output."""
    candidates: list[Path] = []
    for key in ("filepath", "_filename"):
        value = info.get(key)
        if value:
            candidates.append(Path(str(value)))
    for entry in info.get("requested_downloads") or []:
        if isinstance(entry, dict):
            for key in ("filepath", "_filename"):
                value = entry.get(key)
                if value:
                    candidates.append(Path(str(value)))
    try:
        prepared = ydl.prepare_filename(info)
        if prepared:
            candidates.append(Path(str(prepared)))
    except Exception:
        pass

    seen = set()
    for candidate in candidates:
        try:
            resolved = candidate.expanduser().resolve()
            key = os.path.normcase(str(resolved))
            if key in seen:
                continue
            seen.add(key)
            if resolved.is_file() and not resolved.name.casefold().endswith((".part", ".ytdl")):
                return resolved
        except OSError:
            continue

    video_id = str(info.get("id") or "").strip()
    if video_id:
        try:
            matches = [
                path for path in destination.iterdir()
                if path.is_file()
                and f"[{video_id}]" in path.name
                and not path.name.casefold().endswith((".part", ".ytdl"))
            ]
            if matches:
                return max(matches, key=lambda path: path.stat().st_mtime)
        except OSError:
            pass
    return None


def _verify_download_has_video(path: Path, ffprobe: str) -> dict:
    """Reject an audio-only file instead of reporting a false successful video download."""
    kwargs = {"capture_output": True, "text": True, "check": False, "timeout": 45}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    result = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-show_entries", "stream=codec_type,codec_name,width,height",
            "-of", "json", str(path),
        ],
        **kwargs,
    )
    if result.returncode != 0:
        detail = (result.stderr or "").strip()[-800:]
        raise RuntimeError(
            "Không kiểm tra được file video sau khi tải"
            + (f": {detail}" if detail else ".")
        )
    try:
        streams = json.loads(result.stdout or "{}").get("streams") or []
    except json.JSONDecodeError as exc:
        raise RuntimeError("FFprobe trả về dữ liệu không hợp lệ cho file vừa tải.") from exc
    video = next((item for item in streams if item.get("codec_type") == "video"), None)
    if not video:
        raise RuntimeError(
            f"File '{path.name}' chỉ có âm thanh, không có luồng hình. "
            "Ứng dụng chưa đánh dấu mục này hoàn tất để tránh giữ nhầm file lỗi."
        )
    return video


def download_video(
    url: str,
    output_dir: str | Path,
    *,
    browser: str | None = None,
    max_height: int | None = None,
    prefer_mp4: bool = False,
    cancel_event: threading.Event | None = None,
    progress_callback: Callable[[dict], None] | None = None,
) -> dict:
    """Download one authorized/publicly accessible video and return its metadata."""
    url = validate_video_url(url)
    if max_height not in {None, 720, 1080}:
        raise ValueError("Mức phân giải không được hỗ trợ.")
    if browser not in {None, "chrome", "edge", "firefox"}:
        raise ValueError("Trình duyệt cookie không được hỗ trợ.")

    try:
        import yt_dlp
    except ImportError as exc:
        raise RuntimeError("Thiếu yt-dlp. Hãy chạy CAP_NHAT_THU_VIEN.bat để cài engine tải.") from exc

    destination = Path(output_dir).expanduser().resolve()
    destination.mkdir(parents=True, exist_ok=True)
    ffmpeg = _resolve_ffmpeg()
    has_ffmpeg = bool(ffmpeg)

    options: dict = {
        "format": _format_selector(max_height, prefer_mp4, has_ffmpeg),
        "outtmpl": str(destination / "%(title).160B [%(id)s].%(ext)s"),
        "noplaylist": True,
        "windowsfilenames": True,
        "continuedl": True,
        "nopart": False,
        "overwrites": False,
        "retries": 5,
        "fragment_retries": 8,
        "file_access_retries": 3,
        "concurrent_fragment_downloads": 8,
        "http_chunk_size": 10 * 1024 * 1024,
        "check_formats": True,
        "socket_timeout": 30,
        "quiet": True,
        "no_warnings": True,
        "progress_hooks": [],
    }
    if browser:
        options["cookiesfrombrowser"] = (browser, None, None, None)
    if ffmpeg:
        options["ffmpeg_location"] = str(ffmpeg)
        # Keep source streams intact; MP4-first/MKV-first only changes the
        # container through stream copy and does not re-encode the video.
        options["merge_output_format"] = "mp4/mkv" if prefer_mp4 else "mkv/mp4"

    def hook(data: dict):
        if cancel_event is not None and cancel_event.is_set():
            raise DownloadCancelled("Người dùng đã yêu cầu dừng tải.")
        status = str(data.get("status", "downloading"))
        if progress_callback:
            if status == "downloading":
                total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
                downloaded = data.get("downloaded_bytes") or 0
                percent = int(downloaded * 100 / total) if total else 0
                progress_callback({"status": status, "percent": percent, "speed": data.get("speed"), "eta": data.get("eta")})
            elif status == "finished":
                progress_callback({"status": status, "percent": 100, "speed": 0, "eta": 0})

    options["progress_hooks"] = [hook]
    if cancel_event is not None and cancel_event.is_set():
        raise DownloadCancelled("Người dùng đã yêu cầu dừng tải.")

    with yt_dlp.YoutubeDL(options) as ydl:
        info = ydl.extract_info(url, download=True)
        output_path = _find_downloaded_file(info, ydl, destination) if isinstance(info, dict) else None
    if cancel_event is not None and cancel_event.is_set():
        raise DownloadCancelled("Người dùng đã yêu cầu dừng tải.")
    if not isinstance(info, dict):
        raise RuntimeError("Nguồn không trả về thông tin video hợp lệ.")
    ffprobe = _resolve_ffprobe(ffmpeg)
    video_stream = _verify_download_has_video(output_path, ffprobe) if output_path and ffprobe else None
    return {
        "id": str(info.get("id") or ""),
        "title": str(info.get("title") or "Video"),
        "duration": info.get("duration"),
        "height": info.get("height"),
        "ext": str(info.get("ext") or ""),
        "platform": detect_platform(url),
        "output_dir": str(destination),
        "filepath": str(output_path) if output_path else "",
        "video_codec": str(video_stream.get("codec_name") or "") if video_stream else "",
    }


def run_download_queue(
    jobs: list[dict],
    output_dir: str | Path,
    *,
    browser: str | None = None,
    max_height: int | None = None,
    prefer_mp4: bool = False,
    cancel_event: threading.Event | None = None,
    max_concurrent: int = 2,
    on_job_started: Callable[[int, str], None] | None = None,
    on_progress: Callable[[int, dict], None] | None = None,
    on_job_finished: Callable[[int, bool, str], None] | None = None,
) -> int:
    """Run a download queue with bounded parallelism and cooperative cancellation.

    Jobs not yet started when cancellation is requested remain queued so they
    can be resumed by the UI.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    if not jobs:
        return 0
    workers = min(2, max(1, int(max_concurrent)), len(jobs))
    stop_event = cancel_event or threading.Event()

    def run_one(job: dict):
        job_id = int(job["id"])
        url = str(job["url"])
        if stop_event.is_set():
            return None
        try:
            if on_job_started:
                on_job_started(job_id, url)
            result = download_video(
                url,
                str(job.get("output_dir") or output_dir),
                browser=job.get("browser", browser),
                max_height=job.get("max_height", max_height),
                prefer_mp4=bool(job.get("prefer_mp4", prefer_mp4)),
                cancel_event=stop_event,
                progress_callback=(
                    (lambda data, jid=job_id: on_progress(jid, data))
                    if on_progress else None
                ),
            )
            return job_id, True, str(result.get("title") or "Đã tải xong")
        except DownloadCancelled:
            return job_id, False, "Đã dừng theo yêu cầu"
        except Exception as exc:
            if stop_event.is_set():
                return job_id, False, "Đã dừng theo yêu cầu"
            return job_id, False, str(exc)[:2000]

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="GocReviewDownload") as executor:
        futures = [executor.submit(run_one, job) for job in jobs]
        for future in as_completed(futures):
            outcome = future.result()
            if outcome is not None and on_job_finished:
                on_job_finished(*outcome)
    return workers
