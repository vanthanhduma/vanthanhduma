from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
GUARD = """if hasattr(sys, "set_lazy_imports"):
    # CPython 3.15 accepts "normal" or "all"; normal keeps regular imports eager.
    sys.set_lazy_imports("normal")
    # Also force explicitly marked lazy imports to resolve immediately.
    if hasattr(sys, "set_lazy_imports_filter"):
        sys.set_lazy_imports_filter(lambda _importing, _imported, _fromlist: False)"""


class FakePython315Sys:
    """Model the public CPython 3.15 API contract for Python 3.11 CI runners."""

    def __init__(self):
        self.mode = None
        self.filter = None

    def set_lazy_imports(self, mode):
        if mode not in {"normal", "all"}:
            raise ValueError("mode must be 'normal' or 'all'")
        self.mode = mode

    def set_lazy_imports_filter(self, callback):
        if callback is not None and not callable(callback):
            raise TypeError("filter must be callable or None")
        self.filter = callback


class Python315LazyImportCompatibilityTests(unittest.TestCase):
    def test_qt_disables_global_lazy_imports_before_pyside6(self):
        source = (ROOT / "qt_app.py").read_text(encoding="utf-8")
        self.assertIn(GUARD, source)
        self.assertLess(source.index(GUARD), source.index("from PySide6.QtCore"))

    def test_all_entrypoints_use_supported_eager_import_guard(self):
        boundaries = {
            "qt_app.py": "from PySide6.QtCore",
            "app.py": "import cv2",
            "engine_worker.py": "import cv2",
            "download_engine.py": "import json",
        }
        for name, boundary in boundaries.items():
            with self.subTest(name=name):
                source = (ROOT / name).read_text(encoding="utf-8")
                self.assertIn(GUARD, source)
                self.assertNotIn('sys.set_lazy_imports("none")', source)
                self.assertLess(source.index(GUARD), source.index(boundary))

                fake_sys = FakePython315Sys()
                exec(GUARD, {"sys": fake_sys})
                self.assertEqual(fake_sys.mode, "normal")
                self.assertIsNotNone(fake_sys.filter)
                self.assertFalse(fake_sys.filter(None, "example", None))

    def test_runtime_python315_api_accepts_normal_and_eager_filter(self):
        required = ("set_lazy_imports", "get_lazy_imports",
                    "set_lazy_imports_filter", "get_lazy_imports_filter")
        if not all(hasattr(sys, name) for name in required):
            self.skipTest("Complete lazy-import API is available in Python 3.15+")

        previous_mode = sys.get_lazy_imports()
        previous_filter = sys.get_lazy_imports_filter()
        try:
            sys.set_lazy_imports("normal")
            eager_filter = lambda _importing, _imported, _fromlist: False
            sys.set_lazy_imports_filter(eager_filter)
            self.assertEqual(sys.get_lazy_imports(), "normal")
            self.assertIs(sys.get_lazy_imports_filter(), eager_filter)
            self.assertFalse(sys.get_lazy_imports_filter()(None, "example", None))
        finally:
            sys.set_lazy_imports_filter(previous_filter)
            sys.set_lazy_imports(previous_mode)


if __name__ == "__main__":
    unittest.main()
