from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import cv2
import numpy as np

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QPointF, Qt
from PySide6.QtWidgets import QApplication

import engine_worker
from qt_app import BrandingPreviewCanvas


class _Value:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value


class BrandingPreviewPerformanceTests(unittest.TestCase):
    def test_4k_preview_builds_overlay_only_at_ui_resolution_once(self):
        source = np.zeros((2160, 3840, 3), dtype=np.uint8)
        fake_app = SimpleNamespace(
            frame=source,
            info={"duration": 600.0},
            frame_time_var=_Value("30"),
            logo_path="",
            _branding_text=lambda: "Tập 1",
        )
        observed = {}

        def build_components(width, height, logo_path, label_text, config):
            observed["component_size"] = (width, height)
            logo = np.zeros((height, width, 4), dtype=np.uint8)
            label = np.zeros_like(logo)
            logo[10:30, 20:40, 3] = 255
            return logo, label

        def apply_overlay(frame, mask, expansion, overlay):
            observed["apply_size"] = (frame.shape[1], frame.shape[0])
            observed["overlay_size"] = (overlay.shape[1], overlay.shape[0])
            observed["base_overlay_alpha_max"] = int(overlay[:, :, 3].max())
            self.assertIsNone(mask)
            self.assertEqual(expansion, 0)
            return frame

        with tempfile.TemporaryDirectory(prefix="gocreview-branding-preview-") as temp:
            with (
                mock.patch.object(engine_worker, "app_instance", fake_app),
                mock.patch.object(engine_worker, "STATE_DIR", Path(temp)),
                mock.patch.object(
                    engine_worker.core, "build_branding_components",
                    side_effect=build_components,
                ) as components,
                mock.patch.object(
                    engine_worker.core, "build_overlay",
                    side_effect=AssertionError("Preview must not build the full-size overlay twice."),
                ),
                mock.patch.object(
                    engine_worker.core, "apply_mask_and_overlay",
                    side_effect=apply_overlay,
                ),
            ):
                result = engine_worker._branding_preview({
                    "config": {"show_from": 0.0, "show_to": 600.0},
                    "logo_path": "",
                    "label_text": "Tập 1",
                    "preview_token": 17,
                })

            self.assertEqual(components.call_count, 1)
            self.assertEqual(observed["component_size"], (1280, 720))
            self.assertEqual(observed["apply_size"], (1280, 720))
            self.assertEqual(observed["overlay_size"], (1280, 720))
            self.assertEqual(observed["base_overlay_alpha_max"], 0)
            self.assertEqual(result["frame_width"], 3840)
            self.assertEqual(result["frame_height"], 2160)
            self.assertEqual(result["preview_width"], 1280)
            self.assertEqual(result["preview_height"], 720)
            self.assertEqual(result["logo_rect"], [60, 30, 120, 90])
            preview_path = Path(result["preview_path"])
            logo_path = Path(result["logo_overlay_path"])
            self.assertTrue(preview_path.is_file())
            self.assertTrue(logo_path.is_file())
            preview = cv2.imread(str(preview_path))
            logo = cv2.imread(str(logo_path), cv2.IMREAD_UNCHANGED)
            self.assertIsNotNone(preview)
            self.assertIsNotNone(logo)
            self.assertEqual(preview.shape[:2], (720, 1280))
            self.assertEqual(logo.shape, (20, 20, 4))
            self.assertEqual(int(logo[:, :, 3].max()), 255)


class BrandingLabelBackgroundTests(unittest.TestCase):
    def test_background_expands_to_cover_long_vietnamese_label_text(self):
        image = engine_worker.core._draw_branding_label(
            640, 360, "Tập 18 · Ngoại truyện đặc biệt", {"label_scale": 100},
        )
        pixels = np.asarray(image)
        red = (
            (pixels[:, :, 0] > 100)
            & (pixels[:, :, 1] < 90)
            & (pixels[:, :, 2] < 90)
            & (pixels[:, :, 3] > 200)
        )
        white = (
            (pixels[:, :, 0] > 210)
            & (pixels[:, :, 1] > 210)
            & (pixels[:, :, 2] > 210)
            & (pixels[:, :, 3] > 200)
        )
        self.assertTrue(red.any(), "The label background was not rendered.")
        self.assertTrue(white.any(), "The label text was not rendered.")
        by, bx = np.where(red)
        ty, tx = np.where(white)
        self.assertLess(int(bx.min()), int(tx.min()))
        self.assertGreater(int(bx.max()), int(tx.max()))
        self.assertLess(int(by.min()), int(ty.min()))
        self.assertGreater(int(by.max()), int(ty.max()))


class _MouseEvent:
    def __init__(self, x, y, button=Qt.MouseButton.LeftButton):
        self._position = QPointF(float(x), float(y))
        self._button = button

    def position(self):
        return self._position

    def button(self):
        return self._button

    def accept(self):
        pass

    def ignore(self):
        pass


class BrandingCanvasDragTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt_app = QApplication.instance() or QApplication([])

    def test_logo_tracks_pointer_locally_and_emits_only_on_release(self):
        with tempfile.TemporaryDirectory(prefix="gocreview-branding-drag-") as temp:
            root = Path(temp)
            base_path = root / "base.jpg"
            logo_path = root / "logo.png"
            self.assertTrue(cv2.imwrite(str(base_path), np.zeros((360, 640, 3), dtype=np.uint8)))
            logo = np.zeros((40, 50, 4), dtype=np.uint8)
            logo[:, :, 3] = 255
            self.assertTrue(cv2.imwrite(str(logo_path), logo))

            canvas = BrandingPreviewCanvas()
            canvas.resize(640, 360)
            canvas.set_preview(
                str(base_path), 640, 360, [100, 100, 150, 140], str(logo_path)
            )
            canvas.image_rect = canvas._fit_rect()
            moved = []
            canvas.logoMoved.connect(lambda x, y: moved.append((x, y)))

            canvas.mousePressEvent(_MouseEvent(125, 120))
            self.assertTrue(canvas._dragging_logo)
            canvas.mouseMoveEvent(_MouseEvent(325, 220))

            self.assertEqual(canvas.logo_rect, (300, 200, 350, 240))
            self.assertEqual(moved, [])
            canvas.mouseReleaseEvent(_MouseEvent(325, 220))

            self.assertFalse(canvas._dragging_logo)
            self.assertEqual(len(moved), 1)
            self.assertAlmostEqual(moved[0][0], 325 / 640)
            self.assertAlmostEqual(moved[0][1], 220 / 360)


if __name__ == "__main__":
    unittest.main()
