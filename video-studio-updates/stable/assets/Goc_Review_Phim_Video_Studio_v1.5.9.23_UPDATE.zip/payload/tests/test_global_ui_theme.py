from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class GlobalUiThemeRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt = (ROOT / "qt_app.py").read_text(encoding="utf-8")

    def test_content_controls_do_not_paint_dark_rectangles(self):
        self.assertIn(
            "QLabel, QCheckBox, QRadioButton, QSlider, QGroupBox, QTabWidget, QStackedWidget, QFrame {{\n"
            "  background: transparent;",
            self.qt,
        )
        self.assertIn("QCheckBox, QRadioButton {{\n  background: transparent;", self.qt)
        self.assertIn("QGroupBox {{ background: transparent;", self.qt)

    def test_app_uses_one_readable_vietnamese_safe_base_font(self):
        self.assertIn("font-size: 10.5pt;", self.qt)
        self.assertIn("ui_font.setPointSizeF(10.5)", self.qt)
        self.assertIn("ui_font.setWeight(QFont.Weight.Medium)", self.qt)
        self.assertIn('("Segoe UI", "Arial", "Tahoma", "Noto Sans", "DejaVu Sans")', self.qt)

    def test_common_ui_levels_are_consistent(self):
        self.assertIn("QLabel#SectionTitle", self.qt)
        self.assertIn("font-size: 10.5pt;", self.qt)
        self.assertIn("QLabel#ProjectTitle", self.qt)
        self.assertIn("font-size: 12.5pt;", self.qt)
        self.assertIn("QPushButton, QToolButton", self.qt)
        self.assertIn("font-size: 10pt;", self.qt)
        self.assertIn("QTabBar::tab", self.qt)
        self.assertIn("QHeaderView::section", self.qt)

    def test_download_cta_mask_branding_and_batch_controls_use_shared_surface(self):
        self.assertIn("QCheckBox::indicator", self.qt)
        self.assertIn("QTableWidget#CtaTable", self.qt)
        self.assertIn("QLabel#CtaCaption", self.qt)
        self.assertIn("QLabel#BatchKicker", self.qt)
        self.assertIn("QFrame#ProjectCard", self.qt)

    def test_project_identity_has_more_room_and_keeps_full_text_tooltip(self):
        self.assertIn("self.project_title.setMaximumWidth(260)", self.qt)
        self.assertIn("self.video_title.setMaximumWidth(240)", self.qt)
        self.assertIn('self.project_title.setToolTip("Tên dự án đang mở")', self.qt)
        self.assertIn('self.video_title.setToolTip(s.get("video_path", ""))', self.qt)


if __name__ == "__main__":
    unittest.main()
