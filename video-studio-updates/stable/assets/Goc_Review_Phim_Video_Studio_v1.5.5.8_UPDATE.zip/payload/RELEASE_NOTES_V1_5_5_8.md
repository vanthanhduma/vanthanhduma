# v1.5.5.8

- Làm thumbnail CTA lớn hơn và tự co giãn theo kích thước panel, giữ đúng tỉ lệ khi xem lại.
- Hiển thị trực tiếp chữ OCR nhận diện được trong bảng kết quả, kèm phương pháp và tooltip.
- Tăng tương phản/cỡ chữ phần mô tả preview và cho phép chọn/copy nội dung để đọc rõ trước khi cắt.
- Giữ nguyên updater một lần bấm, rollback và bảo toàn project/settings/venv.
