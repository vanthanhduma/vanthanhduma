# Tesseract language data notice

The `assets/tessdata/eng.traineddata` and `assets/tessdata/vie.traineddata` files are language data from the Tesseract OCR `tessdata_fast` distribution. The upstream project states that the data files are licensed under Apache License 2.0. The license text is included next to the files as `LICENSE-Apache-2.0.txt`.

Upstream source: https://github.com/tesseract-ocr/tessdata_fast

The application supplies these files to enable local English/Vietnamese on-screen text recognition. The Tesseract executable itself is not bundled; install it separately on Windows if it is not present.
