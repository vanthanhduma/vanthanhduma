@echo off
start "" "https://www.gyan.dev/ffmpeg/builds/"
