"""Pure timecode helpers for precise video timeline navigation."""
from __future__ import annotations

import math
import re


def parse_timecode(value: str) -> float:
    """Parse seconds, MM:SS[.mmm], or HH:MM:SS[.mmm] to seconds."""
    text = str(value or "").strip().replace(",", ".")
    if not text:
        raise ValueError("Hãy nhập thời gian cần đến.")
    if ":" not in text:
        try:
            seconds = float(text)
        except ValueError as exc:
            raise ValueError("Thời gian phải là giây hoặc dạng HH:MM:SS.mmm.") from exc
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError("Thời gian phải là số không âm.")
        return seconds

    parts = text.split(":")
    if len(parts) not in (2, 3):
        raise ValueError("Dùng dạng MM:SS hoặc HH:MM:SS.mmm.")
    try:
        if len(parts) == 2:
            minutes = int(parts[0])
            seconds = float(parts[1])
            hours = 0
        else:
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = float(parts[2])
    except ValueError as exc:
        raise ValueError("Timecode không hợp lệ. Ví dụ: 00:12:34.500.") from exc
    if hours < 0 or minutes < 0 or seconds < 0 or seconds >= 60:
        raise ValueError("Giây phải nhỏ hơn 60 và thời gian không được âm.")
    if len(parts) == 3 and minutes >= 60:
        raise ValueError("Phút trong dạng HH:MM:SS phải nhỏ hơn 60.")
    return hours * 3600.0 + minutes * 60.0 + seconds


def format_timecode(seconds: float, milliseconds: bool = True) -> str:
    total_ms = max(0, int(round(float(seconds or 0) * 1000)))
    whole_seconds, ms = divmod(total_ms, 1000)
    hours, remainder = divmod(whole_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if milliseconds:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}.{ms:03d}"
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"
