from __future__ import annotations

import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path


def _log_path() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local"))
    folder = base / "GocReviewVideoStudio" / "logs"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "launcher.log"


def _gui_python(root: Path) -> Path:
    """Prefer pythonw.exe so even a stale/legacy shortcut cannot flash a console."""
    scripts = root / ".venv" / "Scripts"
    pythonw = scripts / "pythonw.exe"
    python = scripts / "python.exe"
    return pythonw if pythonw.is_file() else python


def _creation_flags() -> int:
    if os.name != "nt":
        return 0
    # CREATE_NO_WINDOW is sufficient; DETACHED_PROCESS can interfere with
    # inherited log handles and is unnecessary for pythonw.exe.
    return getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000) | getattr(
        subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200
    )


def main() -> int:
    root = Path(__file__).resolve().parent
    python = _gui_python(root)
    script = root / "qt_app.py"
    log_path = _log_path()

    with log_path.open("a", encoding="utf-8") as log:
        log.write(f"\n[{datetime.now().isoformat()}] Launcher start. root={root}\n")
        if not script.is_file():
            log.write("ERROR: qt_app.py missing.\n")
            return 2
        if not python.is_file():
            log.write(f"ERROR: Python runtime missing: {python}\n")
            return 3

        try:
            child_log = log_path.open("ab", buffering=0)
            proc = subprocess.Popen(
                [str(python), "-u", str(script)],
                cwd=str(root),
                stdin=subprocess.DEVNULL,
                stdout=child_log,
                stderr=subprocess.STDOUT,
                close_fds=(os.name == "nt"),
                creationflags=_creation_flags(),
            )
            # Parent launcher exits shortly after confirming that Qt stayed alive.
            child_log.close()
            log.write(f"GUI process started pid={proc.pid} executable={python}\n")
        except Exception as exc:
            log.write(f"ERROR: failed to spawn GUI: {type(exc).__name__}: {exc}\n")
            return 4

        for _ in range(10):
            time.sleep(0.5)
            code = proc.poll()
            if code is not None:
                log.write(f"ERROR: GUI exited during startup with code={code}.\n")
                return 5 if code else 0
        log.write("GUI remained alive through startup probe.\n")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
