Option Explicit
Dim fso, shell, root, desktop, launcher, shortcutPath, link, iconPath, wscriptPath

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

root = fso.GetParentFolderName(WScript.ScriptFullName)
launcher = root & "\MO_GOC_REVIEW_PHIM.vbs"
iconPath = root & "\assets\app_icon.ico"
wscriptPath = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\wscript.exe")

If Not fso.FileExists(launcher) Then
    MsgBox "Cannot find MO_GOC_REVIEW_PHIM.vbs in this folder:" & vbCrLf & root, vbCritical, "Goc Review Phim"
    WScript.Quit 1
End If
If Not fso.FileExists(wscriptPath) Then
    MsgBox "Windows Script Host was not found:" & vbCrLf & wscriptPath, vbCritical, "Goc Review Phim"
    WScript.Quit 2
End If

desktop = shell.SpecialFolders("Desktop")
shortcutPath = desktop & "\Goc Review Phim.lnk"
Set link = shell.CreateShortcut(shortcutPath)
link.TargetPath = wscriptPath
link.Arguments = "//B //NoLogo " & Chr(34) & launcher & Chr(34)
link.WorkingDirectory = root
link.WindowStyle = 1
link.Description = "Goc Review Phim Video Studio v1.5.5.6"
If fso.FileExists(iconPath) Then
    link.IconLocation = iconPath & ",0"
End If
link.Save

' Shortcut creation is intentionally silent so the installer can refresh it automatically.
