# Tesseract OCR — v1.5.5.5

Video Studio ships local `eng.traineddata` and `vie.traineddata` models in `assets/tessdata`.
The app first validates that Tesseract can actually initialize both models, not merely list their names.

If the Tesseract executable cannot read the models from the application directory (for example because of folder permissions, external-drive policies, or file-access interference), Video Studio copies the bundled files to the per-user cache:

`%LOCALAPPDATA%\GocReviewVideoStudio\ocr\tessdata`

The copied files are checked against the bundled SHA-256 values before use. The app then retries OCR initialization using that local path. No model download is needed, and the cache remains separate from project files and user settings.

If initialization still fails, the CTA Detector displays the exact Tesseract executable, candidate model paths, and native error. A genuine OCR timeout is reported separately from a traineddata loading error.
