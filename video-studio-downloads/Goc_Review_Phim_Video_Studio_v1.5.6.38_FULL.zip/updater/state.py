from __future__ import annotations

import json
import os
import time
from pathlib import Path


def state_path() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local"))
    folder = base / "GocReviewVideoStudio" / "updater"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "state.json"


def load_state() -> dict:
    try:
        value = json.loads(state_path().read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def save_state(**updates) -> None:
    current = load_state()
    current.update(updates)
    path = state_path()
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, path)


def should_auto_check(interval_seconds: int = 86400) -> bool:
    last = float(load_state().get("last_check_epoch", 0) or 0)
    return time.time() - last >= interval_seconds


def mark_checked() -> None:
    save_state(last_check_epoch=time.time())


def is_skipped(version: str) -> bool:
    return str(load_state().get("skipped_version", "")) == str(version)


def skip_version(version: str) -> None:
    save_state(skipped_version=str(version))
