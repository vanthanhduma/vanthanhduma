from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

try:
    import app
    ffmpeg = app.get_ffmpeg()
    nvenc_present = app.ffmpeg_has_encoder(ffmpeg, "h264_nvenc")
    nvenc_usable, nvenc_detail = app.probe_nvenc_result(ffmpeg)
    nvdec_listed = app.ffmpeg_has_hwaccel(ffmpeg, "cuda")
    dav1d_listed = app.ffmpeg_has_decoder(ffmpeg, "libdav1d")
    print("=== GOC REVIEW PHIM - KIEM TRA TANG TOC GPU ===")
    print("FFmpeg duoc chon:", ffmpeg)
    print("h264_nvenc encoder present:", nvenc_present)
    print("NVENC usable (real 720p test):", nvenc_usable)
    print("NVENC test detail:", nvenc_detail)
    print("CUDA hwaccel listed by FFmpeg:", nvdec_listed)
    print("libdav1d AV1 decoder present:", dav1d_listed)
    print("libx264 fallback present:", app.ffmpeg_has_encoder(ffmpeg, "libx264"))
    print()
    if nvenc_usable:
        print("KET LUAN: NVIDIA NVENC da ma hoa thu 30 frame 720p thanh cong.")
    elif nvenc_present:
        print("KET LUAN: FFmpeg co NVENC nhung phep thu thiet bi that bai.")
        print("Xem NVENC test detail o tren; khong can cai lai FFmpeg neu encoder da co.")
    else:
        print("KET LUAN: FFmpeg dang chon khong co h264_nvenc.")
        print("Hay chon mot ffmpeg.exe co NVENC trong Video Studio.")
    print("Ghi chu: RTX 2070 Super khong co NVDEC AV1; nguon AV1 van giai ma bang CPU.")
except Exception as exc:
    print("Khong the kiem tra FFmpeg:", exc)
    raise
